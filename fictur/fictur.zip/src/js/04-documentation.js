const chatEl = document.getElementById('chat');
const docScreen = document.getElementById('docScreen');
const docStartBtn = document.getElementById('docStartBtn');
const docToggle = document.getElementById('docToggle');
docStartBtn.addEventListener('click', () => docScreen.classList.add('hidden'));
docToggle.addEventListener('click', () => docScreen.classList.remove('hidden'));
