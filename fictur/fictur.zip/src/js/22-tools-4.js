
/* -------------------------------------------------------------------------
   9) SERTIFIKAT / PIAGAM GENERATOR — SVG siap cetak
   params: { judul, nama, keterangan, penyelenggara, tanggal }
   ------------------------------------------------------------------------- */
function renderSertifikatSVG({ judul, nama, keterangan, penyelenggara, tanggal }) {
  const w = 700, h = 495;
  const borderPad = 22;
  const ketLines = keterangan ? wrapSvgText(keterangan, w - 160) : [];
  const ketSvg = ketLines.map((l, i) => `<text x="${w / 2}" y="${290 + i * 16}" text-anchor="middle" font-size="11.5" fill="rgba(212,212,217,0.8)">${escapeSvgText(l)}</text>`).join('');

  return `<svg viewBox="0 0 ${w} ${h}" width="100%" xmlns="http://www.w3.org/2000/svg" font-family="'JetBrains Mono', monospace">
    <rect x="0" y="0" width="${w}" height="${h}" fill="#27272f"/>
    <rect x="${borderPad}" y="${borderPad}" width="${w - borderPad * 2}" height="${h - borderPad * 2}" fill="none" stroke="#7c6ae8" stroke-width="2.5"/>
    <rect x="${borderPad + 8}" y="${borderPad + 8}" width="${w - (borderPad + 8) * 2}" height="${h - (borderPad + 8) * 2}" fill="none" stroke="#7c6ae8" stroke-width="1" opacity="0.5"/>
    <text x="${w / 2}" y="100" text-anchor="middle" font-size="14" letter-spacing="4" fill="rgba(212,212,217,0.6)">SERTIFIKAT</text>
    <text x="${w / 2}" y="140" text-anchor="middle" font-size="24" font-weight="700" fill="#f5f5f7">${escapeSvgText(judul || 'PENGHARGAAN')}</text>
    <line x1="${w / 2 - 60}" y1="160" x2="${w / 2 + 60}" y2="160" stroke="#d97706" stroke-width="2"/>
    <text x="${w / 2}" y="205" text-anchor="middle" font-size="11" fill="rgba(212,212,217,0.7)">Diberikan kepada</text>
    <text x="${w / 2}" y="248" text-anchor="middle" font-size="30" font-weight="700" fill="#0f9d63">${escapeSvgText(nama || '')}</text>
    ${ketSvg}
    <text x="${w / 2}" y="400" text-anchor="middle" font-size="10" fill="rgba(212,212,217,0.6)">${escapeSvgText(tanggal || '')}</text>
    <text x="${w / 2}" y="420" text-anchor="middle" font-size="12" font-weight="600" fill="#d97706">${escapeSvgText(penyelenggara || '')}</text>
  </svg>`;
}

async function runSertifikatTool(params, wrap) {
  if (!params.nama) throw new Error('Nama penerima sertifikat tidak diberikan');
  const svgMarkup = renderSertifikatSVG(params);
  buildVisualBox(wrap, '', svgMarkup, 'sertifikat');
}

/* -------------------------------------------------------------------------
   10) PRESENSI / ABSENSI VISUAL — rekap kehadiran jadi grid warna
   params: { judul, siswa: [{nama, status: ['H','H','S','I','A',...]}] }
   status per hari: H=hadir S=sakit I=izin A=alpa
   ------------------------------------------------------------------------- */
const PRESENSI_COLOR = { H: '#0f9d63', S: '#d97706', I: '#2563eb', A: '#e0524f' };
const PRESENSI_LABEL = { H: 'Hadir', S: 'Sakit', I: 'Izin', A: 'Alpa' };

function parsePresensi(raw) {
  const arr = typeof raw === 'string' ? safeJsonParse(raw, 'siswa') : raw;
  return (arr || []).map(s => ({
    nama: String(s.nama || '').trim(),
    status: (s.status || []).map(x => String(x).toUpperCase().trim()[0]).filter(x => 'HSIA'.includes(x))
  })).filter(s => s.nama);
}

function renderPresensiSVG(siswa, judul) {
  const maxHari = Math.max(...siswa.map(s => s.status.length), 1);
  const nameColW = 130, cellW = 24, cellH = 24, headH = 26, pad = 20;
  const svgW = nameColW + maxHari * cellW + pad * 2;
  const svgH = headH + siswa.length * cellH + pad * 2 + (judul ? 24 : 0) + 40; // +40 untuk legenda
  const offsetY = judul ? 24 : 0;

  let headerSvg = `<text x="${pad + nameColW / 2}" y="${pad + offsetY + headH / 2 + 4}" text-anchor="middle" font-size="9" font-weight="700" fill="rgba(212,212,217,0.6)">Nama</text>`;
  for (let i = 0; i < maxHari; i++) {
    const x = pad + nameColW + i * cellW;
    headerSvg += `<text x="${x + cellW / 2}" y="${pad + offsetY + headH / 2 + 4}" text-anchor="middle" font-size="8.5" fill="rgba(212,212,217,0.55)">${i + 1}</text>`;
  }

  let bodySvg = '';
  siswa.forEach((s, ri) => {
    const y = pad + offsetY + headH + ri * cellH;
    bodySvg += `<text x="${pad}" y="${y + cellH / 2 + 3.5}" font-size="9.5" fill="#d4d4d9">${escapeSvgText(s.nama)}</text>`;
    s.status.forEach((st, ci) => {
      const x = pad + nameColW + ci * cellW;
      const color = PRESENSI_COLOR[st] || 'rgba(120,120,130,0.18)';
      bodySvg += `<rect x="${x + 2}" y="${y + 2}" width="${cellW - 4}" height="${cellH - 4}" rx="4" fill="${color}"/>
        <text x="${x + cellW / 2}" y="${y + cellH / 2 + 3.5}" text-anchor="middle" font-size="9" font-weight="700" fill="#14141a">${st}</text>`;
    });
  });

  const legendY = pad + offsetY + headH + siswa.length * cellH + 24;
  let legendSvg = '';
  Object.keys(PRESENSI_LABEL).forEach((k, i) => {
    const x = pad + i * 110;
    legendSvg += `<rect x="${x}" y="${legendY - 10}" width="14" height="14" rx="3" fill="${PRESENSI_COLOR[k]}"/>
      <text x="${x + 20}" y="${legendY + 1}" font-size="9" fill="rgba(212,212,217,0.7)">${k} = ${PRESENSI_LABEL[k]}</text>`;
  });

  const titleSvg = judul ? `<text x="${svgW / 2}" y="16" text-anchor="middle" font-size="12" font-weight="600" fill="#f5f5f7">${escapeSvgText(judul)}</text>` : '';

  return `<svg viewBox="0 0 ${svgW} ${svgH}" width="100%" xmlns="http://www.w3.org/2000/svg" font-family="'JetBrains Mono', monospace">
    ${titleSvg}
    ${headerSvg}
    ${bodySvg}
    ${legendSvg}
  </svg>`;
}

async function runPresensiTool(params, wrap) {
  const siswa = parsePresensi(params.siswa);
  if (!siswa.length) throw new Error('Data presensi tidak diberikan');
  const judul = params.judul || 'Rekap Presensi';
  const svgMarkup = renderPresensiSVG(siswa, judul);
  const rekap = siswa.map(s => {
    const count = { H: 0, S: 0, I: 0, A: 0 };
    s.status.forEach(st => { if (count[st] !== undefined) count[st]++; });
    return { nama: s.nama, ...count };
  });
  const box = buildVisualBox(wrap, judul, svgMarkup, 'presensi');
  const table = document.createElement('table');
  table.className = 'tool-visual-table';
  table.innerHTML = `<thead><tr><th>Nama</th><th>Hadir</th><th>Sakit</th><th>Izin</th><th>Alpa</th></tr></thead>
    <tbody>${rekap.map(r => `<tr><td>${escapeHtml(r.nama)}</td><td>${r.H}</td><td>${r.S}</td><td>${r.I}</td><td>${r.A}</td></tr>`).join('')}</tbody>`;
  box.insertBefore(table, box.querySelector('.tool-visual-actions'));
}

/* -------------------------------------------------------------------------
   11) QUIZ GENERATOR — dari materi, jadi soal pilihan ganda + kunci jawaban
   params: { judul, soal: [{pertanyaan, opsi:[...], jawaban_index}] }
   Ditampilkan sebagai kartu interaktif: pilih jawaban → langsung tahu benar/salah
   ------------------------------------------------------------------------- */
function parseQuizSoal(raw) {
  const arr = typeof raw === 'string' ? safeJsonParse(raw, 'soal') : raw;
  return (arr || []).map(s => ({
    pertanyaan: String(s.pertanyaan || '').trim(),
    opsi: (s.opsi || []).map(o => String(o).trim()).filter(Boolean),
    jawaban_index: Math.max(0, Number(s.jawaban_index) || 0)
  })).filter(s => s.pertanyaan && s.opsi.length >= 2);
}

async function runQuizGeneratorTool(params, wrap) {
  const soal = parseQuizSoal(params.soal);
  if (!soal.length) throw new Error('Data soal quiz tidak diberikan');
  const judul = params.judul || 'Quiz';

  wrap.innerHTML = '';
  const box = document.createElement('div');
  box.className = 'tool-visual tool-quizgen';
  const title = document.createElement('div');
  title.className = 'tool-visual-title';
  title.textContent = `${judul} (${soal.length} soal)`;
  box.appendChild(title);

  let skor = 0;
  let dijawab = 0;

  const skorEl = document.createElement('div');
  skorEl.className = 'quizgen-skor';
  skorEl.textContent = `Skor: 0 / ${soal.length}`;
  box.appendChild(skorEl);

  soal.forEach((s, si) => {
    const card = document.createElement('div');
    card.className = 'quizgen-card';
    const q = document.createElement('div');
    q.className = 'quizgen-question';
    q.textContent = `${si + 1}. ${s.pertanyaan}`;
    card.appendChild(q);

    const optWrap = document.createElement('div');
    optWrap.className = 'quizgen-options';
    let dijawabSoalIni = false;

    s.opsi.forEach((opsiText, oi) => {
      const optBtn = document.createElement('button');
      optBtn.className = 'quizgen-option';
      optBtn.textContent = opsiText;
      optBtn.addEventListener('click', () => {
        if (dijawabSoalIni) return;
        dijawabSoalIni = true;
        dijawab++;
        const benar = oi === s.jawaban_index;
        optBtn.classList.add(benar ? 'quizgen-correct' : 'quizgen-wrong');
        if (!benar) {
          const correctBtn = optWrap.children[s.jawaban_index];
          if (correctBtn) correctBtn.classList.add('quizgen-correct');
        } else {
          skor++;
        }
        skorEl.textContent = `Skor: ${skor} / ${soal.length}`;
        [...optWrap.children].forEach(b => b.disabled = true);
      });
      optWrap.appendChild(optBtn);
    });
    card.appendChild(optWrap);
    box.appendChild(card);
  });

  wrap.appendChild(box);
}

/* -------------------------------------------------------------------------
   12) RUMUS KE GAMBAR — render ekspresi matematika sederhana jadi SVG
   params: { rumus, keterangan }
   Catatan: parser MENDUKUNG sintaks sederhana ala teks (bukan LaTeX penuh):
   ^ untuk pangkat (x^2), _ untuk indeks (a_1), sqrt(...) untuk akar,
   / untuk pecahan sederhana a/b (dibuat pecahan bertingkat), * atau tanpa spasi untuk kali.
   ------------------------------------------------------------------------- */
function renderRumusSVG(rumus, keterangan) {
  // Pendekatan sederhana & robust: render token demi token dalam satu baris,
  // dengan superscript (^) dan subscript (_) digeser naik/turun, serta
  // sqrt(...) digambar dengan garis akar. Pecahan a/b (tanpa spasi di sekitar /,
  // dan operand tunggal) digambar bertingkat.
  const fontSize = 22;
  const charW = fontSize * 0.58;

  function renderPecahan(left, right, x, yBase) {
    const w = Math.max(left.length, right.length) * charW * 0.62 + 10;
    const topText = `<text x="${x + w / 2}" y="${yBase - 6}" text-anchor="middle" font-size="${fontSize * 0.75}" fill="#f5f5f7">${escapeSvgText(left)}</text>`;
    const botText = `<text x="${x + w / 2}" y="${yBase + 18}" text-anchor="middle" font-size="${fontSize * 0.75}" fill="#f5f5f7">${escapeSvgText(right)}</text>`;
    const line = `<line x1="${x}" y1="${yBase + 2}" x2="${x + w}" y2="${yBase + 2}" stroke="#f5f5f7" stroke-width="1.5"/>`;
    return { svg: topText + line + botText, width: w };
  }

  // Deteksi pecahan sederhana bentuk "A/B" di seluruh rumus (satu level saja, cukup untuk kasus umum)
  const fracMatch = rumus.match(/^([^\/]+)\/([^\/]+)$/);
  const yBase = 60;
  let bodySvg = '', totalWidth = 0;
  const pad = 20;

  if (fracMatch) {
    const { svg, width } = renderPecahan(fracMatch[1].trim(), fracMatch[2].trim(), pad, yBase);
    bodySvg = svg;
    totalWidth = width + pad * 2;
  } else {
    // Render inline dengan dukungan ^superscript, _subscript, sqrt(...)
    let x = pad;
    let i = 0;
    const parts = [];
    while (i < rumus.length) {
      const ch = rumus[i];
      if (rumus.slice(i, i + 5) === 'sqrt(') {
        const closeIdx = rumus.indexOf(')', i);
        const inner = closeIdx > -1 ? rumus.slice(i + 5, closeIdx) : rumus.slice(i + 5);
        const innerW = inner.length * charW * 0.62;
        parts.push({ type: 'sqrt', inner, width: innerW + 18 });
        i = closeIdx > -1 ? closeIdx + 1 : rumus.length;
      } else if (ch === '^') {
        let j = i + 1;
        let token = '';
        if (rumus[j] === '(') { const c2 = rumus.indexOf(')', j); token = rumus.slice(j + 1, c2); j = c2 + 1; }
        else { while (j < rumus.length && /[a-zA-Z0-9]/.test(rumus[j])) { token += rumus[j]; j++; } }
        parts.push({ type: 'sup', text: token });
        i = j;
      } else if (ch === '_') {
        let j = i + 1;
        let token = '';
        if (rumus[j] === '(') { const c2 = rumus.indexOf(')', j); token = rumus.slice(j + 1, c2); j = c2 + 1; }
        else { while (j < rumus.length && /[a-zA-Z0-9]/.test(rumus[j])) { token += rumus[j]; j++; } }
        parts.push({ type: 'sub', text: token });
        i = j;
      } else {
        let j = i;
        let token = '';
        while (j < rumus.length && !'^_'.includes(rumus[j]) && rumus.slice(j, j + 5) !== 'sqrt(') { token += rumus[j]; j++; }
        parts.push({ type: 'normal', text: token });
        i = j;
      }
    }

    parts.forEach(p => {
      if (p.type === 'normal') {
        const w = p.text.length * charW;
        bodySvg += `<text x="${x}" y="${yBase}" font-size="${fontSize}" fill="#f5f5f7">${escapeSvgText(p.text)}</text>`;
        x += w;
      } else if (p.type === 'sup') {
        const w = p.text.length * charW * 0.6 + 4;
        bodySvg += `<text x="${x}" y="${yBase - 10}" font-size="${fontSize * 0.62}" fill="#7c6ae8">${escapeSvgText(p.text)}</text>`;
        x += w;
      } else if (p.type === 'sub') {
        const w = p.text.length * charW * 0.6 + 4;
        bodySvg += `<text x="${x}" y="${yBase + 8}" font-size="${fontSize * 0.62}" fill="#0f9d63">${escapeSvgText(p.text)}</text>`;
        x += w;
      } else if (p.type === 'sqrt') {
        const innerW = p.width - 18;
        bodySvg += `<path d="M${x},${yBase - 4} L${x + 6},${yBase + 2} L${x + 12},${yBase - 16} L${x + p.width},${yBase - 16}" fill="none" stroke="#f5f5f7" stroke-width="1.5"/>
          <text x="${x + 16}" y="${yBase}" font-size="${fontSize}" fill="#f5f5f7">${escapeSvgText(p.inner)}</text>`;
        x += p.width + 4;
      }
    });
    totalWidth = x + pad;
  }

  const svgH = 100 + (keterangan ? 26 : 0);
  const ketSvg = keterangan ? `<text x="${totalWidth / 2}" y="${svgH - 12}" text-anchor="middle" font-size="10" fill="rgba(212,212,217,0.65)">${escapeSvgText(keterangan)}</text>` : '';

  return `<svg viewBox="0 0 ${Math.max(totalWidth, 120)} ${svgH}" width="100%" xmlns="http://www.w3.org/2000/svg" font-family="'JetBrains Mono', monospace">
    ${bodySvg}
    ${ketSvg}
  </svg>`;
}

async function runRumusTool(params, wrap) {
  const rumus = params.rumus;
  if (!rumus) throw new Error('Rumus tidak diberikan');
  const svgMarkup = renderRumusSVG(rumus, params.keterangan || '');
  buildVisualBox(wrap, '', svgMarkup, 'rumus');
}

/* -------------------------------------------------------------------------
   TOOL TAMBAHAN 1) RPP / MODUL AJAR — kartu ringkasan rencana pembelajaran
   params: { mapel, jenjang, topik, durasi, tujuan }
   ------------------------------------------------------------------------- */
function renderRppSVG({ mapel, jenjang, topik, durasi, tujuan }) {
  const w = 640;
  const tujuanLines = tujuan ? wrapSvgText(tujuan, w - 80) : [];
  const rows = [
    ['Mata Pelajaran', mapel || '-'],
    ['Jenjang / Kelas', jenjang || '-'],
    ['Topik', topik || '-'],
    ['Durasi', durasi || '2 x 35 menit'],
  ];
  let y = 96;
  let rowsSvg = '';
  rows.forEach(([label, val]) => {
    rowsSvg += `<text x="40" y="${y}" font-size="10.5" fill="rgba(212,212,217,0.55)">${escapeSvgText(label)}</text>
      <text x="220" y="${y}" font-size="12" font-weight="600" fill="#f5f5f7">${escapeSvgText(val)}</text>`;
    y += 30;
  });
  y += 10;
  const tujuanSvg = tujuanLines.map((l, i) => `<text x="40" y="${y + 24 + i * 17}" font-size="11" fill="#d4d4d9">${escapeSvgText(l)}</text>`).join('');
  const h = y + 24 + tujuanLines.length * 17 + 30;

  return `<svg viewBox="0 0 ${w} ${h}" width="100%" xmlns="http://www.w3.org/2000/svg" font-family="'JetBrains Mono', monospace">
    <rect x="0" y="0" width="${w}" height="${h}" rx="10" fill="#27272f"/>
    <text x="40" y="40" font-size="15" letter-spacing="2" fill="rgba(212,212,217,0.6)">RENCANA PEMBELAJARAN</text>
    <line x1="40" y1="56" x2="${w - 40}" y2="56" stroke="#7c6ae8" stroke-width="1.5"/>
    ${rowsSvg}
    <text x="40" y="${y}" font-size="10.5" fill="rgba(212,212,217,0.55)">Tujuan Pembelajaran</text>
    ${tujuanSvg}
  </svg>`;
}

async function runRppTool(params, wrap) {
  if (!params.mapel || !params.topik) throw new Error('Mapel dan topik RPP wajib diisi');
  if (!params.jenjang) throw new Error('Jenjang/kelas wajib diisi');
  const svgMarkup = renderRppSVG(params);
  buildVisualBox(wrap, '', svgMarkup, 'rpp');
}

/* -------------------------------------------------------------------------
   TOOL TAMBAHAN 2) SOAL ESSAY — daftar soal uraian + kunci (tersembunyi, klik untuk buka)
   params: { judul, soal: [{pertanyaan, poin, kunci}] }
   ------------------------------------------------------------------------- */
function parseSoalEssay(raw) {
  const arr = safeJsonParse(raw, 'soal') || [];
  return arr.map(s => ({
    pertanyaan: String(s.pertanyaan || '').trim(),
    poin: s.poin != null ? String(s.poin) : '',
    kunci: String(s.kunci || '').trim()
  })).filter(s => s.pertanyaan);
}

async function runSoalEssayTool(params, wrap) {
  const soal = parseSoalEssay(params.soal);
  if (!soal.length) throw new Error('Data soal essay tidak diberikan');
  const judul = params.judul || 'Soal Essay';

  wrap.innerHTML = '';
  const box = document.createElement('div');
  box.className = 'tool-visual tool-soal-essay';
  const title = document.createElement('div');
  title.className = 'tool-visual-title';
  title.textContent = judul;
  box.appendChild(title);

  const list = document.createElement('div');
  list.className = 'soal-essay-list';
  soal.forEach((s, i) => {
    const item = document.createElement('div');
    item.className = 'soal-essay-item';

    const q = document.createElement('div');
    q.className = 'soal-essay-question';
    q.textContent = `${i + 1}. ${s.pertanyaan}` + (s.poin ? ` (${s.poin} poin)` : '');
    item.appendChild(q);

    if (s.kunci) {
      const toggle = document.createElement('button');
      toggle.className = 'soal-essay-toggle';
      toggle.textContent = 'Lihat kunci jawaban';
      const kunciBox = document.createElement('div');
      kunciBox.className = 'soal-essay-kunci';
      kunciBox.textContent = s.kunci;
      kunciBox.style.display = 'none';
      toggle.addEventListener('click', () => {
        const showing = kunciBox.style.display !== 'none';
        kunciBox.style.display = showing ? 'none' : 'block';
        toggle.textContent = showing ? 'Lihat kunci jawaban' : 'Sembunyikan kunci jawaban';
      });
      item.appendChild(toggle);
      item.appendChild(kunciBox);
    }
    list.appendChild(item);
  });
  box.appendChild(list);
  wrap.appendChild(box);
}

/* -------------------------------------------------------------------------
   TOOL TAMBAHAN 3) SURAT EDARAN — format surat resmi siap cetak
   params: { perihal, tujuan, tanggal, isi, penandatangan }
   ------------------------------------------------------------------------- */
function renderSuratEdaranSVG({ perihal, tujuan, tanggal, isi, penandatangan }) {
  const w = 640;
  const isiLines = isi ? wrapSvgText(isi, w - 100) : [];
  const bodyH = isiLines.length * 17;
  const h = 260 + bodyH;

  let isiSvg = isiLines.map((l, i) => `<text x="50" y="${182 + i * 17}" font-size="11.5" fill="#d4d4d9">${escapeSvgText(l)}</text>`).join('');
  const signY = 182 + bodyH + 50;

  return `<svg viewBox="0 0 ${w} ${h}" width="100%" xmlns="http://www.w3.org/2000/svg" font-family="'JetBrains Mono', monospace">
    <rect x="0" y="0" width="${w}" height="${h}" fill="#27272f"/>
    <text x="${w / 2}" y="40" text-anchor="middle" font-size="14" letter-spacing="3" fill="rgba(212,212,217,0.6)">SURAT EDARAN</text>
    <line x1="50" y1="56" x2="${w - 50}" y2="56" stroke="#7c6ae8" stroke-width="1.5"/>
    <text x="50" y="86" font-size="10.5" fill="rgba(212,212,217,0.55)">Kepada Yth.</text>
    <text x="150" y="86" font-size="12" font-weight="600" fill="#f5f5f7">${escapeSvgText(tujuan || '-')}</text>
    <text x="50" y="110" font-size="10.5" fill="rgba(212,212,217,0.55)">Perihal</text>
    <text x="150" y="110" font-size="12" font-weight="600" fill="#f5f5f7">${escapeSvgText(perihal || '-')}</text>
    <text x="50" y="134" font-size="10.5" fill="rgba(212,212,217,0.55)">Tanggal</text>
    <text x="150" y="134" font-size="12" fill="#d4d4d9">${escapeSvgText(tanggal || '-')}</text>
    <line x1="50" y1="152" x2="${w - 50}" y2="152" stroke="rgba(124,106,232,0.3)" stroke-width="1"/>
    ${isiSvg}
    <text x="${w - 50}" y="${signY}" text-anchor="end" font-size="11.5" font-weight="600" fill="#0f9d63">${escapeSvgText(penandatangan || '')}</text>
  </svg>`;
}

async function runSuratEdaranTool(params, wrap) {
  if (!params.perihal || !params.isi) throw new Error('Perihal dan isi surat wajib diisi');
  const svgMarkup = renderSuratEdaranSVG(params);
  buildVisualBox(wrap, '', svgMarkup, 'surat-edaran');
}

/* -------------------------------------------------------------------------
   TOOL TAMBAHAN 4) CV RINGKAS — riwayat hidup singkat
   params: { nama, kontak, ringkasan, pengalaman: [{posisi,instansi,tahun,deskripsi}],
             pendidikan: [{jenjang,institusi,tahun}], skill }
   ------------------------------------------------------------------------- */
function renderCvSVG({ nama, kontak, ringkasan, pengalaman, pendidikan, skill }) {
  const w = 640;
  let y = 90;
  const ringkasanLines = ringkasan ? wrapSvgText(ringkasan, w - 100) : [];
  let body = '';

  ringkasanLines.forEach((l, i) => { body += `<text x="50" y="${y + i * 16}" font-size="11" fill="#d4d4d9">${escapeSvgText(l)}</text>`; });
  y += ringkasanLines.length * 16 + 26;

  if (pengalaman.length) {
    body += `<text x="50" y="${y}" font-size="11.5" font-weight="700" fill="#7c6ae8">PENGALAMAN</text>`;
    y += 22;
    pengalaman.forEach(p => {
      body += `<text x="50" y="${y}" font-size="11.5" font-weight="600" fill="#f5f5f7">${escapeSvgText(p.posisi || '')} — ${escapeSvgText(p.instansi || '')}</text>
        <text x="${w - 50}" y="${y}" text-anchor="end" font-size="9.5" fill="rgba(212,212,217,0.55)">${escapeSvgText(p.tahun || '')}</text>`;
      y += 16;
      if (p.deskripsi) {
        const dLines = wrapSvgText(p.deskripsi, w - 100);
        dLines.forEach(l => { body += `<text x="50" y="${y}" font-size="10" fill="rgba(212,212,217,0.75)">${escapeSvgText(l)}</text>`; y += 15; });
      }
      y += 10;
    });
  }

  if (pendidikan.length) {
    body += `<text x="50" y="${y}" font-size="11.5" font-weight="700" fill="#7c6ae8">PENDIDIKAN</text>`;
    y += 22;
    pendidikan.forEach(p => {
      body += `<text x="50" y="${y}" font-size="11" font-weight="600" fill="#f5f5f7">${escapeSvgText(p.jenjang || '')} — ${escapeSvgText(p.institusi || '')}</text>
        <text x="${w - 50}" y="${y}" text-anchor="end" font-size="9.5" fill="rgba(212,212,217,0.55)">${escapeSvgText(p.tahun || '')}</text>`;
      y += 24;
    });
  }

  if (skill) {
    body += `<text x="50" y="${y}" font-size="11.5" font-weight="700" fill="#7c6ae8">KEMAMPUAN</text>`;
    y += 20;
    body += `<text x="50" y="${y}" font-size="10.5" fill="#d4d4d9">${escapeSvgText(skill)}</text>`;
    y += 24;
  }

  const h = y + 20;
  return `<svg viewBox="0 0 ${w} ${h}" width="100%" xmlns="http://www.w3.org/2000/svg" font-family="'JetBrains Mono', monospace">
    <rect x="0" y="0" width="${w}" height="${h}" fill="#27272f"/>
    <text x="50" y="42" font-size="20" font-weight="700" fill="#f5f5f7">${escapeSvgText(nama || '')}</text>
    <text x="50" y="62" font-size="10.5" fill="rgba(212,212,217,0.6)">${escapeSvgText(kontak || '')}</text>
    <line x1="50" y1="74" x2="${w - 50}" y2="74" stroke="#7c6ae8" stroke-width="1.5"/>
    ${body}
  </svg>`;
}

async function runCvRingkasTool(params, wrap) {
  if (!params.nama) throw new Error('Nama wajib diisi untuk CV');
  const pengalaman = safeJsonParse(params.pengalaman, 'pengalaman') || [];
  const pendidikan = safeJsonParse(params.pendidikan, 'pendidikan') || [];
  const svgMarkup = renderCvSVG({ ...params, pengalaman, pendidikan });
  buildVisualBox(wrap, '', svgMarkup, 'cv-ringkas');
}

/* -------------------------------------------------------------------------
   TOOL TAMBAHAN 5) CHECKLIST — daftar centang interaktif
   params: { judul, item: "a|b|c" }
   ------------------------------------------------------------------------- */
async function runChecklistTool(params, wrap) {
  const items = String(params.item || '').split('|').map(s => s.trim()).filter(Boolean);
  if (!items.length) throw new Error('Data checklist tidak diberikan');
  const judul = params.judul || 'Checklist';

  wrap.innerHTML = '';
  const box = document.createElement('div');
  box.className = 'tool-visual tool-checklist';
  const title = document.createElement('div');
  title.className = 'tool-visual-title';
  title.textContent = judul;
  box.appendChild(title);

  const list = document.createElement('div');
  list.className = 'checklist-list';
  items.forEach((text, i) => {
    const row = document.createElement('label');
    row.className = 'checklist-row';
    const cb = document.createElement('input');
    cb.type = 'checkbox';
    cb.addEventListener('change', () => row.classList.toggle('checked', cb.checked));
    const span = document.createElement('span');
    span.textContent = text;
    row.appendChild(cb);
    row.appendChild(span);
    list.appendChild(row);
  });
  box.appendChild(list);
  wrap.appendChild(box);
}

/* -------------------------------------------------------------------------
   TOOL TAMBAHAN 6) KALKULATOR BMI
   params: { berat (kg), tinggi (cm) }
   ------------------------------------------------------------------------- */
function bmiKategori(bmi) {
  if (bmi < 18.5) return { label: 'Berat badan kurang', color: '#2563eb' };
  if (bmi < 25) return { label: 'Berat badan normal', color: '#0f9d63' };
  if (bmi < 30) return { label: 'Berat badan berlebih', color: '#d97706' };
  return { label: 'Obesitas', color: '#e0524f' };
}

function renderBmiSVG(berat, tinggi) {
  const tinggiM = tinggi / 100;
  const bmi = berat / (tinggiM * tinggiM);
  const bmiRounded = Math.round(bmi * 10) / 10;
  const kat = bmiKategori(bmi);
  const w = 420, h = 220;

  return `<svg viewBox="0 0 ${w} ${h}" width="100%" xmlns="http://www.w3.org/2000/svg" font-family="'JetBrains Mono', monospace">
    <rect x="0" y="0" width="${w}" height="${h}" rx="10" fill="#27272f"/>
    <text x="${w / 2}" y="36" text-anchor="middle" font-size="12" letter-spacing="2" fill="rgba(212,212,217,0.6)">HASIL BMI</text>
    <text x="${w / 2}" y="98" text-anchor="middle" font-size="46" font-weight="700" fill="${kat.color}">${bmiRounded}</text>
    <text x="${w / 2}" y="130" text-anchor="middle" font-size="13" font-weight="600" fill="${kat.color}">${escapeSvgText(kat.label)}</text>
    <line x1="60" y1="155" x2="${w - 60}" y2="155" stroke="rgba(124,106,232,0.3)" stroke-width="1"/>
    <text x="${w / 2 - 60}" y="180" text-anchor="middle" font-size="10" fill="rgba(212,212,217,0.55)">Berat</text>
    <text x="${w / 2 - 60}" y="198" text-anchor="middle" font-size="12" font-weight="600" fill="#f5f5f7">${berat} kg</text>
    <text x="${w / 2 + 60}" y="180" text-anchor="middle" font-size="10" fill="rgba(212,212,217,0.55)">Tinggi</text>
    <text x="${w / 2 + 60}" y="198" text-anchor="middle" font-size="12" font-weight="600" fill="#f5f5f7">${tinggi} cm</text>
  </svg>`;
}

async function runKalkulatorBmiTool(params, wrap) {
  const berat = parseFloat(params.berat);
  const tinggi = parseFloat(params.tinggi);
  if (!berat || !tinggi) throw new Error('Berat dan tinggi badan wajib diisi dengan angka valid');
  const svgMarkup = renderBmiSVG(berat, tinggi);
  buildVisualBox(wrap, '', svgMarkup, 'bmi');
}

/* -------------------------------------------------------------------------
   TOOL TAMBAHAN 7) RESEP MASAK
   params: { nama, porsi, bahan: "a|b|c", langkah: "a|b|c" }
   ------------------------------------------------------------------------- */
async function runResepMasakTool(params, wrap) {
  const bahan = String(params.bahan || '').split('|').map(s => s.trim()).filter(Boolean);
  const langkah = String(params.langkah || '').split('|').map(s => s.trim()).filter(Boolean);
  if (!params.nama) throw new Error('Nama masakan wajib diisi');
  if (!bahan.length || !langkah.length) throw new Error('Bahan dan langkah resep wajib diisi');
  const porsi = params.porsi || '2';

  wrap.innerHTML = '';
  const box = document.createElement('div');
  box.className = 'tool-visual tool-resep';
  const title = document.createElement('div');
  title.className = 'tool-visual-title';
  title.textContent = `${params.nama} (untuk ${porsi} porsi)`;
  box.appendChild(title);

  const bahanHeader = document.createElement('div');
  bahanHeader.className = 'resep-subheader';
  bahanHeader.textContent = 'Bahan-bahan';
  box.appendChild(bahanHeader);
  const bahanList = document.createElement('ul');
  bahanList.className = 'resep-bahan-list';
  bahan.forEach(b => { const li = document.createElement('li'); li.textContent = b; bahanList.appendChild(li); });
  box.appendChild(bahanList);

  const langkahHeader = document.createElement('div');
  langkahHeader.className = 'resep-subheader';
  langkahHeader.textContent = 'Langkah-langkah';
  box.appendChild(langkahHeader);
  const langkahList = document.createElement('ol');
  langkahList.className = 'resep-langkah-list';
  langkah.forEach(l => { const li = document.createElement('li'); li.textContent = l; langkahList.appendChild(li); });
  box.appendChild(langkahList);

  wrap.appendChild(box);
}

/* -------------------------------------------------------------------------
   TOOL TAMBAHAN 8) COUNTDOWN — hitung mundur ke tanggal target
   params: { judul, tanggal_target (YYYY-MM-DD), keterangan }
   ------------------------------------------------------------------------- */
async function runCountdownTool(params, wrap) {
  const target = params.tanggal_target;
  if (!target) throw new Error('Tanggal target countdown wajib diisi');
  const targetDate = new Date(target + 'T00:00:00');
  if (isNaN(targetDate.getTime())) throw new Error('Format tanggal_target tidak valid (pakai YYYY-MM-DD)');
  const judul = params.judul || 'Countdown';

  wrap.innerHTML = '';
  const box = document.createElement('div');
  box.className = 'tool-visual tool-countdown';
  const title = document.createElement('div');
  title.className = 'tool-visual-title';
  title.textContent = judul;
  box.appendChild(title);

  const numsWrap = document.createElement('div');
  numsWrap.className = 'countdown-nums';
  box.appendChild(numsWrap);

  if (params.keterangan) {
    const ket = document.createElement('div');
    ket.className = 'countdown-keterangan';
    ket.textContent = params.keterangan;
    box.appendChild(ket);
  }
  wrap.appendChild(box);

  let intervalId = null;
  function render() {
    const now = new Date();
    const diffMs = targetDate.getTime() - now.getTime();
    if (diffMs <= 0) {
      numsWrap.innerHTML = `<div class="countdown-done">Waktunya sudah tiba! 🎉</div>`;
      if (intervalId) clearInterval(intervalId);
      return;
    }
    const totalSec = Math.floor(diffMs / 1000);
    const days = Math.floor(totalSec / 86400);
    const hours = Math.floor((totalSec % 86400) / 3600);
    const mins = Math.floor((totalSec % 3600) / 60);
    const secs = totalSec % 60;
    numsWrap.innerHTML = `
      <div class="countdown-unit"><span>${days}</span><label>Hari</label></div>
      <div class="countdown-unit"><span>${String(hours).padStart(2,'0')}</span><label>Jam</label></div>
      <div class="countdown-unit"><span>${String(mins).padStart(2,'0')}</span><label>Menit</label></div>
      <div class="countdown-unit"><span>${String(secs).padStart(2,'0')}</span><label>Detik</label></div>
    `;
  }
  render();
  intervalId = setInterval(render, 1000);
}

/* -------------------------------------------------------------------------
   TOOL TAMBAHAN 9) QUOTES — kutipan tokoh/filsuf/anime random
   params: { kategori: tokoh|filsuf|anime }
   ------------------------------------------------------------------------- */
async function fetchQuotesList(kategori) {
  if (quotesCache[kategori]) return quotesCache[kategori];
  const source = QUOTES_SOURCES[kategori];
  const res = await fetch(source.url);
  if (!res.ok) throw new Error(`Gagal mengambil data quotes (HTTP ${res.status})`);
  const json = await res.json();
  const list = Array.isArray(json) ? json
    : Array.isArray(json.quotes) ? json.quotes
    : Array.isArray(json.result) ? json.result
    : Array.isArray(json.data) ? json.data
    : [];
  if (!list.length) throw new Error('Data quotes kosong');
  quotesCache[kategori] = list;
  return list;
}

function pickField(obj, keys) {
  for (const k of keys) if (obj[k]) return obj[k];
  return null;
}

async function runQuotesTool(params, wrap) {
  const kategori = (params.kategori || '').toLowerCase().trim();
  const source = QUOTES_SOURCES[kategori];
  if (!source) throw new Error('Kategori quotes tidak dikenal (pakai: tokoh, filsuf, atau anime)');

  const list = await fetchQuotesList(kategori);

  wrap.innerHTML = '';
  const box = document.createElement('div');
  box.className = 'tool-visual tool-quotes';

  const quoteText = document.createElement('div');
  quoteText.className = 'quotes-text';
  const quoteFigure = document.createElement('div');
  quoteFigure.className = 'quotes-figure';

  box.appendChild(quoteText);
  box.appendChild(quoteFigure);

  function renderRandom() {
    const item = list[Math.floor(Math.random() * list.length)];
    const quote = item.quote || item.text || item.kata || '';
    const figure = pickField(item, source.figureKeys) || 'Tidak diketahui';
    const anime = source.animeKeys ? pickField(item, source.animeKeys) : null;
    quoteText.textContent = `"${quote}"`;
    quoteFigure.textContent = anime ? `— ${figure} (${anime})` : `— ${figure}`;
  }
  renderRandom();

  const actions = document.createElement('div');
  actions.className = 'tool-visual-actions';
  const nextBtn = document.createElement('button');
  nextBtn.textContent = 'Quote lain →';
  nextBtn.addEventListener('click', renderRandom);
  actions.appendChild(nextBtn);
  box.appendChild(actions);

  wrap.appendChild(box);
}

/* -------------------------------------------------------------------------
   TOOL TAMBAHAN 10) TRANSCRIBE — ubah audio terlampir jadi teks
   params: {} (tidak perlu parameter, otomatis pakai audio terakhir dilampirkan)
   Alur: warmup -> presign -> upload PUT ke OSS -> check quota -> submit ->
   polling sampai selesai. Semua request lewat FICTUR_CORS_PROXY karena
   audioconvert.ai tidak mengizinkan CORS langsung dari browser.
   ------------------------------------------------------------------------- */
const TRANSCRIBE_BASE = 'https://audioconvert.ai';
const TRANSCRIBE_PAGE_URL = `${TRANSCRIBE_BASE}/id`;
const TRANSCRIBE_JWT_SECRET = 'auc995cx6se';

function transcribeBase64Url(input) {
  let str = btoa(String.fromCharCode(...new Uint8Array(input)));
  return str.replace(/=+$/g, '').replace(/\+/g, '-').replace(/\//g, '_');
}

async function transcribeHmacSha256Base64Url(secret, data) {
  const enc = new TextEncoder();
  const key = await crypto.subtle.importKey('raw', enc.encode(secret), { name: 'HMAC', hash: 'SHA-256' }, false, ['sign']);
  const sig = await crypto.subtle.sign('HMAC', key, enc.encode(data));
  return transcribeBase64Url(sig);
}

async function createTranscribeGuestBearer() {
  const userId = crypto.randomUUID();
  const header = { alg: 'HS256', typ: 'JWT' };
  const payload = { userId };
  const enc = new TextEncoder();
  const encodedHeader = transcribeBase64Url(enc.encode(JSON.stringify(header)));
  const encodedPayload = transcribeBase64Url(enc.encode(JSON.stringify(payload)));
  const data = `${encodedHeader}.${encodedPayload}`;
  const signature = await transcribeHmacSha256Base64Url(TRANSCRIBE_JWT_SECRET, data);
  return `${data}.${signature}`;
}

function transcribeProxyFetch(targetUrl, options) {
  return fetch(FICTUR_CORS_PROXY + encodeURIComponent(targetUrl), options);
}

async function transcribeWarmup() {
  await transcribeProxyFetch(TRANSCRIBE_PAGE_URL, { method: 'GET' });
}

async function transcribePresign(token, filename) {
  const url = `${TRANSCRIBE_BASE}/api/resource/upload/presign?filename=${encodeURIComponent(filename)}`;
  const res = await transcribeProxyFetch(url, {
    method: 'GET',
    headers: { authorization: `Bearer ${token}`, accept: '*/*' }
  });
  const data = await res.json().catch(() => null);
  if (!res.ok || data?.code !== 100000 || !data?.data?.upload_url) {
    throw new Error(`Presign gagal (HTTP ${res.status})`);
  }
  return data.data.upload_url;
}

async function transcribeUploadToOss(uploadUrl, blob) {
  const res = await transcribeProxyFetch(uploadUrl, {
    method: 'PUT',
    headers: { 'Content-Type': blob.type || 'application/octet-stream' },
    body: blob
  });
  if (!res.ok) throw new Error(`Upload audio gagal (HTTP ${res.status})`);
  return uploadUrl.split('?')[0];
}

async function transcribeCheckGuestQuota(token, durationMinutes) {
  const res = await transcribeProxyFetch(`${TRANSCRIBE_BASE}/api/transcribe/check-guest-quota`, {
    method: 'POST',
    headers: { authorization: `Bearer ${token}`, 'content-type': 'application/json', accept: 'application/json' },
    body: JSON.stringify({ duration_minutes: durationMinutes })
  });
  const data = await res.json().catch(() => null);
  if (!res.ok || data?.code !== 100000 || !data?.data?.allowed) {
    throw new Error('Kuota transcribe gratis sudah habis atau tidak diizinkan');
  }
}

async function transcribeCreate(token, audioUrl, fileName) {
  const res = await transcribeProxyFetch(`${TRANSCRIBE_BASE}/api/transcribe/`, {
    method: 'POST',
    headers: { authorization: `Bearer ${token}`, 'content-type': 'application/json', accept: 'application/json' },
    body: JSON.stringify({ audio_url: audioUrl, language_code: '', file_name: fileName, scenario: 'auto' })
  });
  const data = await res.json().catch(() => null);
  if (!res.ok || data?.code !== 100000 || !data?.data?.id) {
    throw new Error(`Submit transcribe gagal (HTTP ${res.status})`);
  }
  return data.data;
}

function transcribeExtractText(data) {
  const d = data?.data ?? data;
  if (!d) return null;
  if (typeof d === 'string') return d;
  const value = d.text ?? d.transcript ?? d.result ?? d.content ?? d.transcription
    ?? (d.segments ? d.segments.map(x => x.text).filter(Boolean).join(' ') : null);
  if (typeof value === 'string') return value;
  if (value && typeof value === 'object') {
    return value.text ?? value.transcript ?? value.result ?? value.content ?? value.transcription ?? null;
  }
  return null;
}

async function transcribePoll(token, taskId, onProgress) {
  for (let i = 0; i < 40; i++) {
    const res = await transcribeProxyFetch(`${TRANSCRIBE_BASE}/api/transcribe/${taskId}`, {
      method: 'GET',
      headers: { authorization: `Bearer ${token}`, accept: '*/*' }
    });
    const data = await res.json().catch(() => null);

    if (data?.code === 100001 || data?.message === 'Need Login') {
      throw new Error('Layanan transcribe meminta login (kuota tamu habis)');
    }
    if (res.ok && data?.code === 100000) {
      const task = data.data;
      const text = transcribeExtractText(data);
      if (task?.status === 'succeeded' || task?.status === 'success' || task?.status === 'completed' || text) {
        return text;
      }
      if (task?.status === 'failed' || task?.status === 'error') {
        throw new Error(task?.error ?? data?.message ?? 'Transcribe gagal diproses');
      }
    }
    if (onProgress) onProgress(i + 1);
    await new Promise(r => setTimeout(r, 3000));
  }
  throw new Error('Transcribe memakan waktu terlalu lama, coba lagi nanti');
}

async function getAudioDurationMinutes(dataUrl) {
  try {
    const duration = await new Promise((resolve, reject) => {
      const audio = new Audio();
      audio.preload = 'metadata';
      audio.onloadedmetadata = () => resolve(audio.duration);
      audio.onerror = () => reject(new Error('Gagal membaca durasi audio'));
      audio.src = dataUrl;
    });
    if (!Number.isFinite(duration) || duration <= 0) return 1;
    return Math.max(1, Math.ceil(duration / 60));
  } catch {
    return 1;
  }
}

async function runTranscribeTool(params, wrap) {
  if (!lastUserAudioDataUrl) throw new Error('Belum ada file audio yang dilampirkan untuk ditranskrip');

  wrap.innerHTML = '';
  const box = document.createElement('div');
  box.className = 'tool-visual tool-transcribe';
  const status = document.createElement('div');
  status.className = 'transcribe-status';
  status.textContent = 'Menyiapkan...';
  box.appendChild(status);
  wrap.appendChild(box);

  const blob = dataUrlToBlob(lastUserAudioDataUrl);
  const filename = lastUserAudioName || 'audio.mp3';

  const token = await createTranscribeGuestBearer();
  const durationMinutes = await getAudioDurationMinutes(lastUserAudioDataUrl);

  status.textContent = 'Menghubungkan ke layanan...';
  await transcribeWarmup();

  status.textContent = 'Mengunggah audio...';
  const uploadUrl = await transcribePresign(token, filename);
  const audioUrl = await transcribeUploadToOss(uploadUrl, blob);

  status.textContent = 'Memeriksa kuota...';
  await transcribeCheckGuestQuota(token, durationMinutes);

  status.textContent = 'Memproses transkrip...';
  const task = await transcribeCreate(token, audioUrl, filename);

  const text = await transcribePoll(token, task.id, (attempt) => {
    status.textContent = `Memproses transkrip... (${attempt * 3} detik)`;
  });

  if (!text) throw new Error('Hasil transkrip kosong');

  wrap.innerHTML = '';
  const resultBox = document.createElement('div');
  resultBox.className = 'tool-visual tool-transcribe';
  const title = document.createElement('div');
  title.className = 'tool-visual-title';
  title.textContent = `Transkrip — ${filename}`;
  resultBox.appendChild(title);
  const textEl = document.createElement('div');
  textEl.className = 'transcribe-text';
  textEl.textContent = text;
  resultBox.appendChild(textEl);

  const actions = document.createElement('div');
  actions.className = 'tool-visual-actions';
  const copyBtn = document.createElement('button');
  copyBtn.textContent = '⧉ Salin Teks';
  copyBtn.addEventListener('click', () => {
    navigator.clipboard.writeText(text).then(() => {
      copyBtn.textContent = '✓ Tersalin';
      setTimeout(() => { copyBtn.textContent = '⧉ Salin Teks'; }, 1500);
    });
  });
  actions.appendChild(copyBtn);
  resultBox.appendChild(actions);

  wrap.appendChild(resultBox);
}


