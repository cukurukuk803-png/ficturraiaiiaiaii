// ===================== Pexels image search (bukan generate) =====================
// Dipakai untuk mengganti placeholder "PEXELS:kata kunci" yang ditulis AI di dalam
// kode HTML/CSS (model fictur-chatbot & fictur-q1-code) dengan URL foto asli dari
// Pexels, supaya UI yang dihasilkan AI punya gambar nyata & relevan alih-alih
// placeholder abu-abu/link 404. Hasil dipilih otomatis: ambil hasil teratas per
// kata kunci (AI cuma bisa menulis teks, tidak bisa "melihat" mana yang paling
// bagus, jadi pemilihan gambar terbaik didelegasikan ke ranking relevansi Pexels).
const PEXELS_API_KEY = 'cm3FEQEsOE8Ior9rq5E9NB2rlZWF5r5h792Z2MdUInCKrBtgLGOKwpoJ';
const PEXELS_SEARCH_URL = 'https://api.pexels.com/v1/search';
// Cache per kata kunci (case-insensitive) supaya kata kunci yang sama tidak
// nge-hit API Pexels berkali-kali dalam satu sesi (mis. dipakai ulang di
// beberapa turn atau dua placeholder dengan kata kunci identik).
const pexelsCache = new Map();

async function searchPexelsImage(query) {
  const key = query.trim().toLowerCase();
  if (pexelsCache.has(key)) return pexelsCache.get(key);

  const url = `${PEXELS_SEARCH_URL}?query=${encodeURIComponent(query)}&per_page=1&orientation=landscape`;
  const promise = (async () => {
    try {
      const res = await fetch(PROXY + encodeURIComponent(url), {
        headers: { 'Authorization': PEXELS_API_KEY }
      });
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      const data = await res.json();
      const photo = data?.photos?.[0];
      if (!photo) return null;
      // large2x cukup besar untuk background/hero tapi tidak seberat original
      return photo.src?.large2x || photo.src?.large || photo.src?.original || null;
    } catch (e) {
      console.warn('[Pexels] gagal cari gambar untuk query:', query, e.message);
      return null;
    }
  })();
  pexelsCache.set(key, promise);
  return promise;
}

// Cari semua placeholder "PEXELS:kata kunci" di dalam teks (biasanya di dalam
// fenced code block HTML/CSS), resolve semuanya paralel ke URL Pexels asli,
// lalu kembalikan teks dengan placeholder sudah diganti. Placeholder yang
// gagal dicari (tidak ada hasil / error jaringan) dibiarkan apa adanya supaya
// tidak menghasilkan src rusak/kosong secara diam-diam.
async function resolvePexelsPlaceholders(rawText) {
  if (!rawText || !rawText.includes('PEXELS:')) return rawText;

  const re = /PEXELS:([^"'()\n]+)/g;
  const matches = [...rawText.matchAll(re)];
  if (!matches.length) return rawText;

  const uniqueQueries = [...new Set(matches.map(m => m[1].trim()))];
  const resolved = await Promise.all(
    uniqueQueries.map(async q => [q, await searchPexelsImage(q)])
  );
  const urlByQuery = new Map(resolved);

  return rawText.replace(re, (full, rawQuery) => {
    const q = rawQuery.trim();
    const url = urlByQuery.get(q);
    return url || full;
  });
}

async function generateImage(promptText, plateEl) {
  try {
    const payload = {
      prompt: promptText,
      width: 1024,
      height: 1024,
      style: 'Default',
      type: 'text2img-ai-generator',
      stylePrompt: 'high quality artistic image, detailed, vibrant colors, professional',
      images: []
    };

    const targetUrl = `${VONDY_BASE}/api/open/image/generate`;
    const proxiedUrl = PROXY + encodeURIComponent(targetUrl);

    const res = await fetch(proxiedUrl, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Origin': 'https://vondy.com',
        'Referer': 'https://vondy.com/'
      },
      body: JSON.stringify(payload)
    });

    const raw = await res.text();
    if (!res.ok) throw new Error(`HTTP ${res.status}`);

    let data;
    try { data = JSON.parse(raw); } catch (_) { throw new Error('Response bukan JSON'); }

    const imgUrl =
      data?.data?.url ||
      data?.data?.image ||
      data?.data?.images?.[0] ||
      data?.url ||
      data?.image ||
      data?.images?.[0] ||
      (typeof data?.data === 'string' ? data.data : null);

    if (!imgUrl) throw new Error('URL gambar tidak ditemukan');

    const finalSrc = imgUrl.startsWith('http') ? PROXY + encodeURIComponent(imgUrl) : imgUrl;

    plateEl.innerHTML = '';
    const img = document.createElement('img');
    img.src = finalSrc;
    img.alt = promptText;
    plateEl.appendChild(img);
    plateEl.appendChild(createDownloadButton(finalSrc, 'image'));
    scrollToBottom(false);

  } catch (err) {
    plateEl.classList.add('error');
    plateEl.innerHTML = `<span>Gagal membuat gambar — ${err.message}</span>`;
  }
}

