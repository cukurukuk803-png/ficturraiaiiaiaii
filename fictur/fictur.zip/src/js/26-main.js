/* ===================== Inisialisasi ===================== */
if (allChats.length > 0) {
  switchToChat(allChats[0].id);
} else {
  startNewChat();
}

