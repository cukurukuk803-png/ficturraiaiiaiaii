function loadAllChats() {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    return raw ? JSON.parse(raw) : [];
  } catch (_) { return []; }
}
function persistAllChats() {
  try { localStorage.setItem(STORAGE_KEY, JSON.stringify(allChats)); } catch (_) {}
}
function createNewChatRecord() {
  const id = crypto.randomUUID();
  const rec = { id, title: 'Obrolan baru', messages: [], createdAt: Date.now() };
  allChats.unshift(rec);
  persistAllChats();
  return rec;
}
function getCurrentChat() {
  return allChats.find(c => c.id === currentChatId);
}
function saveTurnToChat(role, text) {
  const chat = getCurrentChat();
  if (!chat) return;
  chat.messages.push({ role, text });
  if (chat.title === 'Obrolan baru' && role === 'user') {
    chat.title = text.slice(0, 40) + (text.length > 40 ? '…' : '');
  }
  persistAllChats();
  renderHistoryList();
}

