/* -------------------------------------------------------------------------
   8) FLASHCARD — kartu depan/belakang, tampil sebagai HTML interaktif (flip)
   params: { judul, kartu: [{depan, belakang}] }
   ------------------------------------------------------------------------- */
function parseFlashcards(raw) {
  const arr = typeof raw === 'string' ? safeJsonParse(raw, 'kartu') : raw;
  return (arr || []).map(k => ({
    depan: String(k.depan || '').trim(),
    belakang: String(k.belakang || '').trim()
  })).filter(k => k.depan && k.belakang);
}

async function runFlashcardTool(params, wrap) {
  const kartu = parseFlashcards(params.kartu);
  if (!kartu.length) throw new Error('Data flashcard tidak diberikan');
  const judul = params.judul || 'Flashcard';

  wrap.innerHTML = '';
  const box = document.createElement('div');
  box.className = 'tool-visual tool-flashcard';
  const title = document.createElement('div');
  title.className = 'tool-visual-title';
  title.textContent = judul;
  box.appendChild(title);

  let idx = 0;
  const cardWrap = document.createElement('div');
  cardWrap.className = 'flashcard-stage';

  const counter = document.createElement('div');
  counter.className = 'flashcard-counter';

  function renderCard() {
    cardWrap.innerHTML = '';
    const card = document.createElement('div');
    card.className = 'flashcard';
    const inner = document.createElement('div');
    inner.className = 'flashcard-inner';
    const front = document.createElement('div');
    front.className = 'flashcard-face flashcard-front';
    front.textContent = kartu[idx].depan;
    const back = document.createElement('div');
    back.className = 'flashcard-face flashcard-back';
    back.textContent = kartu[idx].belakang;
    inner.appendChild(front);
    inner.appendChild(back);
    card.appendChild(inner);
    card.addEventListener('click', () => card.classList.toggle('flipped'));
    cardWrap.appendChild(card);
    counter.textContent = `Kartu ${idx + 1} / ${kartu.length} — klik kartu untuk membalik`;
  }
  renderCard();
  box.appendChild(cardWrap);
  box.appendChild(counter);

  const actions = document.createElement('div');
  actions.className = 'tool-visual-actions';
  const prevBtn = document.createElement('button');
  prevBtn.textContent = '← Sebelumnya';
  prevBtn.addEventListener('click', () => { idx = (idx - 1 + kartu.length) % kartu.length; renderCard(); });
  const nextBtn = document.createElement('button');
  nextBtn.textContent = 'Berikutnya →';
  nextBtn.addEventListener('click', () => { idx = (idx + 1) % kartu.length; renderCard(); });
  actions.appendChild(prevBtn);
  actions.appendChild(nextBtn);
  box.appendChild(actions);
  wrap.appendChild(box);
}
