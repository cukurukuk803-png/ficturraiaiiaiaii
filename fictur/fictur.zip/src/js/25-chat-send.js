async function handleSend() {
  const text = inputEl.value.trim();
  const imageDataUrl = pendingImageDataUrl;
  const fileName = pendingFileName;
  const fileText = pendingFileText;
  const hasFile = !!fileName;
  if (!text && !imageDataUrl && !hasFile) return;

  if (!currentChatId) startNewChat();

  inputEl.value = '';
  inputEl.style.height = 'auto';
  sendBtn.disabled = true;

  let sendText = text;
  if (!sendText) {
    sendText = imageDataUrl ? '(kirim gambar tanpa keterangan)' : `(kirim file ${fileName} tanpa keterangan)`;
  }

  addUserTurn(sendText, imageDataUrl, hasFile ? { name: fileName } : null);
  saveTurnToChat('user', sendText);

  if (imageDataUrl) lastUserImageDataUrl = imageDataUrl;
  if (hasFile && pendingFileType.startsWith('audio/') && pendingFileDataUrl) {
    lastUserAudioDataUrl = pendingFileDataUrl;
    lastUserAudioName = fileName;
  }

  // Kalau file non-gambar bertipe teks, sisipkan isinya ke prompt yang
  // benar-benar dikirim ke model (bukan yang ditampilkan di bubble), supaya
  // model bisa "membaca" isi filenya. Untuk file biner (pdf, docx, dll) yang
  // isinya belum bisa diekstrak di sisi client, cukup beri tahu nama & tipe filenya.
  let promptForModel = sendText;
  if (hasFile) {
    if (fileText) {
      const truncNote = fileText.length >= 1500 ? ' (isi dipotong, hanya awal file)' : '';
      promptForModel += `\n\n[File terlampir: ${fileName}${truncNote}]\n---\n${fileText}\n---`;
    } else if (pendingFileType.startsWith('audio/')) {
      promptForModel += `\n\n[User melampirkan file audio: ${fileName} (${formatFileSize(pendingFileSize)}). File ini BELUM diproses/ditranskrip apa pun — kamu HARUS memanggil blok :::tool type: transcribe sekarang untuk memulai transkripsi (jangan hanya membalas dengan kata seperti "tersimpan" atau "oke" tanpa memanggil blok tool tersebut).]`;
    } else {
      promptForModel += `\n\n[User melampirkan file: ${fileName} (${pendingFileType || 'tidak diketahui tipenya'}, ${formatFileSize(pendingFileSize)}). Isi file tidak bisa dibaca otomatis — tanyakan ke user apa yang ingin dilakukan dengan file ini kalau relevan.]`;
    }
  }

  resetPendingAttachments();
  renderAttachPreview();

  const aiTurn = addAiTurnSkeleton();

  try {
    let aiRaw = await askGemini(promptForModel, imageDataUrl);

    // Hanya FicTur Chatbot & Q1 Code yang diinstruksikan menulis placeholder
    // "PEXELS:kata kunci" di kode HTML/CSS-nya — resolve jadi URL foto asli
    // sebelum diketik/dirender, supaya yang muncul ke user sudah gambar nyata.
    if (selectedModelId === 'fictur-chatbot' || selectedModelId === 'fictur-q1-code') {
      aiRaw = await resolvePexelsPlaceholders(aiRaw);
    }

    // Kode selalu langsung ditampilkan sebagai file card (tanpa animasi ketik),
    // untuk semua model — bukan hanya Q2 Code.
    await typeText(aiTurn, aiRaw, 10, 1, true);

    const imgPrompt = extractImagePrompt(aiRaw);

    // Ganti hasil ketikan mentah jadi render final (teks + code block kalau ada)
    const bubbleEl = aiTurn.querySelector('.bubble');
    renderFinalContent(bubbleEl, aiRaw);

    history.push({ role: 'user', content: sendText });
    history.push({ role: 'assistant', content: aiRaw });
    if (history.length > 20) history = history.slice(-20);

    saveTurnToChat('assistant', aiRaw);

    if (imgPrompt) {
      const plate = document.createElement('div');
      plate.className = 'plate';
      plate.innerHTML = `<div class="plate-label"><span class="dot"></span>membentuk gambar</div>`;
      aiTurn.appendChild(plate);
      scrollToBottom(false);
      await generateImage(imgPrompt, plate);
    }

  } catch (err) {
    aiTurn.querySelector('.bubble').innerHTML = `<span style="color:#b5502e;">⚠ ${err.message}</span>`;
  } finally {
    const caret = aiTurn.querySelector('.caret');
    if (caret) caret.remove();
    sendBtn.disabled = false;
  }
}

