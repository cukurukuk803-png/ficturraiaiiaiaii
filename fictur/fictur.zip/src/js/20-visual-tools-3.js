/* =========================================================================
   6 SKILL TAMBAHAN (grup kecil): kalender jadwal, flashcard, sertifikat,
   presensi visual, quiz generator, rumus ke gambar.
   ========================================================================= */

/* -------------------------------------------------------------------------
   7) KALENDER / JADWAL PELAJARAN — grid mingguan dari daftar jadwal
   params: { judul, jadwal: [{hari, jam, mapel}] }
   hari: Senin..Minggu (bebas subset)
   ------------------------------------------------------------------------- */
function parseJadwal(raw) {
  const arr = typeof raw === 'string' ? safeJsonParse(raw, 'jadwal') : raw;
  return (arr || []).map(j => ({
    hari: String(j.hari || '').trim(),
    jam: String(j.jam || '').trim(),
    mapel: String(j.mapel || '').trim()
  })).filter(j => j.hari && j.mapel);
}

function renderJadwalSVG(jadwal, judul) {
  const HARI_ORDER = ['Senin', 'Selasa', 'Rabu', 'Kamis', 'Jumat', 'Sabtu', 'Minggu'];
  const hariUnik = HARI_ORDER.filter(h => jadwal.some(j => j.hari === h));
  const jamUnik = [...new Set(jadwal.map(j => j.jam))].sort();

  const colW = 110, rowH = 50, headH = 34, labelW = 60, pad = 20;
  const svgW = labelW + hariUnik.length * colW + pad * 2;
  const svgH = headH + jamUnik.length * rowH + pad * 2 + (judul ? 24 : 0);
  const offsetY = judul ? 24 : 0;

  const byKey = {};
  jadwal.forEach(j => { byKey[j.hari + '|' + j.jam] = j.mapel; });

  let headerSvg = `<rect x="${pad}" y="${pad + offsetY}" width="${labelW}" height="${headH}" fill="#27272f"/>`;
  hariUnik.forEach((h, i) => {
    const x = pad + labelW + i * colW;
    headerSvg += `<rect x="${x}" y="${pad + offsetY}" width="${colW}" height="${headH}" fill="#27272f"/>
      <text x="${x + colW / 2}" y="${pad + offsetY + headH / 2 + 4}" text-anchor="middle" font-size="10.5" font-weight="700" fill="#7c6ae8">${escapeSvgText(h)}</text>`;
  });

  let bodySvg = '';
  jamUnik.forEach((jam, ri) => {
    const y = pad + offsetY + headH + ri * rowH;
    bodySvg += `<rect x="${pad}" y="${y}" width="${labelW}" height="${rowH}" fill="rgba(120,120,130,0.08)" stroke="rgba(120,120,130,0.18)"/>
      <text x="${pad + labelW / 2}" y="${y + rowH / 2 + 3}" text-anchor="middle" font-size="9" fill="rgba(212,212,217,0.65)">${escapeSvgText(jam)}</text>`;
    hariUnik.forEach((h, ci) => {
      const x = pad + labelW + ci * colW;
      const mapel = byKey[h + '|' + jam];
      const color = VISUAL_PALETTE[(ri + ci) % VISUAL_PALETTE.length];
      bodySvg += `<rect x="${x}" y="${y}" width="${colW}" height="${rowH}" fill="${mapel ? 'rgba(124,106,232,0.08)' : 'transparent'}" stroke="rgba(120,120,130,0.18)"/>`;
      if (mapel) {
        const lines = wrapSvgText(mapel, colW - 16);
        const startY = y + rowH / 2 - (lines.length - 1) * 6 + 4;
        const labelSvg = lines.map((l, li) => `<tspan x="${x + colW / 2}" y="${startY + li * 12}">${escapeSvgText(l)}</tspan>`).join('');
        bodySvg += `<text text-anchor="middle" font-size="9.5" font-weight="600" fill="${color}">${labelSvg}</text>`;
      }
    });
  });

  const titleSvg = judul ? `<text x="${svgW / 2}" y="16" text-anchor="middle" font-size="12" font-weight="600" fill="#f5f5f7">${escapeSvgText(judul)}</text>` : '';

  return `<svg viewBox="0 0 ${svgW} ${svgH}" width="100%" xmlns="http://www.w3.org/2000/svg" font-family="'JetBrains Mono', monospace">
    ${titleSvg}
    ${headerSvg}
    ${bodySvg}
  </svg>`;
}

async function runJadwalTool(params, wrap) {
  const jadwal = parseJadwal(params.jadwal);
  if (!jadwal.length) throw new Error('Data jadwal tidak diberikan');
  const judul = params.judul || 'Jadwal Pelajaran';
  const svgMarkup = renderJadwalSVG(jadwal, judul);
  buildVisualBox(wrap, judul, svgMarkup, 'jadwal');
}

