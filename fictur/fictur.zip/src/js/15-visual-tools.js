/* ===================== Skill: Flowchart generator (lokal, tanpa API) ===================== */

// Parse satu segmen step. Kembalikan {type:'step', text} atau {type:'branch', question, yes, no}
function parseFlowchartStep(raw) {
  const seg = raw.trim();
  const branchMatch = seg.match(/^Keputusan:\s*(.+?)\?\s*Ya:\s*(.+?)\|Tidak:\s*(.+)$/i);
  if (branchMatch) {
    return { type: 'branch', question: branchMatch[1].trim(), yes: branchMatch[2].trim(), no: branchMatch[3].trim() };
  }
  return { type: 'step', text: seg };
}

// Bangun model node dari string "steps" mentah (dipisah |, tapi percabangan sendiri
// juga memakai | di dalamnya untuk Ya/Tidak — makanya branch di-detect dulu per token
// gabungan "Keputusan: ...?Ya:...|Tidak:..." sebelum split umum).
function parseFlowchartSteps(rawSteps) {
  // Gabungkan dulu token yang merupakan bagian dari satu blok Keputusan (karena
  // "Ya:...|Tidak:..." ikut kena split |). Deteksi lewat kemunculan "Keputusan:" tanpa
  // "Tidak:" pada token yang sama -> gabung dengan token berikutnya.
  const rawTokens = rawSteps.split('|').map(s => s.trim()).filter(Boolean);
  const merged = [];
  for (let i = 0; i < rawTokens.length; i++) {
    const t = rawTokens[i];
    if (/^Keputusan:/i.test(t) && !/Tidak:/i.test(t) && i + 1 < rawTokens.length) {
      merged.push(t + '|' + rawTokens[i + 1]);
      i++;
    } else {
      merged.push(t);
    }
  }
  return merged.map(parseFlowchartStep);
}

// Render flowchart jadi SVG murni. model: 'vertikal' | 'horizontal' | 'percabangan' | 'siklus'
function renderFlowchartSVG(steps, model, judul) {
  const isHorizontal = model === 'horizontal';
  const isSiklus = model === 'siklus';
  const boxW = isHorizontal ? 150 : 220;
  const boxH = 50;
  const gap = isHorizontal ? 60 : 42;
  const branchGap = 34;
  const pad = 30;

  // Hitung posisi tiap node secara sekuensial, expand jadi 2 kolom saat branch.
  const nodes = []; // {x,y,w,h,text,kind}
  const edges = []; // {x1,y1,x2,y2,label}
  let cursor = 0; // posisi sumbu utama (y untuk vertikal, x untuk horizontal)
  let mainAxisSize = 0;
  let crossAxisSize = boxW;

  function place(text, kind, crossOffset) {
    const w = boxW, h = boxH;
    let x, y;
    if (isHorizontal) {
      x = pad + cursor; y = pad + (crossOffset || 0);
    } else {
      x = pad + (crossOffset || 0); y = pad + cursor;
    }
    const n = { x, y, w, h, text, kind };
    nodes.push(n);
    return n;
  }

  let prevNode = null;
  let prevBranchExit = null; // {yes:node, no:node} kalau step sebelumnya branch

  steps.forEach((step, idx) => {
    if (step.type === 'step') {
      const n = place(step.text, 'process', 0);
      if (prevBranchExit) {
        edges.push(connectEdge(prevBranchExit.yes, n, 'Ya', isHorizontal));
        edges.push(connectEdge(prevBranchExit.no, n, 'Tidak', isHorizontal));
        prevBranchExit = null;
      } else if (prevNode) {
        edges.push(connectEdge(prevNode, n, '', isHorizontal));
      }
      prevNode = n;
      cursor += (isHorizontal ? boxW : boxH) + gap;
    } else if (step.type === 'branch') {
      const q = place(step.question, 'decision', 0);
      if (prevBranchExit) {
        edges.push(connectEdge(prevBranchExit.yes, q, 'Ya', isHorizontal));
        edges.push(connectEdge(prevBranchExit.no, q, 'Tidak', isHorizontal));
        prevBranchExit = null;
      } else if (prevNode) {
        edges.push(connectEdge(prevNode, q, '', isHorizontal));
      }
      cursor += (isHorizontal ? boxW : boxH) + gap;
      const offset = (isHorizontal ? boxH : boxW) / 2 + branchGap / 2 + boxW / 2;
      const yesNode = place(step.yes, 'process', -offset);
      const noNode = place(step.no, 'process', offset);
      edges.push(connectEdge(q, yesNode, 'Ya', isHorizontal));
      edges.push(connectEdge(q, noNode, 'Tidak', isHorizontal));
      cursor += (isHorizontal ? boxW : boxH) + gap;
      prevBranchExit = { yes: yesNode, no: noNode };
      prevNode = null;
      crossAxisSize = Math.max(crossAxisSize, boxW * 2 + branchGap + boxW);
    }
  });

  // Kalau step terakhir adalah branch tanpa penutup, tetap perlu penampung akhir kosong agar rapi.
  mainAxisSize = cursor - gap;

  // Normalisasi offset cross-axis (karena bisa negatif) supaya semua node berada dalam viewBox positif.
  const crossValues = nodes.map(n => isHorizontal ? n.y : n.x);
  const minCross = Math.min(...crossValues);
  const shift = minCross < pad ? (pad - minCross) : 0;
  nodes.forEach(n => { if (isHorizontal) n.y += shift; else n.x += shift; });
  edges.forEach(e => { if (isHorizontal) { e.y1 += shift; e.y2 += shift; } else { e.x1 += shift; e.x2 += shift; } });

  const maxCross = Math.max(...nodes.map(n => (isHorizontal ? n.y + n.h : n.x + n.w)));
  const svgW = isHorizontal ? mainAxisSize + pad * 2 : Math.max(maxCross + pad, boxW + pad * 2);
  const svgH = isHorizontal ? Math.max(maxCross + pad, boxH + pad * 2) : mainAxisSize + pad * 2;

  // Loop kembali (siklus): tambahkan panah dari node terakhir ke node pertama.
  let loopPath = '';
  if (isSiklus && nodes.length > 1) {
    const first = nodes[0], last = nodes[nodes.length - 1];
    const loopOffset = 26;
    if (isHorizontal) {
      const y1 = last.y + last.h, y2 = first.y + first.h;
      const yBottom = Math.max(y1, y2) + loopOffset;
      loopPath = `<path d="M${last.x + last.w / 2},${last.y + last.h} L${last.x + last.w / 2},${yBottom} L${first.x + first.w / 2},${yBottom} L${first.x + first.w / 2},${first.y + first.h}" fill="none" stroke="#7c6ae8" stroke-width="2" stroke-dasharray="5,4" marker-end="url(#fc-arrow-loop)"/>`;
    } else {
      const x1 = last.x + last.w, x2 = first.x + first.w;
      const xRight = Math.max(x1, x2) + loopOffset;
      loopPath = `<path d="M${last.x + last.w},${last.y + last.h / 2} L${xRight},${last.y + last.h / 2} L${xRight},${first.y + first.h / 2} L${first.x + first.w},${first.y + first.h / 2}" fill="none" stroke="#7c6ae8" stroke-width="2" stroke-dasharray="5,4" marker-end="url(#fc-arrow-loop)"/>`;
    }
  }
  const finalW = isSiklus ? svgW + (isHorizontal ? 0 : 50) : svgW;
  const finalH = isSiklus ? svgH + (isHorizontal ? 50 : 0) : svgH;

  const nodesSvg = nodes.map(n => nodeToSvg(n)).join('');
  const edgesSvg = edges.map(e => edgeToSvg(e)).join('');

  return `<svg viewBox="0 0 ${Math.round(finalW)} ${Math.round(finalH)}" width="100%" xmlns="http://www.w3.org/2000/svg" font-family="'JetBrains Mono', monospace">
    <defs>
      <marker id="fc-arrow" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="6" markerHeight="6" orient="auto-start-reverse">
        <path d="M0 0L10 5L0 10z" fill="#7c6ae8"/>
      </marker>
      <marker id="fc-arrow-loop" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="6" markerHeight="6" orient="auto-start-reverse">
        <path d="M0 0L10 5L0 10z" fill="#7c6ae8"/>
      </marker>
    </defs>
    ${edgesSvg}
    ${loopPath}
    ${nodesSvg}
  </svg>`;
}

function connectEdge(from, to, label, isHorizontal) {
  let x1, y1, x2, y2;
  if (isHorizontal) {
    x1 = from.x + from.w; y1 = from.y + from.h / 2;
    x2 = to.x; y2 = to.y + to.h / 2;
  } else {
    x1 = from.x + from.w / 2; y1 = from.y + from.h;
    x2 = to.x + to.w / 2; y2 = to.y;
  }
  return { x1, y1, x2, y2, label: label || '' };
}

function edgeToSvg(e) {
  const midX = (e.x1 + e.x2) / 2, midY = (e.y1 + e.y2) / 2;
  let pathD;
  if (Math.abs(e.x1 - e.x2) < 1 || Math.abs(e.y1 - e.y2) < 1) {
    pathD = `M${e.x1},${e.y1} L${e.x2},${e.y2}`;
  } else {
    // belokan siku sederhana (L-shape) supaya tidak diagonal aneh saat cabang
    const bendY = e.y1 + (e.y2 - e.y1) * 0.5;
    if (Math.abs(e.y2 - e.y1) > Math.abs(e.x2 - e.x1) * 0.3) {
      pathD = `M${e.x1},${e.y1} L${e.x1},${bendY} L${e.x2},${bendY} L${e.x2},${e.y2}`;
    } else {
      const bendX = e.x1 + (e.x2 - e.x1) * 0.5;
      pathD = `M${e.x1},${e.y1} L${bendX},${e.y1} L${bendX},${e.y2} L${e.x2},${e.y2}`;
    }
  }
  const labelSvg = e.label
    ? `<rect x="${midX - e.label.length * 3.2 - 5}" y="${midY - 9}" width="${e.label.length * 6.4 + 10}" height="16" rx="3" fill="#27272f"/>
       <text x="${midX}" y="${midY + 3}" text-anchor="middle" font-size="10" fill="${e.label === 'Ya' ? '#0f9d63' : e.label === 'Tidak' ? '#d97706' : '#d4d4d9'}">${escapeSvgText(e.label)}</text>`
    : '';
  return `<path d="${pathD}" fill="none" stroke="#5b5580" stroke-width="1.6" marker-end="url(#fc-arrow)"/>${labelSvg}`;
}

function nodeToSvg(n) {
  const fill = n.kind === 'decision' ? '#d97706' : '#0f9d63';
  const textColor = '#14141a';
  const lines = wrapSvgText(n.text, n.w - 20);
  const lh = 13;
  const startY = n.y + n.h / 2 - (lines.length - 1) * lh / 2 + 4;
  const tspans = lines.map((l, i) => `<tspan x="${n.x + n.w / 2}" y="${startY + i * lh}">${escapeSvgText(l)}</tspan>`).join('');
  let shape;
  if (n.kind === 'decision') {
    const cx = n.x + n.w / 2, cy = n.y + n.h / 2, w2 = n.w / 2, h2 = n.h / 2;
    shape = `<polygon points="${cx},${n.y} ${n.x + n.w},${cy} ${cx},${n.y + n.h} ${n.x},${cy}" fill="${fill}" stroke="#b45309" stroke-width="1.6"/>`;
  } else {
    shape = `<rect x="${n.x}" y="${n.y}" width="${n.w}" height="${n.h}" rx="8" fill="${fill}" stroke="#2f8a78" stroke-width="1.6"/>`;
  }
  return `<g>${shape}<text text-anchor="middle" font-size="11" font-weight="600" fill="${textColor}" font-family="'JetBrains Mono', monospace">${tspans}</text></g>`;
}

function wrapSvgText(text, maxWidth) {
  const words = String(text).split(' ');
  const lines = []; let cur = '';
  const charW = 6.4;
  words.forEach(w => {
    const test = cur ? cur + ' ' + w : w;
    if (test.length * charW > maxWidth && cur) { lines.push(cur); cur = w; }
    else cur = test;
  });
  if (cur) lines.push(cur);
  return lines.slice(0, 3);
}

function escapeSvgText(s) {
  return String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
}

async function runFlowchartTool(params, wrap) {
  const rawSteps = params.steps;
  if (!rawSteps) throw new Error('Langkah flowchart tidak diberikan');
  const model = (params.model || 'vertikal').toLowerCase();
  const judul = params.judul || '';

  const steps = parseFlowchartSteps(rawSteps);
  if (!steps.length) throw new Error('Gagal membaca langkah flowchart');

  const svgMarkup = renderFlowchartSVG(steps, model, judul);

  wrap.innerHTML = '';
  const box = document.createElement('div');
  box.className = 'tool-flowchart';
  if (judul) {
    const title = document.createElement('div');
    title.style.cssText = 'font-size:0.72rem; letter-spacing:0.04em; text-transform:uppercase; color:rgba(212,212,217,0.55); margin-bottom:8px;';
    title.textContent = judul;
    box.appendChild(title);
  }
  const svgHolder = document.createElement('div');
  svgHolder.innerHTML = svgMarkup;
  box.appendChild(svgHolder);

  const actions = document.createElement('div');
  actions.className = 'tool-flowchart-actions';

  const svgString = svgHolder.innerHTML;

  const dlSvgBtn = document.createElement('button');
  dlSvgBtn.textContent = '⬇ SVG';
  dlSvgBtn.addEventListener('click', () => {
    const blob = new Blob([svgString], { type: 'image/svg+xml' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url; a.download = `flowchart-${Date.now()}.svg`; a.click();
    URL.revokeObjectURL(url);
  });

  const dlPngBtn = document.createElement('button');
  dlPngBtn.textContent = '⬇ PNG';
  dlPngBtn.addEventListener('click', () => {
    const svgEl = svgHolder.querySelector('svg');
    const vb = svgEl.getAttribute('viewBox').split(' ').map(Number);
    const scale = 2;
    const svgBlob = new Blob([svgString], { type: 'image/svg+xml;charset=utf-8' });
    const url = URL.createObjectURL(svgBlob);
    const img = new Image();
    img.onload = () => {
      const canvas = document.createElement('canvas');
      canvas.width = vb[2] * scale; canvas.height = vb[3] * scale;
      const ctx = canvas.getContext('2d');
      ctx.fillStyle = '#14141a';
      ctx.fillRect(0, 0, canvas.width, canvas.height);
      ctx.scale(scale, scale);
      ctx.drawImage(img, 0, 0);
      canvas.toBlob(blob => {
        const a = document.createElement('a');
        a.href = URL.createObjectURL(blob);
        a.download = `flowchart-${Date.now()}.png`;
        a.click();
      });
      URL.revokeObjectURL(url);
    };
    img.src = url;
  });

  const modelBtn = document.createElement('button');
  const otherModels = ['vertikal', 'horizontal', 'siklus'].filter(m => m !== model);
  modelBtn.textContent = `↻ Coba ${otherModels[0]}`;
  modelBtn.addEventListener('click', () => {
    wrap.innerHTML = '';
    const loading = document.createElement('div');
    loading.className = 'tool-loading';
    loading.innerHTML = `<span class="dot"></span><span>Menggambar ulang...</span>`;
    wrap.appendChild(loading);
    setTimeout(() => {
      runFlowchartTool({ steps: rawSteps, model: otherModels[0], judul }, wrap).catch(err => {
        wrap.innerHTML = `<div class="tool-error">⚠ Gagal memuat: ${err.message}</div>`;
      });
    }, 150);
  });

  actions.appendChild(dlSvgBtn);
  actions.appendChild(dlPngBtn);
  actions.appendChild(modelBtn);
  box.appendChild(actions);
  wrap.appendChild(box);
}

