// Bangun blok pertanyaan pilihan ganda interaktif. Klik salah satu opsi, atau isi
// jawaban sendiri di kotak bawah, sama-sama mengirim jawaban itu sebagai pesan user.
function buildQuiz(question, options) {
  const block = document.createElement('div');
  block.className = 'quiz-block';

  const q = document.createElement('div');
  q.className = 'quiz-question';
  renderInlineMarkdown(q, question);
  block.appendChild(q);

  const optsWrap = document.createElement('div');
  optsWrap.className = 'quiz-options';

  function pickAnswer(answerText, btnEl) {
    if (block.classList.contains('answered')) return;
    block.classList.add('answered');
    if (btnEl) btnEl.classList.add('picked');
    inputEl.value = answerText;
    handleSend();
  }

  options.forEach(optText => {
    const btn = document.createElement('button');
    btn.type = 'button';
    btn.className = 'quiz-opt';
    btn.textContent = optText;
    btn.addEventListener('click', () => pickAnswer(optText, btn));
    optsWrap.appendChild(btn);
  });
  block.appendChild(optsWrap);

  const customRow = document.createElement('div');
  customRow.className = 'quiz-custom';
  const customInput = document.createElement('input');
  customInput.type = 'text';
  customInput.placeholder = 'Atau tulis jawabanmu sendiri...';
  const customBtn = document.createElement('button');
  customBtn.type = 'button';
  customBtn.textContent = 'Kirim';
  function submitCustom() {
    const val = customInput.value.trim();
    if (!val) return;
    pickAnswer(val, null);
  }
  customBtn.addEventListener('click', submitCustom);
  customInput.addEventListener('keydown', (e) => {
    if (e.key === 'Enter') { e.preventDefault(); submitCustom(); }
  });
  customRow.appendChild(customInput);
  customRow.appendChild(customBtn);
  block.appendChild(customRow);

  return block;
}

