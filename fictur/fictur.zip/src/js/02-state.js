let history = [];
let conversationId = crypto.randomUUID();

/* ===================== Penyimpanan riwayat obrolan (permanen via localStorage) ===================== */
const STORAGE_KEY = 'fictur_chats_v1';
let allChats = loadAllChats();
let currentChatId = null;

