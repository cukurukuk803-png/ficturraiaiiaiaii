const PREVIEWABLE_LANGS = new Set(['html', 'svg']);


function resolveFilename(lang, filename) {
  // Nama file dari AI dianggap otoritatif kalau ada; fallback pakai ekstensi bahasa.
  if (filename) return filename;
  const ext = EXT_BY_LANG[lang] || 'txt';
  return `fictur-code.${ext}`;
}

function openCodePreview(lang, code, filename) {
  const overlay = document.createElement('div');
  overlay.className = 'preview-overlay';

  function closeOverlay(){
    overlay.classList.add('closing');
    setTimeout(() => overlay.remove(), 200);
  }

  const panel = document.createElement('div');
  panel.className = 'preview-panel';

  const bar = document.createElement('div');
  bar.className = 'preview-bar';
  const title = document.createElement('span');
  title.className = 'preview-title';
  title.textContent = filename || 'preview';
  const closeBtn = document.createElement('button');
  closeBtn.className = 'preview-close';
  closeBtn.textContent = '✕ Tutup';
  closeBtn.addEventListener('click', () => closeOverlay());
  bar.appendChild(title);
  bar.appendChild(closeBtn);

  const frame = document.createElement('iframe');
  frame.className = 'preview-frame';
  frame.sandbox = 'allow-scripts allow-forms allow-modals allow-popups';

  let srcdoc = code;
  if (lang === 'svg') {
    srcdoc = `<!DOCTYPE html><html><head><style>html,body{margin:0;height:100%;display:flex;align-items:center;justify-content:center;background:#fff;}</style></head><body>${code}</body></html>`;
  }
  frame.srcdoc = srcdoc;

  panel.appendChild(bar);
  panel.appendChild(frame);
  overlay.appendChild(panel);

  overlay.addEventListener('click', (e) => {
    if (e.target === overlay) closeOverlay();
  });

  document.body.appendChild(overlay);
}

// Kartu file ringkas: dipakai untuk semua kode dari AI (semua model) sebagai
// pengganti buildCodebox — isi kode TIDAK ditampilkan sebagai teks di layar,
// cukup nama file + ukuran + tombol buka(preview)/download, seolah kode itu
// langsung "jadi file" alih-alih diketik/ditampilkan mentah di chat.
function buildFileCard(lang, code, filename) {
  const card = document.createElement('div');
  card.className = 'filecard';

  const resolvedName = resolveFilename(lang, filename);
  const ext = (EXT_BY_LANG[lang] || lang || 'txt').toUpperCase();
  const sizeBytes = new Blob([code]).size;

  const icon = document.createElement('div');
  icon.className = 'fc-icon';
  icon.textContent = ext.length > 4 ? ext.slice(0, 4) : ext;

  const info = document.createElement('div');
  info.className = 'fc-info';
  const nameEl = document.createElement('div');
  nameEl.className = 'fc-name';
  nameEl.textContent = resolvedName;
  const metaEl = document.createElement('div');
  metaEl.className = 'fc-meta';
  metaEl.textContent = `${ext} · ${formatFileSize(sizeBytes)}`;
  info.appendChild(nameEl);
  info.appendChild(metaEl);

  const actions = document.createElement('div');
  actions.className = 'fc-actions';

  if (PREVIEWABLE_LANGS.has(lang)) {
    const openBtn = document.createElement('button');
    openBtn.className = 'fc-btn fc-open';
    openBtn.textContent = '▶ Buka';
    openBtn.addEventListener('click', () => openCodePreview(lang, code, resolvedName));
    actions.appendChild(openBtn);
  } else {
    const viewBtn = document.createElement('button');
    viewBtn.className = 'fc-btn fc-open';
    viewBtn.textContent = '👁 Lihat';
    viewBtn.addEventListener('click', () => {
      const blob = new Blob([code], { type: 'text/plain' });
      const url = URL.createObjectURL(blob);
      window.open(url, '_blank');
      setTimeout(() => URL.revokeObjectURL(url), 60000);
    });
    actions.appendChild(viewBtn);
  }

  const dlBtn = document.createElement('button');
  dlBtn.className = 'fc-btn';
  dlBtn.textContent = '⬇ Download';
  dlBtn.addEventListener('click', () => {
    const blob = new Blob([code], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = resolvedName;
    a.click();
    URL.revokeObjectURL(url);
  });
  actions.appendChild(dlBtn);

  card.appendChild(icon);
  card.appendChild(info);
  card.appendChild(actions);
  return card;
}

function buildCodebox(lang, code, filename) {
  const box = document.createElement('div');
  box.className = 'codebox';

  const resolvedName = resolveFilename(lang, filename);

  const head = document.createElement('div');
  head.className = 'cb-head';

  const headLeft = document.createElement('div');
  headLeft.className = 'cb-head-left';
  const langLabel = document.createElement('span');
  langLabel.className = 'cb-lang';
  langLabel.textContent = lang || 'text';
  const fileLabel = document.createElement('span');
  fileLabel.className = 'cb-filename';
  fileLabel.textContent = resolvedName;
  headLeft.appendChild(langLabel);
  headLeft.appendChild(fileLabel);

  const actions = document.createElement('div');
  actions.className = 'cb-actions';

  if (PREVIEWABLE_LANGS.has(lang)) {
    const previewBtn = document.createElement('button');
    previewBtn.className = 'cb-preview';
    previewBtn.textContent = '▶ Preview';
    previewBtn.addEventListener('click', () => openCodePreview(lang, code, resolvedName));
    actions.appendChild(previewBtn);
  }

  const copyBtn = document.createElement('button');
  copyBtn.className = 'cb-copy';
  copyBtn.textContent = 'Salin';
  copyBtn.addEventListener('click', async () => {
    try {
      await navigator.clipboard.writeText(code);
      copyBtn.textContent = 'Tersalin ✓';
      copyBtn.classList.add('copied');
      setTimeout(() => { copyBtn.textContent = 'Salin'; copyBtn.classList.remove('copied'); }, 1500);
    } catch (_) {
      copyBtn.textContent = 'Gagal';
      setTimeout(() => { copyBtn.textContent = 'Salin'; }, 1500);
    }
  });

  const dlBtn = document.createElement('button');
  dlBtn.className = 'cb-dl';
  dlBtn.textContent = '⬇ File';
  dlBtn.addEventListener('click', () => {
    const blob = new Blob([code], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = resolvedName;
    a.click();
    URL.revokeObjectURL(url);
  });

  actions.appendChild(copyBtn);
  actions.appendChild(dlBtn);
  head.appendChild(headLeft);
  head.appendChild(actions);

  const pre = document.createElement('pre');
  const codeEl = document.createElement('code');
  codeEl.innerHTML = escapeHtml(code);
  pre.appendChild(codeEl);

  box.appendChild(head);
  box.appendChild(pre);
  box.appendChild(buildCodeFooterActions(lang, code, resolvedName));
  return box;
}

const ICON_SVG = {
  copy: '<svg xmlns="http://www.w3.org/2000/svg" width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="9" y="9" width="13" height="13" rx="2"/><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/></svg>',
  share: '<svg xmlns="http://www.w3.org/2000/svg" width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 12v8a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-8"/><polyline points="16 6 12 2 8 6"/><line x1="12" y1="2" x2="12" y2="15"/></svg>',
  play: '<svg xmlns="http://www.w3.org/2000/svg" width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polygon points="6 3 20 12 6 21 6 3"/></svg>',
  thumbUp: '<svg xmlns="http://www.w3.org/2000/svg" width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M7 10v12"/><path d="M15 5.88 14 10h5.83a2 2 0 0 1 1.92 2.56l-2.33 8A2 2 0 0 1 17.5 22H4a2 2 0 0 1-2-2v-8a2 2 0 0 1 2-2h2.76a2 2 0 0 0 1.79-1.11L12 2h0a3.13 3.13 0 0 1 3 3.88Z"/></svg>',
  thumbDown: '<svg xmlns="http://www.w3.org/2000/svg" width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M17 14V2"/><path d="M9 18.12 10 14H4.17a2 2 0 0 1-1.92-2.56l2.33-8A2 2 0 0 1 6.5 2H20a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2h-2.76a2 2 0 0 0-1.79 1.11L12 22h0a3.13 3.13 0 0 1-3-3.88Z"/></svg>',
  refresh: '<svg xmlns="http://www.w3.org/2000/svg" width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 12a9 9 0 0 1 9-9 9.75 9.75 0 0 1 6.74 2.74L21 8"/><path d="M21 3v5h-5"/><path d="M21 12a9 9 0 0 1-9 9 9.75 9.75 0 0 1-6.74-2.74L3 16"/><path d="M8 16H3v5"/></svg>',
  check: '<svg xmlns="http://www.w3.org/2000/svg" width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"/></svg>'
};

// Baris aksi di bawah codebox: duplikat/salin, bagikan, jalankan/preview, suka, tidak suka, ulangi
function buildCodeFooterActions(lang, code, resolvedName){
  const row = document.createElement('div');
  row.className = 'cb-footer-actions';

  function makeBtn(key, title, onClick){
    const b = document.createElement('button');
    b.className = 'cb-fa-btn';
    b.title = title;
    b.innerHTML = ICON_SVG[key];
    if (onClick) b.addEventListener('click', onClick);
    return b;
  }

  const copyBtn2 = makeBtn('copy', 'Salin kode', async () => {
    try {
      await navigator.clipboard.writeText(code);
      copyBtn2.innerHTML = ICON_SVG.check;
      copyBtn2.classList.add('cb-fa-active');
      setTimeout(() => { copyBtn2.innerHTML = ICON_SVG.copy; copyBtn2.classList.remove('cb-fa-active'); }, 1200);
    } catch(_) {}
  });

  const shareBtn = makeBtn('share', 'Bagikan', async () => {
    try {
      if (navigator.share) {
        await navigator.share({ title: resolvedName, text: code });
      } else {
        await navigator.clipboard.writeText(code);
      }
    } catch(_) {}
  });

  row.appendChild(copyBtn2);
  row.appendChild(shareBtn);

  if (PREVIEWABLE_LANGS.has(lang)) {
    row.appendChild(makeBtn('play', 'Jalankan / Preview', () => openCodePreview(lang, code, resolvedName)));
  }

  const likeBtn = makeBtn('thumbUp', 'Suka', () => {
    likeBtn.classList.toggle('cb-fa-active');
    dislikeBtn.classList.remove('cb-fa-active');
  });
  const dislikeBtn = makeBtn('thumbDown', 'Tidak suka', () => {
    dislikeBtn.classList.toggle('cb-fa-active');
    likeBtn.classList.remove('cb-fa-active');
  });
  row.appendChild(likeBtn);
  row.appendChild(dislikeBtn);

  row.appendChild(makeBtn('refresh', 'Buat ulang', (e) => {
    const b = e.currentTarget;
    b.classList.add('cb-fa-spin');
    setTimeout(() => b.classList.remove('cb-fa-spin'), 500);
  }));

  return row;
}

// Render teks final (setelah typing selesai) jadi campuran teks biasa + codebox
function renderFinalContent(bubbleEl, rawText) {
  const segments = splitTextAndCode(rawText);
  bubbleEl.innerHTML = '';
  segments.forEach(seg => {
    if (seg.type === 'text') {
      if (seg.content.trim() === '') return;
      const wrap = document.createElement('div');
      wrap.className = 'md-block';
      renderInlineMarkdown(wrap, seg.content.replace(/^\n+|\n+$/g, ''));
      bubbleEl.appendChild(wrap);
    } else if (seg.type === 'table') {
      bubbleEl.appendChild(buildTable(seg.headers, seg.rows));
    } else if (seg.type === 'quiz') {
      bubbleEl.appendChild(buildQuiz(seg.question, seg.options));
    } else if (seg.type === 'tool') {
      bubbleEl.appendChild(buildToolBlock(seg.toolType, seg.params));
    } else {
      bubbleEl.appendChild(buildFileCard(seg.lang, seg.content, seg.filename));
    }
  });
}

// Render turn user statis (dari riwayat tersimpan, tanpa animasi)
function renderStaticUserTurn(text) {
  const es = document.getElementById('emptyState');
  if (es) es.remove();
  const turn = document.createElement('div');
  turn.className = 'turn user';
  turn.innerHTML = `<div class="who">kamu</div><div class="bubble"></div>`;
  turn.querySelector('.bubble').textContent = text;
  chatEl.appendChild(turn);
}

// Render turn AI statis (dari riwayat tersimpan) — termasuk gambar kalau ada
function renderStaticAiTurn(text) {
  const turn = document.createElement('div');
  turn.className = 'turn ai';
  turn.innerHTML = `<div class="who">fictur</div><div class="bubble"></div>`;
  const bubble = turn.querySelector('.bubble');
  const imgPrompt = extractImagePrompt(text);
  const displayText = imgPrompt ? text : text;
  renderFinalContent(bubble, displayText);
  chatEl.appendChild(turn);
  return turn;
}

