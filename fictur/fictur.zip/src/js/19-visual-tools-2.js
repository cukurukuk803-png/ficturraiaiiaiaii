/* =========================================================================
   HELPER GENERIK untuk 6 skill visual baru (rapor, orgchart, mindmap,
   conceptmap, peta belajar, statistik). Semua pakai palet warna & pola
   yang sama dengan flowchart supaya konsisten.
   ========================================================================= */

// Bikin box .tool-visual standar berisi judul + svg + tombol unduh SVG/PNG.
// extraButtons: array {label, onClick} opsional (mis. tombol ganti model).
function buildVisualBox(wrap, judul, svgMarkup, filenamePrefix, extraButtons) {
  wrap.innerHTML = '';
  const box = document.createElement('div');
  box.className = 'tool-visual';
  if (judul) {
    const title = document.createElement('div');
    title.className = 'tool-visual-title';
    title.textContent = judul;
    box.appendChild(title);
  }
  const svgHolder = document.createElement('div');
  svgHolder.innerHTML = svgMarkup;
  box.appendChild(svgHolder);

  const actions = document.createElement('div');
  actions.className = 'tool-visual-actions';
  const svgString = svgHolder.innerHTML;

  const dlSvgBtn = document.createElement('button');
  dlSvgBtn.textContent = '⬇ SVG';
  dlSvgBtn.addEventListener('click', () => {
    const blob = new Blob([svgString], { type: 'image/svg+xml' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url; a.download = `${filenamePrefix}-${Date.now()}.svg`; a.click();
    URL.revokeObjectURL(url);
  });

  const dlPngBtn = document.createElement('button');
  dlPngBtn.textContent = '⬇ PNG';
  dlPngBtn.addEventListener('click', () => {
    const svgEl = svgHolder.querySelector('svg');
    const vb = svgEl.getAttribute('viewBox').split(' ').map(Number);
    const scale = 2;
    const svgBlob = new Blob([svgString], { type: 'image/svg+xml;charset=utf-8' });
    const url = URL.createObjectURL(svgBlob);
    const img = new Image();
    img.onload = () => {
      const canvas = document.createElement('canvas');
      canvas.width = vb[2] * scale; canvas.height = vb[3] * scale;
      const ctx = canvas.getContext('2d');
      ctx.fillStyle = '#14141a';
      ctx.fillRect(0, 0, canvas.width, canvas.height);
      ctx.scale(scale, scale);
      ctx.drawImage(img, 0, 0);
      canvas.toBlob(blob => {
        const a = document.createElement('a');
        a.href = URL.createObjectURL(blob);
        a.download = `${filenamePrefix}-${Date.now()}.png`;
        a.click();
      });
      URL.revokeObjectURL(url);
    };
    img.src = url;
  });

  actions.appendChild(dlSvgBtn);
  actions.appendChild(dlPngBtn);
  (extraButtons || []).forEach(eb => {
    const btn = document.createElement('button');
    btn.textContent = eb.label;
    btn.addEventListener('click', eb.onClick);
    actions.appendChild(btn);
  });
  box.appendChild(actions);
  wrap.appendChild(box);
  return box;
}

const VISUAL_PALETTE = ['#0f9d63', '#d97706', '#7c6ae8', '#e0524f', '#2563eb', '#d97706'];

/* -------------------------------------------------------------------------
   1) RAPOR / NILAI VISUAL — grafik bar + radar dari daftar mapel & nilai
   params: { nama, kelas, mapel: [{nama, nilai(0-100)}], model: 'bar'|'radar' }
   ------------------------------------------------------------------------- */
function parseRaporMapel(raw) {
  if (Array.isArray(raw)) {
    return raw.map(m => ({
      nama: String(m.nama || m.mapel || '').trim(),
      nilai: Math.max(0, Math.min(100, Number(m.nilai) || 0))
    })).filter(m => m.nama);
  }
  // fallback string "Matematika:85, IPA:90"
  return String(raw).split(/[,\n]/).map(line => {
    const [nama, nilai] = line.split(':').map(s => (s || '').trim());
    return { nama, nilai: Math.max(0, Math.min(100, Number(nilai) || 0)) };
  }).filter(m => m.nama);
}

function renderRaporBarSVG(mapel, nama, kelas) {
  const padL = 40, padB = 70, padT = 30, padR = 20;
  const barW = 46, gap = 26;
  const chartH = 260;
  const chartW = mapel.length * (barW + gap) + gap;
  const svgW = chartW + padL + padR;
  const svgH = chartH + padT + padB;

  const bars = mapel.map((m, i) => {
    const x = padL + gap + i * (barW + gap);
    const h = (m.nilai / 100) * chartH;
    const y = padT + (chartH - h);
    const color = m.nilai >= 75 ? '#0f9d63' : m.nilai >= 60 ? '#d97706' : '#e0524f';
    const labelLines = wrapSvgText(m.nama, barW + 24);
    const labelSvg = labelLines.map((l, li) => `<tspan x="${x + barW / 2}" y="${padT + chartH + 18 + li * 12}">${escapeSvgText(l)}</tspan>`).join('');
    return `<rect x="${x}" y="${y}" width="${barW}" height="${h}" rx="4" fill="${color}" stroke="${color}" stroke-width="1"/>
      <text x="${x + barW / 2}" y="${y - 6}" text-anchor="middle" font-size="11" font-weight="600" fill="#d4d4d9">${m.nilai}</text>
      <text text-anchor="middle" font-size="9" fill="rgba(212,212,217,0.65)">${labelSvg}</text>`;
  }).join('');

  const gridLines = [0, 25, 50, 75, 100].map(v => {
    const y = padT + chartH - (v / 100) * chartH;
    return `<line x1="${padL}" y1="${y}" x2="${padL + chartW}" y2="${y}" stroke="rgba(120,120,130,0.18)" stroke-width="1"/>
      <text x="${padL - 8}" y="${y + 3}" text-anchor="end" font-size="9" fill="rgba(212,212,217,0.5)">${v}</text>`;
  }).join('');

  const judulTxt = `${nama || 'Rapor'}${kelas ? ' — ' + kelas : ''}`;

  return `<svg viewBox="0 0 ${svgW} ${svgH}" width="100%" xmlns="http://www.w3.org/2000/svg" font-family="'JetBrains Mono', monospace">
    <text x="${svgW / 2}" y="16" text-anchor="middle" font-size="12" font-weight="600" fill="#f5f5f7">${escapeSvgText(judulTxt)}</text>
    ${gridLines}
    ${bars}
    <line x1="${padL}" y1="${padT + chartH}" x2="${padL + chartW}" y2="${padT + chartH}" stroke="rgba(212,212,217,0.35)" stroke-width="1.4"/>
  </svg>`;
}

function renderRaporRadarSVG(mapel, nama, kelas) {
  const size = 320, cx = size / 2, cy = size / 2 + 6, R = 110;
  const n = mapel.length;
  const angleStep = (Math.PI * 2) / n;
  const levels = [0.25, 0.5, 0.75, 1];

  function pointAt(i, ratio) {
    const angle = -Math.PI / 2 + i * angleStep;
    return { x: cx + Math.cos(angle) * R * ratio, y: cy + Math.sin(angle) * R * ratio };
  }

  const gridPolys = levels.map(lv => {
    const pts = mapel.map((_, i) => { const p = pointAt(i, lv); return `${p.x},${p.y}`; }).join(' ');
    return `<polygon points="${pts}" fill="none" stroke="rgba(120,120,130,0.2)" stroke-width="1"/>`;
  }).join('');

  const axisLines = mapel.map((_, i) => {
    const p = pointAt(i, 1);
    return `<line x1="${cx}" y1="${cy}" x2="${p.x}" y2="${p.y}" stroke="rgba(120,120,130,0.2)" stroke-width="1"/>`;
  }).join('');

  const dataPts = mapel.map((m, i) => pointAt(i, m.nilai / 100));
  const dataPoly = dataPts.map(p => `${p.x},${p.y}`).join(' ');

  const labels = mapel.map((m, i) => {
    const p = pointAt(i, 1.22);
    const anchor = Math.abs(p.x - cx) < 4 ? 'middle' : (p.x > cx ? 'start' : 'end');
    return `<text x="${p.x}" y="${p.y + 3}" text-anchor="${anchor}" font-size="9" fill="rgba(212,212,217,0.7)">${escapeSvgText(m.nama)}</text>`;
  }).join('');

  const dots = dataPts.map((p, i) => `<circle cx="${p.x}" cy="${p.y}" r="3" fill="#7c6ae8"/>`).join('');
  const judulTxt = `${nama || 'Rapor'}${kelas ? ' — ' + kelas : ''}`;

  return `<svg viewBox="0 0 ${size} ${size + 20}" width="100%" xmlns="http://www.w3.org/2000/svg" font-family="'JetBrains Mono', monospace">
    <text x="${size / 2}" y="16" text-anchor="middle" font-size="12" font-weight="600" fill="#f5f5f7">${escapeSvgText(judulTxt)}</text>
    ${gridPolys}
    ${axisLines}
    <polygon points="${dataPoly}" fill="rgba(124,106,232,0.3)" stroke="#7c6ae8" stroke-width="2"/>
    ${dots}
    ${labels}
  </svg>`;
}

async function runRaporTool(params, wrap) {
  const mapel = parseRaporMapel(params.mapel);
  if (!mapel.length) throw new Error('Data nilai mapel tidak diberikan');
  const model = (params.model || 'bar').toLowerCase();
  const nama = params.nama || '';
  const kelas = params.kelas || '';

  const svgMarkup = model === 'radar' ? renderRaporRadarSVG(mapel, nama, kelas) : renderRaporBarSVG(mapel, nama, kelas);
  const rataRata = (mapel.reduce((s, m) => s + m.nilai, 0) / mapel.length).toFixed(1);

  const box = buildVisualBox(wrap, `${nama || 'Rapor'}${kelas ? ' — ' + kelas : ''}`, svgMarkup, 'rapor', [
    {
      label: `↻ Coba ${model === 'radar' ? 'bar' : 'radar'}`,
      onClick: () => runRaporTool({ ...params, model: model === 'radar' ? 'bar' : 'radar' }, wrap)
    }
  ]);

  const table = document.createElement('table');
  table.className = 'tool-visual-table';
  table.innerHTML = `<thead><tr><th>Mapel</th><th>Nilai</th></tr></thead>
    <tbody>${mapel.map(m => `<tr><td>${escapeHtml(m.nama)}</td><td>${m.nilai}</td></tr>`).join('')}
    <tr><td><strong>Rata-rata</strong></td><td><strong>${rataRata}</strong></td></tr></tbody>`;
  box.insertBefore(table, box.querySelector('.tool-visual-actions'));
}

/* -------------------------------------------------------------------------
   2) ORG CHART — struktur hierarki atasan-bawahan
   params: { judul, root: { nama, jabatan, children: [...] } }
   atau bentuk flat: { judul, nodes: [{id, nama, jabatan, parent}] }
   ------------------------------------------------------------------------- */
function safeJsonParse(raw, fieldName) {
  if (raw == null) return null;
  if (typeof raw !== 'string') return raw; // sudah objek/array
  try {
    return JSON.parse(raw);
  } catch (e) {
    throw new Error(`Format data "${fieldName}" tidak valid (bukan JSON yang benar)`);
  }
}

function normalizeOrgTree(params) {
  const rootParam = safeJsonParse(params.root, 'root');
  if (rootParam) return rootParam;
  const nodes = safeJsonParse(params.nodes, 'nodes') || [];
  const byId = {};
  nodes.forEach(n => { byId[n.id] = { ...n, children: [] }; });
  let root = null;
  nodes.forEach(n => {
    if (n.parent && byId[n.parent]) byId[n.parent].children.push(byId[n.id]);
    else root = byId[n.id];
  });
  return root;
}

function layoutOrgTree(root) {
  const boxW = 150, boxH = 54, gapX = 24, gapY = 50;
  const nodes = [];
  const edges = [];

  // Pass 1: hitung lebar subtree tiap node (leaf = 1 unit)
  function subtreeWidth(node) {
    if (!node.children || !node.children.length) return boxW;
    const childW = node.children.reduce((sum, c) => sum + subtreeWidth(c), 0) + gapX * (node.children.length - 1);
    return Math.max(boxW, childW);
  }

  // Pass 2: assign posisi x (tengah subtree) & y (level)
  function place(node, xLeft, level) {
    const w = subtreeWidth(node);
    const cx = xLeft + w / 2;
    const y = level * (boxH + gapY);
    nodes.push({ x: cx - boxW / 2, y, w: boxW, h: boxH, nama: node.nama, jabatan: node.jabatan || '' });
    const selfIdx = nodes.length - 1;
    if (node.children && node.children.length) {
      let curX = xLeft;
      node.children.forEach(c => {
        const cw = subtreeWidth(c);
        const childIdx = place(c, curX, level + 1);
        edges.push({ x1: cx, y1: y + boxH, x2: nodes[childIdx].x + boxW / 2, y2: nodes[childIdx].y });
        curX += cw + gapX;
      });
    }
    return selfIdx;
  }

  place(root, 0, 0);
  const maxX = Math.max(...nodes.map(n => n.x + n.w));
  const maxY = Math.max(...nodes.map(n => n.y + n.h));
  return { nodes, edges, w: maxX, h: maxY };
}

function renderOrgChartSVG(root, judul) {
  const { nodes, edges, w, h } = layoutOrgTree(root);
  const pad = 30;
  const svgW = w + pad * 2, svgH = h + pad * 2 + (judul ? 24 : 0);
  const offsetY = judul ? 24 : 0;

  const edgesSvg = edges.map(e => {
    const bendY = e.y1 + (e.y2 - e.y1) / 2;
    return `<path d="M${e.x1 + pad},${e.y1 + pad + offsetY} L${e.x1 + pad},${bendY + pad + offsetY} L${e.x2 + pad},${bendY + pad + offsetY} L${e.x2 + pad},${e.y2 + pad + offsetY}" fill="none" stroke="#5b5580" stroke-width="1.6"/>`;
  }).join('');

  const nodesSvg = nodes.map((n, i) => {
    const x = n.x + pad, y = n.y + pad + offsetY;
    const color = VISUAL_PALETTE[Math.min(i === 0 ? 2 : 0, VISUAL_PALETTE.length - 1)];
    const namaLines = wrapSvgText(n.nama, n.w - 16);
    const jabatanLines = n.jabatan ? wrapSvgText(n.jabatan, n.w - 16) : [];
    const totalLines = namaLines.length + jabatanLines.length;
    let curY = y + n.h / 2 - (totalLines - 1) * 6 + 2;
    const namaSvg = namaLines.map(l => { const t = `<text x="${x + n.w / 2}" y="${curY}" text-anchor="middle" font-size="10.5" font-weight="700" fill="#14141a">${escapeSvgText(l)}</text>`; curY += 12; return t; }).join('');
    const jabatanSvg = jabatanLines.map(l => { const t = `<text x="${x + n.w / 2}" y="${curY}" text-anchor="middle" font-size="9" fill="rgba(18,16,28,0.7)">${escapeSvgText(l)}</text>`; curY += 11; return t; }).join('');
    return `<g><rect x="${x}" y="${y}" width="${n.w}" height="${n.h}" rx="8" fill="${color}" stroke="${color}" stroke-width="1.6"/>${namaSvg}${jabatanSvg}</g>`;
  }).join('');

  const titleSvg = judul ? `<text x="${svgW / 2}" y="16" text-anchor="middle" font-size="12" font-weight="600" fill="#f5f5f7">${escapeSvgText(judul)}</text>` : '';

  return `<svg viewBox="0 0 ${svgW} ${svgH}" width="100%" xmlns="http://www.w3.org/2000/svg" font-family="'JetBrains Mono', monospace">
    ${titleSvg}
    ${edgesSvg}
    ${nodesSvg}
  </svg>`;
}

async function runOrgChartTool(params, wrap) {
  const root = normalizeOrgTree(params);
  if (!root || !root.nama) throw new Error('Struktur organisasi tidak valid');
  const judul = params.judul || '';
  const svgMarkup = renderOrgChartSVG(root, judul);
  buildVisualBox(wrap, judul, svgMarkup, 'orgchart');
}

/* -------------------------------------------------------------------------
   3) MIND MAP dari teks/ringkasan — layout radial dari 1 topik pusat
   params: { topik, cabang: [{ label, sub: [label,...] }] } atau
           { topik, cabang: ["Cabang: sub1, sub2", ...] }
   ------------------------------------------------------------------------- */
function parseMindmapCabang(raw) {
  if (!raw) return [];
  const arr = typeof raw === 'string' ? raw.split('|').map(s => s.trim()).filter(Boolean) : raw;
  return arr.map(c => {
    if (typeof c === 'string') {
      const [label, subRaw] = c.split(':');
      const sub = subRaw ? subRaw.split(',').map(s => s.trim()).filter(Boolean) : [];
      return { label: (label || '').trim(), sub };
    }
    return { label: c.label || '', sub: c.sub || [] };
  }).filter(c => c.label);
}

function renderMindmapSVG(topik, cabang) {
  const size = 700;
  const cx = size / 2, cy = size / 2;
  const branchR = 170;
  const n = cabang.length;
  const angleStep = (Math.PI * 2) / n;

  let edgesSvg = '', nodesSvg = '';
  const centerColor = '#7c6ae8';

  cabang.forEach((c, i) => {
    const angle = -Math.PI / 2 + i * angleStep;
    const bx = cx + Math.cos(angle) * branchR;
    const by = cy + Math.sin(angle) * branchR;
    const color = VISUAL_PALETTE[i % VISUAL_PALETTE.length];

    edgesSvg += `<path d="M${cx},${cy} Q${cx + Math.cos(angle) * branchR * 0.5},${cy + Math.sin(angle) * branchR * 0.5} ${bx},${by}" fill="none" stroke="${color}" stroke-width="2.2" opacity="0.7"/>`;

    const labelLines = wrapSvgText(c.label, 130);
    const bw = Math.max(80, Math.max(...labelLines.map(l => l.length)) * 6.6 + 20);
    const bh = 26 + (labelLines.length - 1) * 12;
    const bx0 = bx - bw / 2, by0 = by - bh / 2;
    const labelSvg = labelLines.map((l, li) => `<tspan x="${bx}" y="${by - (labelLines.length - 1) * 6 + li * 12 + 4}">${escapeSvgText(l)}</tspan>`).join('');
    nodesSvg += `<g><rect x="${bx0}" y="${by0}" width="${bw}" height="${bh}" rx="8" fill="${color}" stroke="${color}"/><text text-anchor="middle" font-size="10.5" font-weight="700" fill="#14141a">${labelSvg}</text></g>`;

    // sub-cabang tersebar di sekitar arah yang sama
    const subCount = c.sub.length;
    if (subCount) {
      const subR = 95;
      const spread = Math.PI / 3.2;
      c.sub.forEach((s, si) => {
        const subAngle = angle - spread / 2 + (subCount === 1 ? spread / 2 : (spread / (subCount - 1)) * si);
        const sx = bx + Math.cos(subAngle) * subR;
        const sy = by + Math.sin(subAngle) * subR;
        edgesSvg += `<path d="M${bx},${by} L${sx},${sy}" fill="none" stroke="${color}" stroke-width="1.2" opacity="0.45" stroke-dasharray="3,3"/>`;
        const subLines = wrapSvgText(s, 100);
        const sbw = Math.max(60, Math.max(...subLines.map(l => l.length)) * 5.8 + 14);
        const sbh = 18 + (subLines.length - 1) * 11;
        const subLabelSvg = subLines.map((l, li) => `<tspan x="${sx}" y="${sy - (subLines.length - 1) * 5.5 + li * 11 + 3}">${escapeSvgText(l)}</tspan>`).join('');
        nodesSvg += `<g><rect x="${sx - sbw / 2}" y="${sy - sbh / 2}" width="${sbw}" height="${sbh}" rx="6" fill="#27272f" stroke="${color}" stroke-width="1.2"/><text text-anchor="middle" font-size="9" fill="#d4d4d9">${subLabelSvg}</text></g>`;
      });
    }
  });

  const topikLines = wrapSvgText(topik, 140);
  const tw = Math.max(110, Math.max(...topikLines.map(l => l.length)) * 7.4 + 24);
  const th = 34 + (topikLines.length - 1) * 14;
  const topikLabelSvg = topikLines.map((l, li) => `<tspan x="${cx}" y="${cy - (topikLines.length - 1) * 7 + li * 14 + 5}">${escapeSvgText(l)}</tspan>`).join('');

  return `<svg viewBox="0 0 ${size} ${size}" width="100%" xmlns="http://www.w3.org/2000/svg" font-family="'JetBrains Mono', monospace">
    ${edgesSvg}
    ${nodesSvg}
    <g><rect x="${cx - tw / 2}" y="${cy - th / 2}" width="${tw}" height="${th}" rx="10" fill="${centerColor}" stroke="${centerColor}"/><text text-anchor="middle" font-size="12" font-weight="700" fill="#14141a">${topikLabelSvg}</text></g>
  </svg>`;
}

async function runMindmapTool(params, wrap) {
  const topik = params.topik;
  if (!topik) throw new Error('Topik utama tidak diberikan');
  const cabang = parseMindmapCabang(params.cabang);
  if (!cabang.length) throw new Error('Cabang mind map tidak diberikan');
  const svgMarkup = renderMindmapSVG(topik, cabang);
  buildVisualBox(wrap, topik, svgMarkup, 'mindmap');
}

/* -------------------------------------------------------------------------
   4) CONCEPT MAP — node bebas saling terhubung dengan label relasi
   params: { judul, nodes: [{id, label}], links: [{from, to, label}] }
   ------------------------------------------------------------------------- */
function layoutConceptNodes(nodes) {
  // Layout melingkar sederhana + sedikit jitter berdasar index agar tidak simetris kaku
  const n = nodes.length;
  const R = Math.max(150, n * 32);
  const size = R * 2 + 160;
  const cx = size / 2, cy = size / 2;
  const positioned = nodes.map((node, i) => {
    const angle = (Math.PI * 2 * i) / n - Math.PI / 2;
    return { ...node, x: cx + Math.cos(angle) * R, y: cy + Math.sin(angle) * R };
  });
  return { positioned, size };
}

function renderConceptMapSVG(nodes, links, judul) {
  const { positioned, size } = layoutConceptNodes(nodes);
  const byId = {};
  positioned.forEach(n => { byId[n.id] = n; });

  const linksSvg = links.map((l, i) => {
    const a = byId[l.from], b = byId[l.to];
    if (!a || !b) return '';
    const midX = (a.x + b.x) / 2, midY = (a.y + b.y) / 2;
    const color = VISUAL_PALETTE[i % VISUAL_PALETTE.length];
    const labelSvg = l.label
      ? `<rect x="${midX - l.label.length * 3 - 4}" y="${midY - 9}" width="${l.label.length * 6 + 8}" height="16" rx="3" fill="#27272f"/>
         <text x="${midX}" y="${midY + 3}" text-anchor="middle" font-size="9" fill="${color}">${escapeSvgText(l.label)}</text>`
      : '';
    return `<line x1="${a.x}" y1="${a.y}" x2="${b.x}" y2="${b.y}" stroke="${color}" stroke-width="1.6" opacity="0.65" marker-end="url(#cm-arrow)"/>${labelSvg}`;
  }).join('');

  const nodesSvg = positioned.map((n, i) => {
    const color = VISUAL_PALETTE[i % VISUAL_PALETTE.length];
    const lines = wrapSvgText(n.label, 120);
    const bw = Math.max(80, Math.max(...lines.map(l => l.length)) * 6.6 + 18);
    const bh = 26 + (lines.length - 1) * 12;
    const labelSvg = lines.map((l, li) => `<tspan x="${n.x}" y="${n.y - (lines.length - 1) * 6 + li * 12 + 4}">${escapeSvgText(l)}</tspan>`).join('');
    return `<g><rect x="${n.x - bw / 2}" y="${n.y - bh / 2}" width="${bw}" height="${bh}" rx="8" fill="${color}" stroke="${color}"/><text text-anchor="middle" font-size="10" font-weight="700" fill="#14141a">${labelSvg}</text></g>`;
  }).join('');

  const titleSvg = judul ? `<text x="${size / 2}" y="18" text-anchor="middle" font-size="12" font-weight="600" fill="#f5f5f7">${escapeSvgText(judul)}</text>` : '';

  return `<svg viewBox="0 0 ${size} ${size}" width="100%" xmlns="http://www.w3.org/2000/svg" font-family="'JetBrains Mono', monospace">
    <defs><marker id="cm-arrow" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="5" markerHeight="5" orient="auto-start-reverse"><path d="M0 0L10 5L0 10z" fill="#7c6ae8"/></marker></defs>
    ${titleSvg}
    ${linksSvg}
    ${nodesSvg}
  </svg>`;
}

async function runConceptMapTool(params, wrap) {
  const nodes = safeJsonParse(params.nodes, 'nodes') || [];
  const links = safeJsonParse(params.links, 'links') || [];
  if (!nodes.length) throw new Error('Node concept map tidak diberikan');
  const judul = params.judul || '';
  const svgMarkup = renderConceptMapSVG(nodes, links, judul);
  buildVisualBox(wrap, judul, svgMarkup, 'conceptmap');
}

/* -------------------------------------------------------------------------
   5) PETA / RUTE PEMBELAJARAN — urutan lokasi/tahap dengan penanda nomor
   params: { judul, titik: [{ nama, keterangan }] }  (linear seperti rute belajar)
   Catatan: ini peta konseptual bergaya jalur, BUKAN peta geografis nyata
   (tidak butuh API map eksternal, cocok untuk rute topik/materi berurutan).
   ------------------------------------------------------------------------- */
function renderPetaRuteSVG(titik, judul) {
  const boxW = 200, boxH = 60, gapY = 46, pad = 34;
  const zigzag = 90; // offset kiri-kanan biar tidak lurus kaku
  const svgW = boxW + zigzag * 2 + pad * 2;
  const svgH = titik.length * (boxH + gapY) - gapY + pad * 2 + (judul ? 24 : 0);
  const offsetY = judul ? 24 : 0;

  let edgesSvg = '', nodesSvg = '';
  const positions = titik.map((_, i) => {
    const x = pad + (i % 2 === 0 ? 0 : zigzag);
    const y = pad + offsetY + i * (boxH + gapY);
    return { x, y };
  });

  positions.forEach((p, i) => {
    const color = VISUAL_PALETTE[i % VISUAL_PALETTE.length];
    const t = titik[i];
    const namaLines = wrapSvgText(t.nama, boxW - 50);
    const ketLines = t.keterangan ? wrapSvgText(t.keterangan, boxW - 50) : [];
    let curY = p.y + 22;
    const namaSvg = namaLines.map(l => { const s = `<text x="${p.x + 44}" y="${curY}" font-size="10.5" font-weight="700" fill="#14141a">${escapeSvgText(l)}</text>`; curY += 12; return s; }).join('');
    const ketSvg = ketLines.map(l => { const s = `<text x="${p.x + 44}" y="${curY}" font-size="8.5" fill="rgba(18,16,28,0.7)">${escapeSvgText(l)}</text>`; curY += 10; return s; }).join('');
    nodesSvg += `<g>
      <rect x="${p.x}" y="${p.y}" width="${boxW}" height="${boxH}" rx="10" fill="${color}" stroke="${color}"/>
      <circle cx="${p.x + 24}" cy="${p.y + boxH / 2}" r="14" fill="#14141a"/>
      <text x="${p.x + 24}" y="${p.y + boxH / 2 + 4}" text-anchor="middle" font-size="12" font-weight="700" fill="${color}">${i + 1}</text>
      ${namaSvg}${ketSvg}
    </g>`;

    if (i > 0) {
      const prev = positions[i - 1];
      const x1 = prev.x + boxW / 2, y1 = prev.y + boxH;
      const x2 = p.x + boxW / 2, y2 = p.y;
      const bendY = y1 + (y2 - y1) / 2;
      edgesSvg += `<path d="M${x1},${y1} L${x1},${bendY} L${x2},${bendY} L${x2},${y2}" fill="none" stroke="#5b5580" stroke-width="1.6" stroke-dasharray="6,4" marker-end="url(#fc-arrow)"/>`;
    }
  });

  const titleSvg = judul ? `<text x="${svgW / 2}" y="16" text-anchor="middle" font-size="12" font-weight="600" fill="#f5f5f7">${escapeSvgText(judul)}</text>` : '';

  return `<svg viewBox="0 0 ${svgW} ${svgH}" width="100%" xmlns="http://www.w3.org/2000/svg" font-family="'JetBrains Mono', monospace">
    <defs><marker id="fc-arrow" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="6" markerHeight="6" orient="auto-start-reverse"><path d="M0 0L10 5L0 10z" fill="#7c6ae8"/></marker></defs>
    ${titleSvg}
    ${edgesSvg}
    ${nodesSvg}
  </svg>`;
}

async function runPetaRuteTool(params, wrap) {
  const titik = safeJsonParse(params.titik, 'titik') || [];
  if (!titik.length) throw new Error('Titik rute pembelajaran tidak diberikan');
  const judul = params.judul || '';
  const svgMarkup = renderPetaRuteSVG(titik, judul);
  buildVisualBox(wrap, judul, svgMarkup, 'peta-rute');
}

/* -------------------------------------------------------------------------
   6) GRAFIK STATISTIK — bar / pie / line dari data label:value
   params: { judul, model: 'bar'|'pie'|'line', data: [{label, value}] }
   ------------------------------------------------------------------------- */
function parseStatData(raw) {
  if (Array.isArray(raw)) {
    return raw.map(d => ({ label: String(d.label || '').trim(), value: Number(d.value) || 0 })).filter(d => d.label);
  }
  return String(raw).split(/[,\n]/).map(line => {
    const [label, value] = line.split(':').map(s => (s || '').trim());
    return { label, value: Number(value) || 0 };
  }).filter(d => d.label);
}

function renderStatBarSVG(data, judul) {
  const padL = 44, padB = 60, padT = 30, padR = 20;
  const barW = 44, gap = 22;
  const chartH = 240;
  const maxVal = Math.max(...data.map(d => d.value), 1);
  const chartW = data.length * (barW + gap) + gap;
  const svgW = chartW + padL + padR, svgH = chartH + padT + padB;

  const bars = data.map((d, i) => {
    const x = padL + gap + i * (barW + gap);
    const h = (d.value / maxVal) * chartH;
    const y = padT + (chartH - h);
    const color = VISUAL_PALETTE[i % VISUAL_PALETTE.length];
    const labelLines = wrapSvgText(d.label, barW + 20);
    const labelSvg = labelLines.map((l, li) => `<tspan x="${x + barW / 2}" y="${padT + chartH + 18 + li * 12}">${escapeSvgText(l)}</tspan>`).join('');
    return `<rect x="${x}" y="${y}" width="${barW}" height="${h}" rx="4" fill="${color}"/>
      <text x="${x + barW / 2}" y="${y - 6}" text-anchor="middle" font-size="10" font-weight="600" fill="#d4d4d9">${d.value}</text>
      <text text-anchor="middle" font-size="9" fill="rgba(212,212,217,0.65)">${labelSvg}</text>`;
  }).join('');

  const titleSvg = judul ? `<text x="${svgW / 2}" y="16" text-anchor="middle" font-size="12" font-weight="600" fill="#f5f5f7">${escapeSvgText(judul)}</text>` : '';

  return `<svg viewBox="0 0 ${svgW} ${svgH}" width="100%" xmlns="http://www.w3.org/2000/svg" font-family="'JetBrains Mono', monospace">
    ${titleSvg}
    ${bars}
    <line x1="${padL}" y1="${padT + chartH}" x2="${padL + chartW}" y2="${padT + chartH}" stroke="rgba(212,212,217,0.35)" stroke-width="1.4"/>
  </svg>`;
}

function renderStatPieSVG(data, judul) {
  const size = 320, cx = size / 2, cy = size / 2 + 14, r = 100;
  const total = data.reduce((s, d) => s + d.value, 0) || 1;
  let angleStart = -Math.PI / 2;

  const slices = data.map((d, i) => {
    const angleSize = (d.value / total) * Math.PI * 2;
    const angleEnd = angleStart + angleSize;
    const x1 = cx + Math.cos(angleStart) * r, y1 = cy + Math.sin(angleStart) * r;
    const x2 = cx + Math.cos(angleEnd) * r, y2 = cy + Math.sin(angleEnd) * r;
    const largeArc = angleSize > Math.PI ? 1 : 0;
    const color = VISUAL_PALETTE[i % VISUAL_PALETTE.length];
    const path = `M${cx},${cy} L${x1},${y1} A${r},${r} 0 ${largeArc} 1 ${x2},${y2} Z`;
    const midAngle = angleStart + angleSize / 2;
    const labelR = r + 24;
    const lx = cx + Math.cos(midAngle) * labelR, ly = cy + Math.sin(midAngle) * labelR;
    const pct = Math.round((d.value / total) * 100);
    angleStart = angleEnd;
    return {
      path: `<path d="${path}" fill="${color}" stroke="#14141a" stroke-width="1.5"/>`,
      label: `<text x="${lx}" y="${ly}" text-anchor="middle" font-size="9" fill="rgba(212,212,217,0.8)">${escapeSvgText(d.label)} (${pct}%)</text>`
    };
  });

  const titleSvg = judul ? `<text x="${size / 2}" y="16" text-anchor="middle" font-size="12" font-weight="600" fill="#f5f5f7">${escapeSvgText(judul)}</text>` : '';

  return `<svg viewBox="0 0 ${size} ${size + 20}" width="100%" xmlns="http://www.w3.org/2000/svg" font-family="'JetBrains Mono', monospace">
    ${titleSvg}
    ${slices.map(s => s.path).join('')}
    ${slices.map(s => s.label).join('')}
  </svg>`;
}

function renderStatLineSVG(data, judul) {
  const padL = 44, padB = 40, padT = 30, padR = 24;
  const chartH = 240, stepX = 70;
  const chartW = (data.length - 1) * stepX;
  const maxVal = Math.max(...data.map(d => d.value), 1);
  const svgW = chartW + padL + padR, svgH = chartH + padT + padB;

  const points = data.map((d, i) => ({
    x: padL + i * stepX,
    y: padT + chartH - (d.value / maxVal) * chartH,
    ...d
  }));

  const pathD = points.map((p, i) => (i === 0 ? 'M' : 'L') + `${p.x},${p.y}`).join(' ');
  const gridLines = [0, 0.25, 0.5, 0.75, 1].map(r => {
    const y = padT + chartH - r * chartH;
    const val = Math.round(maxVal * r);
    return `<line x1="${padL}" y1="${y}" x2="${padL + chartW}" y2="${y}" stroke="rgba(120,120,130,0.18)" stroke-width="1"/>
      <text x="${padL - 8}" y="${y + 3}" text-anchor="end" font-size="9" fill="rgba(212,212,217,0.5)">${val}</text>`;
  }).join('');

  const dotsAndLabels = points.map(p => `
    <circle cx="${p.x}" cy="${p.y}" r="3.5" fill="#7c6ae8"/>
    <text x="${p.x}" y="${p.y - 10}" text-anchor="middle" font-size="9" fill="#d4d4d9">${p.value}</text>
    <text x="${p.x}" y="${padT + chartH + 18}" text-anchor="middle" font-size="9" fill="rgba(212,212,217,0.65)">${escapeSvgText(p.label)}</text>`).join('');

  const titleSvg = judul ? `<text x="${svgW / 2}" y="16" text-anchor="middle" font-size="12" font-weight="600" fill="#f5f5f7">${escapeSvgText(judul)}</text>` : '';

  return `<svg viewBox="0 0 ${svgW} ${svgH}" width="100%" xmlns="http://www.w3.org/2000/svg" font-family="'JetBrains Mono', monospace">
    ${titleSvg}
    ${gridLines}
    <path d="${pathD}" fill="none" stroke="#7c6ae8" stroke-width="2.2"/>
    ${dotsAndLabels}
  </svg>`;
}

async function runStatistikTool(params, wrap) {
  const data = parseStatData(params.data);
  if (!data.length) throw new Error('Data statistik tidak diberikan');
  const model = (params.model || 'bar').toLowerCase();
  const judul = params.judul || '';

  let svgMarkup;
  if (model === 'pie') svgMarkup = renderStatPieSVG(data, judul);
  else if (model === 'line') svgMarkup = renderStatLineSVG(data, judul);
  else svgMarkup = renderStatBarSVG(data, judul);

  const otherModels = ['bar', 'pie', 'line'].filter(m => m !== model);
  buildVisualBox(wrap, judul, svgMarkup, 'statistik', [
    { label: `↻ Coba ${otherModels[0]}`, onClick: () => runStatistikTool({ ...params, model: otherModels[0] }, wrap) },
    { label: `↻ Coba ${otherModels[1]}`, onClick: () => runStatistikTool({ ...params, model: otherModels[1] }, wrap) }
  ]);
}

// Bahasa yang bisa dirender langsung di iframe preview
