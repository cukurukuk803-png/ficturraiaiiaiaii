
/* ---------- Theme toggle (dark/light, ikut sistem + override manual) ---------- */
const themeToggleBtn = document.getElementById('themeToggle');
function setThemeIcon(theme){
  themeToggleBtn.innerHTML = theme === 'light'
    ? '<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 3a6 6 0 0 0 9 9 9 9 0 1 1-9-9Z"/></svg>'
    : '<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="4"/><path d="M12 2v2"/><path d="M12 20v2"/><path d="m4.93 4.93 1.41 1.41"/><path d="m17.66 17.66 1.41 1.41"/><path d="M2 12h2"/><path d="M20 12h2"/><path d="m6.34 17.66-1.41 1.41"/><path d="m19.07 4.93-1.41 1.41"/></svg>';
}
function applyTheme(theme){
  document.documentElement.setAttribute('data-theme', theme);
  setThemeIcon(theme);
}
applyTheme(document.documentElement.getAttribute('data-theme') || 'dark');
themeToggleBtn.addEventListener('click', () => {
  const current = document.documentElement.getAttribute('data-theme');
  const next = current === 'light' ? 'dark' : 'light';
  applyTheme(next);
  themeToggleBtn.classList.remove('spin');
  void themeToggleBtn.offsetWidth;
  themeToggleBtn.classList.add('spin');
  try { localStorage.setItem('fictur-theme', next); } catch(e){}
});
// Ikuti perubahan tema sistem OS secara live, kecuali user sudah pernah override manual
if (window.matchMedia) {
  window.matchMedia('(prefers-color-scheme: light)').addEventListener('change', (e) => {
    let hasOverride = false;
    try { hasOverride = localStorage.getItem('fictur-theme') !== null; } catch(err){}
    if (!hasOverride) applyTheme(e.matches ? 'light' : 'dark');
  });
}

