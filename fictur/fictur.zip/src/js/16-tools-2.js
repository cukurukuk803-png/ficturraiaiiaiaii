async function runScreenshotTool(params, wrap) {
  const url = params.url;
  const mode = params.mode || 'desktop';
  if (!url) throw new Error('URL tidak diberikan');
  const apiUrl = `${BINTANGAPI_BASE}/api/tools/ssweb?url=${encodeURIComponent(url)}&mode=${encodeURIComponent(mode)}`;
  const res = await fetch(apiUrl);
  if (!res.ok) throw new Error(`HTTP ${res.status}`);
  const contentType = res.headers.get('content-type') || '';
  wrap.innerHTML = '';
  const box = document.createElement('div');
  box.className = 'tool-screenshot';
  let resultUrl;
  if (contentType.startsWith('image/')) {
    const blob = await res.blob();
    resultUrl = URL.createObjectURL(blob);
    const img = document.createElement('img');
    img.src = resultUrl;
    box.appendChild(img);
  } else {
    const json = await res.json().catch(() => null);
    resultUrl = json?.url || json?.data?.url || json?.result;
    if (!resultUrl) throw new Error('Respon tidak berisi gambar');
    const img = document.createElement('img');
    img.src = resultUrl;
    box.appendChild(img);
  }
  wrap.appendChild(box);
  wrap.appendChild(createDownloadButton(resultUrl, 'image'));
  wrap.appendChild(toolSource(new URL(url).hostname, url));
}

async function runPinterestTool(params, wrap) {
  const query = params.query;
  if (!query) throw new Error('Kata kunci tidak diberikan');
  const apiUrl = `${BINTANGAPI_BASE}/api/search/pinterest?q=${encodeURIComponent(query)}`;
  const res = await fetch(apiUrl);
  if (!res.ok) throw new Error(`HTTP ${res.status}`);
  const json = await res.json();
  const items = (json.data || []).slice(0, 8);
  if (!items.length) throw new Error('Tidak ada hasil');
  wrap.innerHTML = '';
  const container = document.createElement('div');
  renderGridWithLoadMore(container, items, item => {
    const card = document.createElement('a');
    card.className = 'tool-card';
    card.href = item.url;
    card.target = '_blank';
    card.rel = 'noopener noreferrer';
    card.innerHTML = `<img src="${item.thumbnail || item.image}" loading="lazy"><div class="tool-card-body"><div class="tool-card-title">${item.title || 'Pin'}</div><div class="tool-card-meta">♡ ${item.likes ?? 0}</div></div>`;
    return card;
  });
  wrap.appendChild(container);
  wrap.appendChild(toolSource('Pinterest', 'https://pinterest.com'));
}

async function runStickerTool(params, wrap) {
  const query = params.query;
  if (!query) throw new Error('Kata kunci tidak diberikan');
  const apiUrl = `${BINTANGAPI_BASE}/api/search/stikerly?q=${encodeURIComponent(query)}`;
  const res = await fetch(CORS_PROXY + encodeURIComponent(apiUrl));
  if (!res.ok) throw new Error(`HTTP ${res.status}`);
  const json = await res.json();
  const items = (json.data || []).slice(0, 8);
  if (!items.length) throw new Error('Tidak ada hasil');
  wrap.innerHTML = '';
  const container = document.createElement('div');
  renderGridWithLoadMore(container, items, item => {
    const card = document.createElement('a');
    card.className = 'tool-card';
    card.href = item.url;
    card.target = '_blank';
    card.rel = 'noopener noreferrer';
    card.innerHTML = `<img src="${item.thumbnailUrl}" loading="lazy"><div class="tool-card-body"><div class="tool-card-title">${item.name || 'Stiker'}</div><div class="tool-card-meta">${item.stickerCount ?? 0} stiker · @${item.author || '-'}</div></div>`;
    return card;
  });
  wrap.appendChild(container);
  wrap.appendChild(toolSource('Sticker.ly', 'https://sticker.ly'));
}

async function runGagstockTool(params, wrap) {
  const apiUrl = `${BINTANGAPI_BASE}/api/info/gagstock`;
  const res = await fetch(apiUrl);
  if (!res.ok) throw new Error(`HTTP ${res.status}`);
  const json = await res.json();
  const data = json.data || {};
  const countdowns = data.countdowns || {};
  const categoryLabels = {
    gear: 'Gear',
    seeds: 'Seeds',
    egg: 'Egg',
    event: 'Event',
    cosmetics: 'Cosmetics',
    honey: 'Honey'
  };
  const categories = Object.keys(data).filter(k => k !== 'countdowns' && Array.isArray(data[k]) && data[k].length);
  if (!categories.length) throw new Error('Tidak ada data stok');
  wrap.innerHTML = '';
  const container = document.createElement('div');
  container.className = 'tool-gagstock';
  categories.forEach(cat => {
    const items = data[cat];
    const section = document.createElement('div');
    section.className = 'tool-gagstock-section';
    const title = categoryLabels[cat] || (cat.charAt(0).toUpperCase() + cat.slice(1));
    const countdown = countdowns[cat];
    section.innerHTML = `<div class="tool-gagstock-title">${title}${countdown ? ` <span class="tool-gagstock-countdown">(restock ${countdown})</span>` : ''}</div>`;

    renderGridWithLoadMore(section, items, item => {
      const card = document.createElement('div');
      card.className = 'tool-card';
      card.innerHTML = `<img src="${item.image}" loading="lazy" onerror="this.style.opacity='0.15'"><div class="tool-card-body"><div class="tool-card-title">${item.name}</div><div class="tool-card-meta">Stok: ${item.stock ?? 0}</div></div>`;
      return card;
    });

    container.appendChild(section);
  });
  wrap.appendChild(container);
  wrap.appendChild(toolSource('Grow a Garden Stock', 'https://vulcanvalues.com'));
}

const KAPPA_UPLOAD_URL = 'https://kappa.lol/api/upload';
const UPSCALE_BASE = 'https://api.kyzznekoo.my.id/api/upscale/v5/uhd';
const UNGGAH_UPLOAD_URL = 'https://unggah.web.id/api/unggah';

function dataUrlToBlob(dataUrl) {
  const [header, base64] = dataUrl.split(',');
  const mimeMatch = header.match(/data:(.*?);base64/);
  const mime = mimeMatch ? mimeMatch[1] : 'application/octet-stream';
  const binary = atob(base64);
  const bytes = new Uint8Array(binary.length);
  for (let i = 0; i < binary.length; i++) bytes[i] = binary.charCodeAt(i);
  return new Blob([bytes], { type: mime });
}

// Upload generik untuk mendapatkan URL publik dari sebuah blob (foto, video,
// audio, dll) — dipakai oleh berbagai tool yang butuh URL publik sebelum
// diproses API pihak ketiga (upscale, remove_bg, canvas via placeholder,
// transcribe, dll). Coba Kappa dulu (cepat, tanpa proxy); kalau gagal,
// fallback ke unggah.web.id lewat proxy CORS (situs ini butuh header
// origin/referer custom yang diblokir browser kalau di-fetch langsung).
async function uploadFileGetPublicUrl(blob, filename) {
  try {
    const form = new FormData();
    form.append('file', blob, filename);
    const res = await fetch(KAPPA_UPLOAD_URL, { method: 'POST', body: form });
    if (res.ok) {
      const json = await res.json();
      const url = json.link || json.url || json.data?.link;
      if (url) return url;
    }
    console.warn('[FicTur diag] Upload Kappa gagal/tidak ada URL, coba fallback unggah.web.id');
  } catch (e) {
    console.warn('[FicTur diag] Upload Kappa error, coba fallback unggah.web.id:', e.message);
  }

  // Fallback: unggah.web.id butuh multipart form-data dengan Content-Type
  // yang eksplisit di tiap bagian file — FormData browser biasa sudah
  // otomatis menyertakan Content-Type dari blob.type, jadi cukup pakai
  // FormData standar juga di sini (tidak perlu membangun multipart manual
  // seperti di Node.js karena browser sudah menanganinya).
  const target = UNGGAH_UPLOAD_URL;
  const form2 = new FormData();
  form2.append('file', blob, filename);
  const res2 = await fetch(FICTUR_CORS_PROXY + encodeURIComponent(target), {
    method: 'POST',
    body: form2
  });
  if (!res2.ok) throw new Error(`Upload gagal di kedua penyedia (HTTP ${res2.status})`);
  const json2 = await res2.json();
  const url2 = json2.url || json2.result_url || json2.data?.url;
  if (!url2) throw new Error('URL hasil upload tidak ditemukan (fallback)');
  return url2;
}

// Kalau salah satu param canvas butuh URL foto dan pengguna memakai penanda
// {{LAST_ATTACHED_IMAGE}}, upload foto terakhir yang dilampirkan ke Kappa dulu
// supaya dapat URL publik yang bisa diakses API SynoxCloud.
async function resolveLastAttachedImageUrl() {
  if (!lastUserImageDataUrl) throw new Error('Belum ada foto yang dilampirkan untuk dipakai');
  const blob = dataUrlToBlob(lastUserImageDataUrl);
  const ext = blob.type.split('/')[1] || 'jpg';
  const form = new FormData();
  form.append('file', blob, `upload.${ext}`);
  const uploadRes = await fetch(KAPPA_UPLOAD_URL, { method: 'POST', body: form });
  if (!uploadRes.ok) throw new Error(`Upload foto gagal (HTTP ${uploadRes.status})`);
  const uploadJson = await uploadRes.json();
  const mediaUrl = uploadJson.link || uploadJson.url || uploadJson.data?.link;
  if (!mediaUrl) throw new Error('URL hasil upload foto tidak ditemukan');
  return mediaUrl;
}

async function runCanvasTool(params, wrap) {
  const skillName = params.skill;
  if (!skillName) throw new Error('Skill Canvas tidak diberikan');
  const skill = CANVAS_SKILLS[skillName];
  if (!skill) throw new Error(`Skill Canvas "${skillName}" tidak dikenal`);

  const query = new URLSearchParams();
  for (const paramName of skill.params) {
    let value = params[paramName];
    if (value === undefined || value === null || value === '') continue;
    if (String(value).trim() === '{{LAST_ATTACHED_IMAGE}}') {
      value = await resolveLastAttachedImageUrl();
    }
    query.set(paramName, value);
  }

  const apiUrl = `${SYNOXCLOUD_BASE}/canvas/${encodeURIComponent(skillName)}?${query.toString()}`;
  const res = await fetch(apiUrl);
  if (!res.ok) throw new Error(`HTTP ${res.status}`);

  const contentType = res.headers.get('content-type') || '';
  wrap.innerHTML = '';
  const box = document.createElement('div');
  box.className = 'tool-screenshot';

  let resultUrl;
  let isVideo = skill.kind === 'video';

  if (contentType.startsWith('image/') || contentType.startsWith('video/')) {
    const resultBlob = await res.blob();
    resultUrl = URL.createObjectURL(resultBlob);
    isVideo = contentType.startsWith('video/');
  } else {
    const json = await res.json().catch(() => null);
    resultUrl = json?.url || json?.data?.url || json?.result || json?.data?.result;
    if (!resultUrl) throw new Error('Respon tidak berisi hasil media');
  }

  if (isVideo) {
    box.innerHTML = `<video src="${resultUrl}" controls style="width:100%;max-width:340px;border-radius:8px;border:1px solid rgba(120,120,130,0.25);"></video>`;
  } else {
    const img = document.createElement('img');
    img.src = resultUrl;
    box.appendChild(img);
  }
  wrap.appendChild(box);
  wrap.appendChild(createDownloadButton(resultUrl, isVideo ? 'video' : 'image'));
  wrap.appendChild(toolSource('FicTur Canvas', SYNOXCLOUD_BASE));
}

// Bacakan beberapa kemungkinan nama field umum dari respons API games (tiap
// endpoint SynoxCloud punya skema JSON yang sedikit berbeda satu sama lain).
function pickField(obj, names) {
  for (const n of names) {
    if (obj && obj[n] !== undefined && obj[n] !== null && obj[n] !== '') return obj[n];
  }
  return null;
}

async function runGamesTool(params, wrap) {
  const skillKey = params.skill;
  if (!skillKey) throw new Error('Skill game tidak diberikan');
  const skill = GAMES_SKILLS[skillKey];
  if (!skill) throw new Error(`Skill game "${skillKey}" tidak dikenal`);

  const query = new URLSearchParams();
  for (const paramName of skill.params) {
    const value = params[paramName];
    if (value === undefined || value === null || value === '') continue;
    query.set(paramName, value);
  }
  const qs = query.toString();
  const apiUrl = `${SYNOXCLOUD_BASE}${skill.path}${qs ? '?' + qs : ''}`;

  const res = await fetch(apiUrl);
  if (!res.ok) throw new Error(`HTTP ${res.status}`);
  const json = await res.json();
  const data = json.data || json.result || json;

  wrap.innerHTML = '';
  const box = document.createElement('div');
  box.className = 'tool-games';

  const label = document.createElement('div');
  label.className = 'tool-games-label';
  label.textContent = skill.desc;
  box.appendChild(label);

  // Kalau respons berupa array (misal daftar top game Roblox, daftar hasil pencarian),
  // render sebagai grid kartu memakai helper yang sudah ada.
  if (Array.isArray(data)) {
    const grid = document.createElement('div');
    renderGridWithLoadMore(grid, data, item => {
      const card = document.createElement('div');
      card.className = 'tool-card';
      const img = pickField(item, ['image', 'thumbnail', 'thumb', 'icon', 'gambar']);
      const title = pickField(item, ['name', 'title', 'nama', 'judul']) || 'Item';
      const meta = pickField(item, ['players', 'visits', 'category', 'kategori', 'stock', 'genre']);
      card.innerHTML = `${img ? `<img src="${img}" loading="lazy">` : ''}<div class="tool-card-body"><div class="tool-card-title">${title}</div>${meta ? `<div class="tool-card-meta">${meta}</div>` : ''}</div>`;
      return card;
    });
    box.appendChild(grid);
    wrap.appendChild(box);
    wrap.appendChild(toolSource('FicTur Games', SYNOXCLOUD_BASE));
    return;
  }

  // Gambar/audio pendukung soal, kalau ada
  const imageUrl = pickField(data, ['image', 'img', 'gambar', 'foto', 'thumbnail']);
  const audioUrl = pickField(data, ['audio', 'song', 'lagu', 'sound']);
  if (imageUrl) {
    const img = document.createElement('img');
    img.src = imageUrl;
    box.appendChild(img);
  }
  if (audioUrl) {
    box.innerHTML += `<audio src="${audioUrl}" controls></audio>`;
  }

  // Teks soal/pertanyaan
  const question = pickField(data, ['soal', 'question', 'pertanyaan', 'deskripsi', 'clue', 'quote', 'text']);
  if (question) {
    const q = document.createElement('div');
    q.className = 'tool-games-question';
    q.textContent = question;
    box.appendChild(q);
  }

  // Pilihan jawaban (kalau format pilihan ganda)
  const options = pickField(data, ['opsi', 'options', 'pilihan', 'choices']);
  if (Array.isArray(options) && options.length) {
    const optWrap = document.createElement('div');
    optWrap.className = 'tool-games-options';
    options.forEach(opt => {
      const o = document.createElement('div');
      o.className = 'tool-games-option';
      o.textContent = typeof opt === 'string' ? opt : (opt.text || opt.nama || JSON.stringify(opt));
      optWrap.appendChild(o);
    });
    box.appendChild(optWrap);
  }

  // Jawaban disembunyikan di balik tombol biar tetap seru dimainkan
  const answer = pickField(data, ['jawaban', 'answer', 'kunci', 'kunci_jawaban', 'skor']);
  if (answer !== null) {
    const revealBtn = document.createElement('button');
    revealBtn.type = 'button';
    revealBtn.className = 'tool-games-reveal';
    revealBtn.textContent = 'Lihat jawaban';
    const answerBox = document.createElement('div');
    answerBox.className = 'tool-games-answer';
    answerBox.textContent = `Jawaban: ${typeof answer === 'string' || typeof answer === 'number' ? answer : JSON.stringify(answer)}`;
    revealBtn.addEventListener('click', () => {
      answerBox.classList.add('show');
      revealBtn.style.display = 'none';
    });
    box.appendChild(revealBtn);
    box.appendChild(answerBox);
  }

  if (!question && !imageUrl && !audioUrl && !answer) {
    // Fallback: skema JSON tidak dikenali sama sekali, tampilkan mentah
    const pre = document.createElement('div');
    pre.className = 'tool-games-question';
    pre.textContent = JSON.stringify(data, null, 2);
    box.appendChild(pre);
  }

  wrap.appendChild(box);
  wrap.appendChild(toolSource('FicTur Games', SYNOXCLOUD_BASE));
}

async function runUpscaleTool(params, wrap) {
  if (!lastUserImageDataUrl) throw new Error('Belum ada foto/video yang dilampirkan');

  const blob = dataUrlToBlob(lastUserImageDataUrl);
  const ext = blob.type.split('/')[1] || 'jpg';
  const form = new FormData();
  form.append('file', blob, `upload.${ext}`);

  const uploadRes = await fetch(KAPPA_UPLOAD_URL, { method: 'POST', body: form });
  if (!uploadRes.ok) throw new Error(`Upload gagal (HTTP ${uploadRes.status})`);
  const uploadJson = await uploadRes.json();
  const mediaUrl = uploadJson.link || uploadJson.url || uploadJson.data?.link;
  if (!mediaUrl) throw new Error('URL hasil upload tidak ditemukan');

  const upscaleUrl = `${UPSCALE_BASE}?url=${encodeURIComponent(mediaUrl)}`;
  const upscaleRes = await fetch(upscaleUrl, {
    method: 'GET',
    headers: { 'Content-Type': 'application/json' }
  });
  if (!upscaleRes.ok) throw new Error(`Upscale gagal (HTTP ${upscaleRes.status})`);

  const contentType = upscaleRes.headers.get('content-type') || '';
  wrap.innerHTML = '';
  const box = document.createElement('div');
  box.className = 'tool-screenshot';

  let resultUrl;
  let isVideo = blob.type.startsWith('video/');

  if (contentType.startsWith('image/') || contentType.startsWith('video/')) {
    const resultBlob = await upscaleRes.blob();
    resultUrl = URL.createObjectURL(resultBlob);
    isVideo = contentType.startsWith('video/');
  } else {
    const upscaleJson = await upscaleRes.json().catch(() => null);
    resultUrl = upscaleJson?.url || upscaleJson?.data?.url || upscaleJson?.result || upscaleJson?.data?.result;
    if (!resultUrl) throw new Error('Respon tidak berisi hasil media');
  }

  if (isVideo) {
    box.innerHTML = `<video src="${resultUrl}" controls style="width:100%;max-width:340px;border-radius:8px;border:1px solid rgba(120,120,130,0.25);"></video>`;
  } else {
    const img = document.createElement('img');
    img.src = resultUrl;
    box.appendChild(img);
  }
  wrap.appendChild(box);
  wrap.appendChild(createDownloadButton(resultUrl, isVideo ? 'video' : 'image'));
  wrap.appendChild(toolSource('Upscale UHD', 'https://kappa.lol'));
}

const REMOVE_BG_URL = 'https://background-remover.com/removeImageBackground';

function blobToBase64(blob) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onloadend = () => resolve(reader.result);
    reader.onerror = reject;
    reader.readAsDataURL(blob);
  });
}

async function runRemoveBgTool(params, wrap) {
  if (!lastUserImageDataUrl) throw new Error('Belum ada foto yang dilampirkan');

  const blob = dataUrlToBlob(lastUserImageDataUrl);
  if (!blob.type.startsWith('image/')) throw new Error('Hapus background hanya berlaku untuk foto, bukan video');

  const encodedImage = lastUserImageDataUrl.startsWith('data:') ? lastUserImageDataUrl : await blobToBase64(blob);

  const targetUrl = REMOVE_BG_URL;
  const proxiedUrl = PROXY + encodeURIComponent(targetUrl);

  const res = await fetch(proxiedUrl, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Origin': 'https://background-remover.com',
      'Referer': 'https://background-remover.com/upload'
    },
    body: JSON.stringify({ encodedImage, title: 'image.jpg', mimeType: blob.type || 'image/jpeg' })
  });

  if (!res.ok) throw new Error(`Hapus background gagal (HTTP ${res.status})`);

  const contentType = res.headers.get('content-type') || '';
  let resultUrl;

  if (contentType.startsWith('image/')) {
    const resultBlob = await res.blob();
    resultUrl = URL.createObjectURL(resultBlob);
  } else {
    const data = await res.json().catch(() => null);
    const resultData =
      data?.encodedImageWithoutBackground ||
      data?.image || data?.resultImage ||
      data?.output || data?.data || data?.result || null;
    if (!resultData) throw new Error('Respon tidak berisi hasil gambar');
    resultUrl = typeof resultData === 'string' && resultData.startsWith('data:')
      ? resultData
      : `data:image/png;base64,${resultData}`;
  }

  wrap.innerHTML = '';
  const box = document.createElement('div');
  box.className = 'tool-screenshot';
  const img = document.createElement('img');
  img.src = resultUrl;
  box.appendChild(img);
  wrap.appendChild(box);
  wrap.appendChild(createDownloadButton(resultUrl, 'image'));
  wrap.appendChild(toolSource('Background Remover', 'https://background-remover.com'));
}

const QRIS_BACKEND = 'https://kit-footwear-efficiency-assessed.trycloudflare.com';

function formatRupiah(n) {
  const num = Number(n) || 0;
  return 'Rp' + num.toLocaleString('id-ID');
}

async function runQrisCreateTool(params, wrap) {
  const amount = parseInt(String(params.amount || '').replace(/[^\d]/g, ''), 10);
  if (!amount || amount < 1000) throw new Error('Nominal tidak valid (minimal Rp1.000)');

  const res = await fetch(`${QRIS_BACKEND}/api/create-qris`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      amount: String(amount),
      description: 'Support Creator',
      qris_method: 'qris_two',
      fee_by: 'user'
    })
  });
  if (!res.ok) throw new Error(`HTTP ${res.status}`);
  const json = await res.json();
  if (!json.success || !json.data) throw new Error(json.error || 'Gagal membuat QRIS');

  const data = json.data;
  lastQrisTransactionId = data.transaction_id;

  const qrUrl = data.qr_url || data.qris_image;
  if (!qrUrl) throw new Error('Respon tidak berisi QR code');

  wrap.innerHTML = '';
  const box = document.createElement('div');
  box.className = 'tool-qris';

  const img = document.createElement('img');
  img.src = qrUrl;
  img.alt = 'QRIS';
  box.appendChild(img);

  const info = document.createElement('div');
  info.className = 'tool-qris-info';
  info.textContent = `${formatRupiah(data.total_amount ?? data.amount ?? amount)} — ID: ${data.transaction_id}`;
  box.appendChild(info);

  const badge = document.createElement('span');
  badge.className = 'tool-qris-badge pending';
  badge.textContent = 'Menunggu pembayaran';
  box.appendChild(badge);

  wrap.appendChild(box);
  const hint = document.createElement('div');
  hint.className = 'tool-qris-hint';
  hint.textContent = 'Scan QRIS di atas pakai e-wallet/mobile banking. Setelah bayar, bilang "udah aku bayar" untuk cek status.';
  wrap.appendChild(hint);
}

async function runQrisCheckTool(params, wrap) {
  if (!lastQrisTransactionId) throw new Error('Belum ada transaksi QRIS yang dibuat di percakapan ini');

  const res = await fetch(`${QRIS_BACKEND}/api/check-status`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ transaction_id: lastQrisTransactionId })
  });
  if (!res.ok) throw new Error(`HTTP ${res.status}`);
  const json = await res.json();
  if (!json.success || !json.data) throw new Error(json.error || 'Gagal mengecek status');

  const status = json.data.status || 'pending';
  const isPaid = status === 'success' || status === 'paid';

  wrap.innerHTML = '';
  const box = document.createElement('div');
  box.className = 'tool-qris';

  const badge = document.createElement('span');
  badge.className = 'tool-qris-badge ' + (isPaid ? 'paid' : 'pending');
  badge.textContent = isPaid ? 'Pembayaran diterima ✓' : `Status: ${status}`;
  box.appendChild(badge);

  wrap.appendChild(box);
}

const CORS_PROXY = 'https://dark-mouse-4f60.cukurukuk803.workers.dev/?url=';
const AIO_DOWNLOADER_ENDPOINT = 'https://axlyapi.qzz.io/download/aio';
const AIO_SUPPORTED_PATTERN = /(tiktok\.com|instagram\.com|youtube\.com|youtu\.be|facebook\.com|fb\.watch|twitter\.com|x\.com)/i;

async function runDownloaderTool(params, wrap) {
  const url = params.url;
  if (!url || !/^https?:\/\//i.test(url)) throw new Error('URL tidak valid');
  if (!AIO_SUPPORTED_PATTERN.test(url)) throw new Error('Saat ini hanya mendukung link TikTok, Instagram, YouTube, Facebook, atau Twitter/X');

  const target = `${AIO_DOWNLOADER_ENDPOINT}?url=${encodeURIComponent(url)}`;
  const res = await fetch(target, { headers: { 'Accept': 'application/json' } });
  if (!res.ok) throw new Error(`HTTP ${res.status}`);
  const json = await res.json();
  if (!json.status || !json.result) throw new Error('Gagal mengambil media');

  const d = json.result;
  const medias = Array.isArray(d.medias) ? d.medias : [];
  if (!medias.length) throw new Error('Media tidak ditemukan di respons');

  wrap.innerHTML = '';
  const box = document.createElement('div');
  box.className = 'tool-downloader';

  // Tampilkan tiap varian media (video HD/watermark, audio, dst) sebagai player + tombol download sendiri
  medias.forEach((m, i) => {
    if (!m.url) return;
    const item = document.createElement('div');
    item.style.cssText = 'margin-bottom:12px;';

    const label = document.createElement('div');
    label.className = 'tool-source';
    label.style.marginTop = '0';
    const qualityLabel = m.quality ? m.quality.replace(/_/g, ' ') : (m.type === 'audio' ? 'audio' : `media ${i + 1}`);
    label.innerHTML = `<span>${qualityLabel}</span>`;
    item.appendChild(label);

    if (m.type === 'audio') {
      const audio = document.createElement('audio');
      audio.src = m.url;
      audio.controls = true;
      audio.style.cssText = 'width:100%;max-width:320px;';
      item.appendChild(audio);
      item.appendChild(createDownloadButton(m.url, 'audio'));
    } else {
      const video = document.createElement('video');
      video.src = m.url;
      video.controls = true;
      if (d.thumbnail) video.poster = d.thumbnail;
      video.style.cssText = 'width:100%;max-width:320px;border-radius:8px;border:1px solid rgba(120,120,130,0.25);display:block;';
      item.appendChild(video);
      item.appendChild(createDownloadButton(m.url, 'video'));
    }

    box.appendChild(item);
  });

  wrap.appendChild(box);

  if (d.title) {
    const info = document.createElement('div');
    info.className = 'tool-qris-info';
    info.textContent = d.title.slice(0, 120);
    wrap.appendChild(info);
  }

  wrap.appendChild(toolSource(d.author ? d.author : (d.source || 'sumber'), url));
}

const WEB2ZIP_ENDPOINT = 'https://api-xemoz-official.my.id/api/tools/savewebtozip.php';

async function runWeb2ZipTool(params, wrap) {
  const url = params.url;
  if (!url || !/^https?:\/\//i.test(url)) throw new Error('URL tidak valid');

  const target = `${WEB2ZIP_ENDPOINT}?url=${encodeURIComponent(url)}`;
  const res = await fetch(PROXY + encodeURIComponent(target));
  if (!res.ok) throw new Error(`HTTP ${res.status}`);
  const json = await res.json();
  if (!json.status || !json.result) throw new Error('Gagal mengunduh website');

  const d = json.result;
  if (d.error && d.error.text && d.error.text !== '-') throw new Error(d.error.text);
  const downloadUrl = d.downloadUrl;
  if (!downloadUrl) throw new Error('Link unduhan ZIP tidak ditemukan');

  wrap.innerHTML = '';
  const box = document.createElement('div');
  box.className = 'tool-downloader';

  const info = document.createElement('div');
  info.className = 'tool-qris-info';
  const fileCount = d.copiedFilesAmount ?? '-';
  info.textContent = `${d.url || url} — ${fileCount} file berhasil disalin`;
  box.appendChild(info);

  const dlBtn = document.createElement('a');
  dlBtn.className = 'tool-download-btn';
  dlBtn.href = downloadUrl;
  dlBtn.download = `web2zip-${Date.now()}.zip`;
  dlBtn.target = '_blank';
  dlBtn.rel = 'noopener noreferrer';
  dlBtn.textContent = '⬇ Download ZIP';
  box.appendChild(dlBtn);

  wrap.appendChild(box);
  wrap.appendChild(toolSource(new URL(d.url || url).hostname, d.url || url));
}

