  // Eruda: console debug mobile, auto-aktif. Dimuat via <script> terpisah
  // di paling akhir body, setelah semua init utama selesai, supaya tidak
  // bentrok dengan skill/tool yang jalan di atas.
  var erudaScript = document.createElement('script');
  erudaScript.src = 'https://cdn.jsdelivr.net/npm/eruda';
  erudaScript.onload = function () { eruda.init(); };
  document.body.appendChild(erudaScript);
