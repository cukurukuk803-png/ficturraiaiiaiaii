const inputEl = document.getElementById('inputBox');
const sendBtn = document.getElementById('sendBtn');
const emptyState = document.getElementById('emptyState');
const historyEl = document.getElementById('history');
const newChatBtn = document.getElementById('newChatBtn');
const sidebarEl = document.getElementById('sidebar');
const sidebarToggle = document.getElementById('sidebarToggle');
const sidebarBackdrop = document.getElementById('sidebarBackdrop');
const modelBtn = document.getElementById('modelBtn');
const modelBtnLabel = document.getElementById('modelBtnLabel');
const modelMenu = document.getElementById('modelMenu');
const attachBtn = document.getElementById('attachBtn');
const imageInputEl = document.getElementById('imageInput');
const attachPreviewEl = document.getElementById('attachPreview');

function renderHistoryList() {
  historyEl.innerHTML = '';
  allChats.forEach(chat => {
    const item = document.createElement('div');
    item.className = 'hist-item' + (chat.id === currentChatId ? ' active' : '');
    item.innerHTML = `<span class="hist-title"></span><button class="hist-del" title="Hapus">✕</button>`;
    item.querySelector('.hist-title').textContent = chat.title;
    item.addEventListener('click', (e) => {
      if (e.target.closest('.hist-del')) return;
      switchToChat(chat.id);
    });
    item.querySelector('.hist-del').addEventListener('click', (e) => {
      e.stopPropagation();
      allChats = allChats.filter(c => c.id !== chat.id);
      persistAllChats();
      if (chat.id === currentChatId) {
        if (allChats.length > 0) switchToChat(allChats[0].id);
        else startNewChat();
      } else {
        renderHistoryList();
      }
    });
    historyEl.appendChild(item);
  });
}

function switchToChat(id) {
  currentChatId = id;
  conversationId = crypto.randomUUID();
  const chat = getCurrentChat();
  history = [];
  chatEl.innerHTML = '';
  if (!chat || chat.messages.length === 0) {
    chatEl.innerHTML = `<div class="empty-state"><span class="es-icon"><svg xmlns="http://www.w3.org/2000/svg" width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 20h9"/><path d="M16.5 3.5a2.12 2.12 0 0 1 3 3L7 19l-4 1 1-4Z"/></svg></span><span class="es-title">Mulai cerita apa saja</span><span class="es-sub">Ketik apa saja. Kalau ceritamu butuh wajah, FicTur akan menggambarnya.</span></div>`;
  } else {
    chat.messages.forEach(m => {
      if (m.role === 'user') {
        renderStaticUserTurn(m.text);
        history.push({ role: 'user', content: m.text });
      } else {
        renderStaticAiTurn(m.text);
        history.push({ role: 'assistant', content: m.text });
      }
    });
  }
  renderHistoryList();
  scrollToBottom(true);
  closeSidebarOnMobile();
}

function startNewChat() {
  const rec = createNewChatRecord();
  switchToChat(rec.id);
}

function isMobile() { return window.matchMedia('(max-width:640px)').matches; }

function openSidebarMobile() {
  sidebarEl.classList.add('mobile-open');
  sidebarBackdrop.classList.add('show');
}
function closeSidebarMobile() {
  sidebarEl.classList.remove('mobile-open');
  sidebarBackdrop.classList.remove('show');
}
function closeSidebarOnMobile() {
  if (isMobile()) closeSidebarMobile();
}

newChatBtn.addEventListener('click', startNewChat);
const headerNewChatBtn = document.getElementById('headerNewChatBtn');
if (headerNewChatBtn) headerNewChatBtn.addEventListener('click', startNewChat);
sidebarToggle.addEventListener('click', () => {
  if (isMobile()) {
    sidebarEl.classList.contains('mobile-open') ? closeSidebarMobile() : openSidebarMobile();
  } else {
    sidebarEl.classList.toggle('collapsed');
  }
});
sidebarBackdrop.addEventListener('click', closeSidebarMobile);

