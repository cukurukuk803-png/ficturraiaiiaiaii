/* ===================== Skill upload file (gambar & non-gambar) ===================== */
let pendingImageDataUrl = null;
let pendingImageName = '';
let pendingFileDataUrl = null;   // dataURL file non-gambar (pdf, docx, dll) yang sedang menunggu dikirim
let pendingFileName = '';
let pendingFileType = '';        // mime type file non-gambar
let pendingFileSize = 0;
let pendingFileText = '';        // isi teks file (utk .txt/.md/.csv/.json/dll) yang disisipkan ke prompt
let lastUserImageDataUrl = null; // gambar terakhir yang dikirim user, dipakai tool upscale
let lastUserAudioDataUrl = null; // audio terakhir yang dikirim user (dataURL), dipakai tool transcribe
let lastUserAudioName = '';      // nama file audio terakhir, dipakai tool transcribe
let lastQrisTransactionId = null; // transaction_id QRIS terakhir yang dibuat, dipakai tool qris_check

const MAX_ATTACH_SIZE = 5 * 1024 * 1024; // 5MB, berlaku utk gambar maupun file lain
// Tipe file yang isinya bisa dibaca sebagai teks lalu disisipkan ke prompt,
// supaya model FicTur (yang backend-nya cuma nerima teks + gambar) tetap
// bisa "membaca" isi file tersebut.
const TEXT_READABLE_TYPES = /^text\/|json$|csv$|xml$|yaml$|markdown$/i;
const TEXT_READABLE_EXT = /\.(txt|md|csv|json|xml|yaml|yml|log|js|ts|py|html|css|java|c|cpp|sh)$/i;
// Beberapa file picker (terutama Android "content://downloads/...") kadang
// gagal mengisi file.type (string kosong), padahal ekstensi filenya jelas.
// Fallback ini memetakan ekstensi umum audio ke MIME type yang benar supaya
// deteksi "ini file audio" tidak bergantung 100% pada file.type dari browser.
const AUDIO_EXT_MIME = {
  mp3: 'audio/mpeg', wav: 'audio/wav', ogg: 'audio/ogg', m4a: 'audio/mp4',
  aac: 'audio/aac', flac: 'audio/flac', opus: 'audio/opus', webm: 'audio/webm'
};
function resolveFileType(file) {
  if (file.type) return file.type;
  const ext = (file.name.split('.').pop() || '').toLowerCase();
  return AUDIO_EXT_MIME[ext] || 'application/octet-stream';
}

function fileIconSvg() {
  return '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M14.5 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7.5z"/><path d="M14 2v6h6"/></svg>';
}

function formatFileSize(bytes) {
  if (bytes < 1024) return bytes + ' B';
  if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(0) + ' KB';
  return (bytes / (1024 * 1024)).toFixed(1) + ' MB';
}

function resetPendingAttachments() {
  pendingImageDataUrl = null;
  pendingImageName = '';
  pendingFileDataUrl = null;
  pendingFileName = '';
  pendingFileType = '';
  pendingFileSize = 0;
  pendingFileText = '';
  imageInputEl.value = '';
}

attachBtn.addEventListener('click', () => imageInputEl.click());

imageInputEl.addEventListener('change', async () => {
  const file = imageInputEl.files[0];
  if (!file) return;

  if (file.size > MAX_ATTACH_SIZE) {
    alert('Ukuran file maksimal 5MB.');
    imageInputEl.value = '';
    return;
  }

  const isImage = file.type.startsWith('image/');
  const isTextReadable = TEXT_READABLE_TYPES.test(file.type) || TEXT_READABLE_EXT.test(file.name);
  const resolvedType = resolveFileType(file);

  // Reset lampiran sebelumnya (gambar atau file) — cuma satu lampiran aktif per pesan.
  pendingImageDataUrl = null;
  pendingImageName = '';
  pendingFileDataUrl = null;
  pendingFileName = '';
  pendingFileType = '';
  pendingFileSize = 0;
  pendingFileText = '';

  if (isImage) {
    const reader = new FileReader();
    reader.onload = () => {
      pendingImageDataUrl = reader.result;
      pendingImageName = file.name;
      renderAttachPreview();
    };
    reader.readAsDataURL(file);
    return;
  }

  // File non-gambar: simpan sebagai lampiran + kalau tipenya teks, baca isinya
  // supaya bisa disisipkan ke prompt (model tidak bisa "melihat" file biner
  // selain gambar, jadi ini jalan supaya isi dokumen tetap terbaca).
  pendingFileName = file.name;
  pendingFileType = resolvedType;
  pendingFileSize = file.size;

  if (isTextReadable) {
    const textReader = new FileReader();
    textReader.onload = () => {
      // Dipotong ketat: backend notrack.ai membatasi user_input TOTAL
      // (guard identitas + histori + pesan user + isi file ini) maksimal
      // 4000 karakter, jadi isi file sendirian tidak boleh mendekati itu.
      pendingFileText = String(textReader.result || '').slice(0, 1500);
      renderAttachPreview();
    };
    textReader.readAsText(file);
  } else {
    const dataReader = new FileReader();
    dataReader.onload = () => {
      let result = String(dataReader.result || '');
      // Kalau file.type browser kosong, dataURL yang dihasilkan juga punya
      // header MIME kosong/salah (data:;base64,... atau
      // data:application/octet-stream;base64,...) — timpa dengan
      // resolvedType (hasil deteksi dari ekstensi) supaya Blob yang dibuat
      // nanti (dataUrlToBlob) punya Content-Type yang benar, penting untuk
      // tool transcribe yang mengirim Content-Type ini ke server upload.
      result = result.replace(/^data:[^;]*;base64,/, `data:${resolvedType};base64,`);
      pendingFileDataUrl = result;
      renderAttachPreview();
    };
    dataReader.readAsDataURL(file);
  }
  renderAttachPreview();
});

function renderAttachPreview() {
  const hasImage = !!pendingImageDataUrl;
  const hasFile = !!pendingFileName;

  if (!hasImage && !hasFile) {
    attachPreviewEl.classList.remove('show');
    attachPreviewEl.innerHTML = '';
    attachBtn.classList.remove('active');
    return;
  }
  attachBtn.classList.add('active');
  attachPreviewEl.classList.add('show');
  attachPreviewEl.innerHTML = '';
  const chip = document.createElement('div');
  chip.className = 'attach-chip';

  if (hasImage) {
    const img = document.createElement('img');
    img.src = pendingImageDataUrl;
    chip.appendChild(img);
    const name = document.createElement('span');
    name.className = 'attach-name';
    name.textContent = pendingImageName;
    chip.appendChild(name);
  } else {
    const icon = document.createElement('div');
    icon.className = 'attach-filedoc';
    icon.innerHTML = fileIconSvg();
    chip.appendChild(icon);
    const meta = document.createElement('div');
    meta.className = 'attach-meta';
    const name = document.createElement('span');
    name.className = 'attach-name';
    name.textContent = pendingFileName;
    const size = document.createElement('span');
    size.className = 'attach-size';
    size.textContent = formatFileSize(pendingFileSize);
    meta.appendChild(name);
    meta.appendChild(size);
    chip.appendChild(meta);
  }

  const removeBtn = document.createElement('button');
  removeBtn.className = 'attach-remove';
  removeBtn.textContent = '✕';
  removeBtn.addEventListener('click', () => {
    resetPendingAttachments();
    renderAttachPreview();
  });
  chip.appendChild(removeBtn);
  attachPreviewEl.appendChild(chip);
}

