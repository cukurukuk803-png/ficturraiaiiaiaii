/* ===================== Skill tool eksternal (BintangAPI) ===================== */
const BINTANGAPI_BASE = 'https://bintangapi.my.id';

/* ===================== Skill Quotes (Ditzzx-vibecoder Assets, JSON statis di GitHub raw) ===================== */
const QUOTES_SOURCES = {
  tokoh: { url: 'https://raw.githubusercontent.com/Ditzzx-vibecoder/Assets/main/tokoh-quotes.json', figureKeys: ['figure', 'author', 'name', 'tokoh'] },
  filsuf: { url: 'https://raw.githubusercontent.com/Ditzzx-vibecoder/Assets/main/filsuf-quotes.json', figureKeys: ['philosopher', 'author', 'filsuf', 'name'] },
  anime: { url: 'https://raw.githubusercontent.com/Ditzzx-vibecoder/Assets/main/anime-quotes.json', figureKeys: ['character', 'char', 'name', 'tokoh'], animeKeys: ['anime', 'title', 'source'] },
};
// Cache sederhana per kategori supaya tidak fetch ulang seluruh JSON tiap kali
// pengguna minta quote baru dalam sesi yang sama (file JSON-nya lumayan besar).
const quotesCache = {};

/* ===================== Skill Canvas (SynoxCloud) ===================== */
const SYNOXCLOUD_BASE = 'https://api.synoxcloud.xyz';
const CANVAS_SKILLS = {
  "applemusic": {
    desc: "Generate Apple Music style player card.",
    params: ["title", "artist", "cover", "current", "total", "progress", "color1", "color2", "color3"],
    kind: "image"
  },
  "balogo": {
    desc: "Generator logo style Blue Archive dengan teks custom, efek halo anime, dan font khas game aesthetic kualitas HD.",
    params: ["left", "right"],
    kind: "image"
  },
  "bangjago": {
    desc: "Generator fake saldo Bank Jago realistis dengan nama custom dan tampilan mirip aplikasi asli kualitas HD.",
    params: ["nama", "saldo"],
    kind: "image"
  },
  "brat": {
    desc: "Generate gambar teks style brat putih hitam aesthetic otomatis rapih",
    params: ["text"],
    kind: "image"
  },
  "bratvid-gojo": {
    desc: "Generate video brat Gojo.",
    params: ["text"],
    kind: "video"
  },
  "bratvid": {
    desc: "Generate video brat putih hitam.",
    params: ["text"],
    kind: "video"
  },
  "distracted-boy-meme": {
    desc: "Distracted Boyfriend Meme",
    params: ["text1", "text2", "text3"],
    kind: "image"
  },
  "dogecheems": {
    desc: "Generate meme Doge vs Cheems",
    params: ["kiri", "kanan"],
    kind: "image"
  },
  "dragonball": {
    desc: "Generate teks bergaya Dragon Ball dengan background Shenron.",
    params: ["text"],
    kind: "image"
  },
  "drakehotline": {
    desc: "Generate meme Drake format dari 2 teks",
    params: ["teks1", "teks2"],
    kind: "image"
  },
  "e-ktp": {
    desc: "Generate kartu E-KTP, JANGAN UNTUK BERBUAT ANEH.",
    params: ["provinsi", "kota", "nik", "nama", "ttl", "jenis_kelamin", "golongan_darah", "alamat", "rt_rw", "kel_desa", "kecamatan", "agama", "status", "pekerjaan", "kewarganegaraan", "masa_berlaku", "terbuat", "pas_photo"],
    kind: "image"
  },
  "fake-dana": {
    desc: "Generate fake tampilan saldo DANA dengan nominal custom",
    params: ["nominal"],
    kind: "image"
  },
  "fake-gopay": {
    desc: "Generate Fake saldo Gopay",
    params: ["saldo", "koin", "terpakai", "bulan"],
    kind: "image"
  },
  "fake-ngl": {
    desc: "Fake NGL Generator",
    params: ["text"],
    kind: "image"
  },
  "fake-ovo": {
    desc: "Generate gambar saldo fake ovo",
    params: ["amount"],
    kind: "image"
  },
  "fakecall": {
    desc: "Bikin fake tampilan telepon masuk dengan foto profil, nama, dan waktu custom. Cocok buat prank receh manusia gabut yang hidupnya makin hari makin sinetron.",
    params: ["name", "time", "pp"],
    kind: "image"
  },
  "fakedev-2": {
    desc: "Fake developer card dengan foto profil bulat dan badge centang biru.",
    params: ["urlfoto", "teks"],
    kind: "image"
  },
  "fakedev-3": {
    desc: "Generate Fake developer card v3",
    params: ["image", "text1", "text2"],
    kind: "image"
  },
  "fakedev": {
    desc: "Generator kartu developer aesthetic dengan foto profil, nama, dan username custom kualitas HD.",
    params: ["urlfoto", "text1", "text2"],
    kind: "image"
  },
  "fakestory": {
    desc: "Generate realistic story-style image with custom nickname, text, and profile picture",
    params: ["nickname", "text", "pp"],
    kind: "image"
  },
  "fakewa": {
    desc: "Generate Fake WhatsApp Profile",
    params: ["foto", "nama", "bio", "nomor"],
    kind: "image"
  },
  "fakewafat": {
    desc: "Generate Fake Wafat",
    params: ["fotourl", "nama", "lahir", "wafat"],
    kind: "image"
  },
  "iqcimg": {
    desc: "Generate screenshot chat seperti iqc tetapi dengan gambar dan teks.",
    params: ["text", "time", "image"],
    kind: "image"
  },
  "iqc-sticker": {
    desc: "Generate chat WhatsApp stiker dengan nama dan style iphone.",
    params: ["nama", "waktu", "photo"],
    kind: "image"
  },
  "iqc": {
    desc: "Generate gambar iPhone Context Menu dengan bubble chat dan menu aksi. Emoji otomatis menggunakan style Apple.",
    params: ["text", "time", "baterai", "operator", "wifi"],
    kind: "image"
  },
  "jarvis-meme": {
    desc: "Generate meme Jarvis dengan teks custom",
    params: ["text"],
    kind: "image"
  },
  "maju-lo-meme": {
    desc: "Generate meme maju lu format 2 teks",
    params: ["atas", "bawah"],
    kind: "image"
  },
  "pakustadz": {
    desc: "Membuat kata kata ustadz",
    params: ["teks"],
    kind: "image"
  },
  "pornhub": {
    desc: "Generate logo style PornHub dengan dua teks.",
    params: ["text1", "text2"],
    kind: "image"
  },
  "quotes-v1": {
    desc: "Generate aesthetic quote images with auto text layout and optional highlighted words using [text] syntax",
    params: ["quote", "author"],
    kind: "image"
  },
  "quotes-v2": {
    desc: "Quotes V2 Generator — Membuat gambar quotes dengan foto profil dan nama author.",
    params: ["pp", "author", "text"],
    kind: "image"
  },
  "quotes-v3": {
    desc: "Generate fake motivasi image",
    params: ["quote", "author"],
    kind: "image"
  },
  "quotes-v4": {
    desc: "Generate gambar quotes.",
    params: ["text"],
    kind: "image"
  },
  "quotes-v5": {
    desc: "Generate gambar quotes.",
    params: ["text"],
    kind: "image"
  },
  "quotesnokia": {
    desc: "Generate nostalgic mobile-style quote images with custom title, message, sender, date, and time",
    params: ["header", "pesan", "sender", "date", "time"],
    kind: "image"
  },
  "red&blue-pill-meme": {
    desc: "Generate meme red/blue pill dengan 3 teks",
    params: ["atas", "kiri", "kanan"],
    kind: "image"
  },
  "smeme": {
    desc: "Generate classic meme image with top and bottom text",
    params: ["image", "top", "bottom"],
    kind: "image"
  },
  "spongebob-bacot-meme": {
    desc: "Meme SpongeBob bacot generator",
    params: ["atas", "bawah"],
    kind: "image"
  },
  "spotifycard": {
    desc: "Generator Spotify Now Playing card.",
    params: ["title", "artist", "cover"],
    kind: "image"
  },
  "sudahsaatnya": {
    desc: "Generate meme sudah saatnya dengan custom text",
    params: ["text"],
    kind: "image"
  },
  "thomas-meme": {
    desc: "Meme Thomas dengan foto custom",
    params: ["image"],
    kind: "image"
  },
  "ttqc": {
    desc: "Generate screenshot chat TikTok.",
    params: ["username", "text", "avatar"],
    kind: "image"
  },
  "wanted": {
    desc: "Wanted Poster",
    params: ["image"],
    kind: "image"
  },
  "wasted": {
    desc: "Generate efek \"Wasted\" Gta.",
    params: ["url"],
    kind: "image"
  },
  "idcard": {
    desc: "Generate ID Card developer.",
    params: ["name", "title", "script", "contact"],
    kind: "image"
  },
  "fakeff": {
    desc: "Membuat fake lobby freefire foto",
    params: ["username", "lobby"],
    kind: "image"
  },
  "fakeml": {
    desc: "Generate Fake Mobile Legends",
    params: ["avatar", "username", "rank", "border"],
    kind: "image"
  },
};

/* ===================== Skill Games (SynoxCloud) ===================== */
const GAMES_SKILLS = {
  "roblox/gag2-stock": {
    path: "/games/roblox/gag2-stock",
    desc: "Cek stock, summary, dan cuaca Grow a Garden",
    params: ["type", "category"]
  },
  "roblox/roblox-map": {
    path: "/games/roblox/roblox-map",
    desc: "Cari game di Roblox",
    params: ["query"]
  },
  "roblox/toproblox": {
    path: "/games/roblox/toproblox",
    desc: "Top 10 game trending Roblox.",
    params: []
  },
  "asah-otak": {
    path: "/games/asah-otak",
    desc: "Ambil soal asah otak secara random beserta jawaban.",
    params: []
  },
  "benaratausalah": {
    path: "/games/benaratausalah",
    desc: "Random soal benar atau salah.",
    params: []
  },
  "caklontong": {
    path: "/games/caklontong",
    desc: "Ambil soal Cak Lontong secara random beserta jawaban dan deskripsi.",
    params: []
  },
  "familly100": {
    path: "/games/familly100",
    desc: "Random soal kuis Family 100 — menampilkan pertanyaan dan daftar jawaban beserta skor.",
    params: []
  },
  "susun-kata": {
    path: "/games/susun-kata",
    desc: "Ambil soal susun kata secara random beserta tipe dan jawaban.",
    params: []
  },
  "tebak-anime": {
    path: "/games/tebak-anime",
    desc: "Ambil soal tebak anime secara random lengkap dengan gambar, deskripsi, jawaban, dan URL referensi.",
    params: []
  },
  "tebak-jorok": {
    path: "/games/tebak-jorok",
    desc: "Ambil soal tebak jorok secara random beserta jawaban.",
    params: []
  },
  "tebak-makanan": {
    path: "/games/tebak-makanan",
    desc: "Ambil soal tebak makanan secara random beserta gambar, jawaban, dan deskripsi.",
    params: []
  },
  "tebak-mtk": {
    path: "/games/tebak-mtk",
    desc: "Game tebak matematika random dengan level.",
    params: ["level"]
  },
  "tebakkarakterff": {
    path: "/games/tebakkarakterff",
    desc: "Random soal tebak karakter Free Fire — menampilkan gambar karakter dan daftar pilihan jawaban.",
    params: []
  },
  "tebaklagu": {
    path: "/games/tebaklagu",
    desc: "Random soal tebak lagu — menampilkan potongan lirik atau audio lagu beserta pilihan jawaban.",
    params: []
  },
  "tebaklogo": {
    path: "/games/tebaklogo",
    desc: "Game tebak logo random dari gambar.",
    params: []
  },
  "tebakngakak": {
    path: "/games/tebakngakak",
    desc: "Random tebak-tebakan lucu bikin ngakak.",
    params: []
  },
  "tts": {
    path: "/games/tts",
    desc: "Random teka teki silang (tts).",
    params: []
  },
};

function buildToolBlock(toolType, params) {
  const wrap = document.createElement('div');
  wrap.className = 'tool-block';
  const loading = document.createElement('div');
  loading.className = 'tool-loading';
  loading.innerHTML = `<span class="dot"></span><span>${toolLoadingLabel(toolType)}</span>`;
  wrap.appendChild(loading);

  runTool(toolType, params, wrap).catch(err => {
    wrap.innerHTML = `<div class="tool-error">⚠ Gagal memuat: ${err.message}</div>`;
  });

  return wrap;
}

function toolLoadingLabel(toolType) {
  switch (toolType) {
    case 'screenshot': return 'Mengambil screenshot...';
    case 'pinterest': return 'Mencari di Pinterest...';
    case 'sticker': return 'Mencari stiker...';
    case 'gagstock': return 'Mengecek stok Grow a Garden...';
    case 'upscale': return 'Meningkatkan kualitas media...';
    case 'remove_bg': return 'Menghapus background...';
    case 'wikipedia': return 'Mencari di Wikipedia...';
    case 'qris_create': return 'Membuat QRIS...';
    case 'qris_check': return 'Mengecek status pembayaran...';
    case 'downloader': return 'Mengambil video...';
    case 'web2zip': return 'Mengunduh seluruh isi website jadi ZIP...';
    case 'deploy': return 'Menyiapkan form deploy...';
    case 'flowchart': return 'Menggambar flowchart...';
    case 'rapor': return 'Membuat grafik rapor...';
    case 'orgchart': return 'Menyusun struktur organisasi...';
    case 'mindmap': return 'Menggambar mind map...';
    case 'conceptmap': return 'Menyusun concept map...';
    case 'peta_rute': return 'Menyusun rute pembelajaran...';
    case 'statistik': return 'Membuat grafik statistik...';
    case 'jadwal': return 'Menyusun jadwal...';
    case 'flashcard': return 'Menyiapkan flashcard...';
    case 'sertifikat': return 'Membuat sertifikat...';
    case 'presensi': return 'Merekap presensi...';
    case 'quiz_generator': return 'Menyusun soal quiz...';
    case 'rumus': return 'Menggambar rumus...';
    case 'canvas': return 'Membuat gambar Canvas...';
    case 'games': return 'Menyiapkan game...';
    case 'rpp': return 'Menyusun RPP...';
    case 'soal_essay': return 'Menyusun soal essay...';
    case 'surat_edaran': return 'Membuat surat edaran...';
    case 'cv_ringkas': return 'Menyusun CV...';
    case 'checklist': return 'Menyiapkan checklist...';
    case 'kalkulator_bmi': return 'Menghitung BMI...';
    case 'resep_masak': return 'Menyusun resep...';
    case 'countdown': return 'Menyiapkan countdown...';
    case 'quotes': return 'Mengambil quote...';
    case 'transcribe': return 'Mentranskrip audio...';
    default: return 'Memuat...';
  }
}

async function runTool(toolType, params, wrap) {
  if (toolType === 'screenshot') return runScreenshotTool(params, wrap);
  if (toolType === 'pinterest') return runPinterestTool(params, wrap);
  if (toolType === 'sticker') return runStickerTool(params, wrap);
  if (toolType === 'gagstock') return runGagstockTool(params, wrap);
  if (toolType === 'upscale') return runUpscaleTool(params, wrap);
  if (toolType === 'remove_bg') return runRemoveBgTool(params, wrap);
  if (toolType === 'wikipedia') return runWikipediaTool(params, wrap);
  if (toolType === 'qris_create') return runQrisCreateTool(params, wrap);
  if (toolType === 'qris_check') return runQrisCheckTool(params, wrap);
  if (toolType === 'downloader') return runDownloaderTool(params, wrap);
  if (toolType === 'web2zip') return runWeb2ZipTool(params, wrap);
  if (toolType === 'deploy') return runDeployTool(params, wrap);
  if (toolType === 'flowchart') return runFlowchartTool(params, wrap);
  if (toolType === 'rapor') return runRaporTool(params, wrap);
  if (toolType === 'orgchart') return runOrgChartTool(params, wrap);
  if (toolType === 'mindmap') return runMindmapTool(params, wrap);
  if (toolType === 'conceptmap') return runConceptMapTool(params, wrap);
  if (toolType === 'peta_rute') return runPetaRuteTool(params, wrap);
  if (toolType === 'statistik') return runStatistikTool(params, wrap);
  if (toolType === 'jadwal') return runJadwalTool(params, wrap);
  if (toolType === 'flashcard') return runFlashcardTool(params, wrap);
  if (toolType === 'sertifikat') return runSertifikatTool(params, wrap);
  if (toolType === 'presensi') return runPresensiTool(params, wrap);
  if (toolType === 'quiz_generator') return runQuizGeneratorTool(params, wrap);
  if (toolType === 'rumus') return runRumusTool(params, wrap);
  if (toolType === 'canvas') return runCanvasTool(params, wrap);
  if (toolType === 'games') return runGamesTool(params, wrap);
  if (toolType === 'rpp') return runRppTool(params, wrap);
  if (toolType === 'soal_essay') return runSoalEssayTool(params, wrap);
  if (toolType === 'surat_edaran') return runSuratEdaranTool(params, wrap);
  if (toolType === 'cv_ringkas') return runCvRingkasTool(params, wrap);
  if (toolType === 'checklist') return runChecklistTool(params, wrap);
  if (toolType === 'kalkulator_bmi') return runKalkulatorBmiTool(params, wrap);
  if (toolType === 'resep_masak') return runResepMasakTool(params, wrap);
  if (toolType === 'countdown') return runCountdownTool(params, wrap);
  if (toolType === 'quotes') return runQuotesTool(params, wrap);
  if (toolType === 'transcribe') return runTranscribeTool(params, wrap);
  wrap.innerHTML = `<div class="tool-error">⚠ Tool tidak dikenal: ${toolType}</div>`;
}

function toolSource(label, url) {
  const el = document.createElement('div');
  el.className = 'tool-source';
  el.innerHTML = `<span>sumber:</span> <a href="${url}" target="_blank" rel="noopener noreferrer">${label}</a>`;
  return el;
}

// Tombol download generik untuk output gambar/video/audio (screenshot, upscale, generate gambar, downloader, dll)
function createDownloadButton(mediaUrl, kind = 'image') {
  const btn = document.createElement('a');
  btn.className = 'tool-download-btn';
  btn.href = mediaUrl;
  const ext = kind === 'video' ? 'mp4' : (kind === 'audio' ? 'mp3' : 'png');
  btn.download = `fictur-${Date.now()}.${ext}`;
  btn.target = '_blank';
  btn.rel = 'noopener noreferrer';
  btn.textContent = kind === 'video' ? '⬇ Download Video' : (kind === 'audio' ? '⬇ Download Audio' : '⬇ Download Gambar');
  return btn;
}

// Render grid kartu dengan tombol "Muat lebih banyak" / "Muat lebih sedikit"
// kalau item lebih dari initialCount. renderCardFn(item) harus return elemen kartu.
function renderGridWithLoadMore(container, items, renderCardFn, initialCount = 2) {
  const grid = document.createElement('div');
  grid.className = 'tool-grid';
  items.slice(0, initialCount).forEach(item => grid.appendChild(renderCardFn(item)));
  container.appendChild(grid);

  if (items.length > initialCount) {
    const toggleBtn = document.createElement('button');
    toggleBtn.type = 'button';
    toggleBtn.className = 'tool-loadmore-btn';
    toggleBtn.textContent = `Muat lebih banyak (${items.length - initialCount})`;
    let expanded = false;
    toggleBtn.addEventListener('click', () => {
      expanded = !expanded;
      grid.innerHTML = '';
      const slice = expanded ? items : items.slice(0, initialCount);
      slice.forEach(item => grid.appendChild(renderCardFn(item)));
      toggleBtn.textContent = expanded ? 'Muat lebih sedikit' : `Muat lebih banyak (${items.length - initialCount})`;
    });
    container.appendChild(toggleBtn);
  }
}

