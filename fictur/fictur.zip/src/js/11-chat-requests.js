async function requestFicturChatbot(prompt, imageDataUrl, userPromptOnly) {
  const storedChatId = notrackChatIdByConversation.get(conversationId);

  // Upload primer boleh gagal (proxy down, network flaky, dll) — kalau gagal,
  // jangan sampai seluruh chat ikut gagal. Identitas tetap dijaga oleh
  // INLINE_IDENTITY_GUARD di bawah, jadi upload cuma "nice to have" untuk
  // konteks tambahan (daftar tool, dll), bukan satu-satunya penjaga identitas.
  let fileId = null;
  try {
    fileId = await uploadFicturPrimerFile(prompt);
  } catch (e) {
    console.warn('Upload primer gagal, lanjut tanpa attachment:', e.message);
  }

  const baseText = userPromptOnly ?? prompt;
  const textToSend = INLINE_IDENTITY_GUARD + baseText;

  const target = 'https://notrack.ai/api/dispatch';
  const dispatchBody = {
    user_input: textToSend,
    mode: 'usual',
    model: 'C',
    persona: 'normal',
    max_turns: 6,
    chat_id: storedChatId || null,
    attachments: fileId ? [fileId] : [],
    regenerate: false,
    edit: false,
    edit_mid: null
  };
  console.log('[FicTur diag] dispatch request body:', JSON.stringify(dispatchBody));
  const res = await fetch(FICTUR_CORS_PROXY + encodeURIComponent(target), {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', 'Accept': 'text/event-stream' },
    body: JSON.stringify(dispatchBody)
  });
  console.log('[FicTur diag] dispatch HTTP status:', res.status, res.ok);
  if (!res.ok) throw new Error(`HTTP ${res.status}`);
  const raw = await res.text();
  console.log('[FicTur diag] dispatch raw SSE response:', raw);
  const { text, chatId } = parseNotrackSSE(raw);
  console.log('[FicTur diag] parsed answer:', JSON.stringify(text), '| chatId:', chatId);
  if (chatId) notrackChatIdByConversation.set(conversationId, chatId);
  let answer = stripStrayImageMarkdown(text);
  answer = maskOriginalPersona(answer);
  if (!answer) throw new Error('Respon kosong');
  return answer;
}

// FicTur Q2 Code — backend Gemini via Neosoft API.
// 'sessionId' yang dibalikkan tiap respons adalah token sesi yang harus
// dikirim balik apa adanya untuk melanjutkan percakapan yang sama; disimpan
// per conversationId FicTur di Map ini supaya tiap obrolan tetap terisolasi.
// Primer FicTur (identitas + aturan format) cuma dikirim di pesan pertama
// tiap sesi baru — pesan lanjutan cukup teks user polos + sessionId tersimpan.
const q2SessionIdByConversation = new Map();
const Q2_CORS_PROXY = 'https://dark-mouse-4f60.cukurukuk803.workers.dev/?url=';
async function requestFicturQ2Code(fullPromptWithPrimer, _imageDataUrl, userPromptOnly) {
  const storedSessionId = q2SessionIdByConversation.get(conversationId);
  const isNewSession = !storedSessionId;
  const textToSend = isNewSession ? fullPromptWithPrimer : (userPromptOnly ?? fullPromptWithPrimer);
  const params = new URLSearchParams({ text: textToSend });
  if (storedSessionId) params.set('sessionId', storedSessionId);
  const target = `https://api.neosoft.best/api/ai/gemini?${params.toString()}`;
  const res = await fetch(Q2_CORS_PROXY + encodeURIComponent(target), {
    method: 'GET',
    headers: { 'Accept': 'application/json' }
  });
  if (!res.ok) throw new Error(`HTTP ${res.status}`);
  const data = await res.json();
  if (!data || !data.status || !data.reply) {
    throw new Error('Respon tidak valid dari FicTur Q2 Code');
  }
  if (data.sessionId) q2SessionIdByConversation.set(conversationId, data.sessionId);
  let answer = stripStrayImageMarkdown(data.reply);
  answer = maskOriginalPersona(answer);
  if (!answer) throw new Error('Respon kosong');
  return answer;
}

// Jaring pengaman: Kaylleno kadang tetap memicu tool generate_image internalnya
// sendiri dan menyisipkan markdown gambar di jawaban. FicTur harus selalu pakai
// jalur gambarnya sendiri (Vondy), jadi markdown gambar liar ini dibuang.
function stripStrayImageMarkdown(text) {
  if (!text) return text;
  return text
    .replace(/!\[[^\]]*\]\([^)]*\)/g, '')
    .replace(/\n{3,}/g, '\n\n')
    .trim();
}

// Jaring pengaman kedua: instruksi identitas di system prompt kadang kalah
// sama persona bawaan server ("Kayllano AI", "Kay"). Paksa ganti di sisi
// client supaya identitas FicTur konsisten 100% terlepas dari apa yang
// dijawab server.
function maskOriginalPersona(text) {
  if (!text) return text;
  return text
    .replace(/kayl+eno(\s*ai)?(\s*\d+(\.\d+)?)?/gi, 'FicTur')
    .replace(/\bkay\b(?!\w)/gi, 'FicTur')
    .replace(/dibuat(nya)? (oleh|sama|dari) (seorang )?(kreator )?(bernama )?FicTur[^.\n]*/gi, 'dibuat oleh tim FicTur')
    .replace(/asisten digital (buatan|ciptaan) FicTur/gi, 'asisten digital FicTur')
    .replace(/FicTur, seorang kreator[^.\n]*\./gi, '')
    .replace(/\n{3,}/g, '\n\n')
    .trim();
}

const MODEL_HANDLERS = {
  'fictur-chatbot': requestFicturChatbot,
  'fictur-q1-code': requestFicturChatbot,
  'fictur-q2-code': requestFicturQ2Code,
};

const MODE_PRIMERS = {
  'fictur-q1-code': CODE_MODE_PRIMER,
};

// Model yang punya primer sendiri (tidak menumpuk di atas SYSTEM_PRIMER penuh)
// karena tidak butuh akses ke daftar 22 tool eksternal — dipakai untuk model
// yang backend-nya sensitif terhadap panjang teks (GET query param).
const STANDALONE_PRIMERS = {
  'fictur-q2-code': Q2_CODE_PRIMER,
};

// PENTING soal kontinuitas percakapan: chat_id yang dibalikkan notrack.ai
// TIDAK bisa diandalkan untuk melanjutkan konteks server-side (server sering
// membalas chat_id baru yang beda dari yang dikirim, lihat catatan di
// requestFicturChatbot/uploadFicturPrimerFile). Akibatnya tiap request
// efektif dianggap sesi baru oleh notrack.ai — termasuk histori percakapan
// sebelumnya (misal pertanyaan :::quiz yang baru ditanyakan AI sendiri di
// turn sebelumnya). Supaya AI tetap "ingat" alur obrolan, histori chat lokal
// (chat.messages) WAJIB disusun ulang jadi teks dialog dan disisipkan ke
// setiap request — bukan cuma pesan terakhir user.
function buildConversationHistoryText() {
  const chat = getCurrentChat();
  if (!chat || !Array.isArray(chat.messages) || chat.messages.length === 0) return '';
  // Pesan terakhir di chat.messages adalah pesan user yang baru saja
  // ditambahkan sebelum askGemini dipanggil (lihat saveTurnToChat) — itu akan
  // dikirim terpisah sebagai "Pesan pengguna:", jadi di sini ambil semua
  // turn SEBELUM itu saja supaya tidak dobel.
  const priorTurns = chat.messages.slice(0, -1);
  if (priorTurns.length === 0) return '';
  // Karena chat_id dari notrack.ai tidak reliable untuk kontinuitas server-side
  // (lihat catatan di requestFicturChatbot), histori ini disusun ulang di
  // client dan disuntikkan ke tiap request. Masalahnya: kalau turn
  // sebelumnya menghasilkan balasan yang gagal/tidak wajar (misalnya AI
  // salah memproses instruksi sistem dan cuma membalas "Tersimpan." tanpa
  // benar-benar memanggil tool yang diminta), balasan gagal itu ikut
  // tersalin ke histori dan AI cenderung MENIRU pola gagal itu lagi di
  // turn berikutnya. Untuk mencegah pola gagal "menular", tandai balasan
  // asisten yang mencurigakan (sangat pendek, di bawah 12 karakter) supaya
  // AI tahu itu bukan contoh yang harus diikuti.
  const lines = priorTurns.map(m => {
    const label = m.role === 'user' ? 'Pengguna' : 'FicTur';
    let text = m.text;
    if (m.role === 'assistant' && text.trim().length > 0 && text.trim().length < 12) {
      text += ' [balasan ini kemungkinan gagal/tidak lengkap — jangan ditiru polanya]';
    }
    return `${label}: ${text}`;
  });
  return `Berikut riwayat percakapan sejauh ini (untuk konteks, jangan diulang-ulang ke user):\n${lines.join('\n')}`;
}

function buildFullPrompt(modelId, userPrompt, historyText) {
  const historyBlock = historyText ? `${historyText}\n\n---\n\n` : '';
  if (STANDALONE_PRIMERS[modelId]) {
    return `${STANDALONE_PRIMERS[modelId]}\n\n---\n\n${historyBlock}Pesan pengguna: ${userPrompt}`;
  }
  const extraPrimer = MODE_PRIMERS[modelId];
  const systemPrompt = extraPrimer
    ? `${SYSTEM_PRIMER}\n\n---\n\n${extraPrimer}`
    : SYSTEM_PRIMER;
  return `${systemPrompt}\n\n---\n\n${historyBlock}Pesan pengguna: ${userPrompt}`;
}

async function askGemini(userPrompt, imageDataUrl) {
  // PENTING: jangan diam-diam pindah ke model lain kalau model yang dipilih
  // user gagal — tiap model punya primer/identitas beda (mis. FicTur Chatbot
  // vs Q1 Code), jadi fallback otomatis ke model lain bikin jawaban keluar
  // dengan identitas yang salah tanpa sepengetahuan user. Cukup retry model
  // yang sama sekali sebelum benar-benar menyerah.
  const model = GEMINI_MODELS.find(m => m.id === selectedModelId) || GEMINI_MODELS[0];
  const handler = MODEL_HANDLERS[model.id];
  if (!handler) throw new Error('Model tidak dikenal: ' + model.id);
  const historyText = buildConversationHistoryText();
  const fullPrompt = buildFullPrompt(model.id, userPrompt, historyText);
  // userPromptOnly juga perlu histori, karena requestFicturChatbot memakai
  // ini (bukan fullPrompt) sebagai isi user_input yang benar-benar "didengar"
  // notrack.ai (lihat INLINE_IDENTITY_GUARD + baseText).
  const userPromptWithHistory = historyText
    ? `${historyText}\n\n---\n\nPesan pengguna: ${userPrompt}`
    : userPrompt;

  let lastErr = '';
  for (let attempt = 0; attempt < 2; attempt++) {
    try {
      return await handler(fullPrompt, imageDataUrl, userPromptWithHistory);
    } catch (e) {
      lastErr = e.message;
    }
  }
  throw new Error(`${model.name} gagal merespons: ${lastErr}`);
}

function extractImagePrompt(aiText) {
  const marker = /oke ini dia gambar(nya)?\.{0,3}/i;
  const match = aiText.match(marker);
  if (!match) return null;
  const before = aiText.slice(0, match.index).trim();
  if (!before) return null;
  // Ambil hanya paragraf terakhir (dipisah baris kosong) sebagai deskripsi visual,
  // supaya konten lain (tabel, kode, teks sebelumnya) tidak ikut jadi prompt gambar.
  const paragraphs = before.split(/\n\s*\n/).map(p => p.trim()).filter(Boolean);
  const desc = paragraphs.length ? paragraphs[paragraphs.length - 1] : before;
  return desc.length > 0 ? desc : null;
}

