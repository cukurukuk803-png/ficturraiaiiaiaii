async function runWikipediaTool(params, wrap) {
  const query = params.query;
  if (!query) throw new Error('Kata kunci tidak diberikan');
  const apiUrl = `${BINTANGAPI_BASE}/api/search/wikipedia?q=${encodeURIComponent(query)}`;
  const res = await fetch(apiUrl);
  if (!res.ok) throw new Error(`HTTP ${res.status}`);
  const json = await res.json();
  const results = json.data?.results || [];
  if (!results.length) throw new Error('Tidak ada hasil');
  const top = results[0];
  wrap.innerHTML = '';
  const card = document.createElement('a');
  card.className = 'tool-wiki-card';
  card.href = top.detail?.url || '#';
  card.target = '_blank';
  card.rel = 'noopener noreferrer';
  const excerpt = (top.detail?.content || top.description || '').slice(0, 220);
  card.innerHTML = `
    ${top.thumbnail ? `<img src="${top.thumbnail}" loading="lazy">` : ''}
    <div>
      <div class="tool-wiki-title">${top.title}</div>
      <div class="tool-wiki-excerpt">${excerpt}${excerpt.length >= 220 ? '…' : ''}</div>
    </div>`;
  wrap.appendChild(card);
  wrap.appendChild(toolSource('Wikipedia', top.detail?.url || 'https://id.wikipedia.org'));
}

