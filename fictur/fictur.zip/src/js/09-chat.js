function isNearBottom() {
  return chatEl.scrollHeight - chatEl.scrollTop - chatEl.clientHeight < 120;
}
function scrollToBottom(force) {
  if (force || isNearBottom()) {
    chatEl.scrollTop = chatEl.scrollHeight;
  }
}

function addUserTurn(text, imageDataUrl, fileInfo) {
  const es = document.getElementById('emptyState');
  if (es) es.remove();
  const turn = document.createElement('div');
  turn.className = 'turn user';
  turn.innerHTML = `<div class="who">kamu</div><div class="bubble"></div>`;
  const bubble = turn.querySelector('.bubble');
  if (imageDataUrl) {
    const img = document.createElement('img');
    img.className = 'user-attach-img';
    img.src = imageDataUrl;
    bubble.appendChild(img);
  } else if (fileInfo && fileInfo.name) {
    const fileChip = document.createElement('div');
    fileChip.className = 'user-attach-file';
    const icon = document.createElement('div');
    icon.className = 'attach-filedoc';
    icon.innerHTML = fileIconSvg();
    const name = document.createElement('span');
    name.className = 'attach-name';
    name.textContent = fileInfo.name;
    fileChip.appendChild(icon);
    fileChip.appendChild(name);
    bubble.appendChild(fileChip);
  }
  const textNode = document.createElement('span');
  textNode.textContent = text;
  bubble.appendChild(textNode);
  chatEl.appendChild(turn);
  scrollToBottom(true);
}

function addAiTurnSkeleton() {
  const turn = document.createElement('div');
  turn.className = 'turn ai';
  turn.innerHTML = `<div class="who">fictur</div><div class="bubble"><span class="typed"></span><span class="caret"></span></div>`;
  chatEl.appendChild(turn);
  scrollToBottom(true);
  return turn;
}

