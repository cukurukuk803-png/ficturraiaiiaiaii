// Tool deploy: BUKAN auto-fetch dari parameter AI (isi HTML lengkap tidak
// pernah lewat prompt AI karena kena limit karakter backend). Sebagai
// gantinya, render form interaktif — user pilih file & nama project sendiri
// di sisi client, isi file dibaca via FileReader dan dikirim langsung ke API
// deploy lewat PROXY, tanpa AI pernah "melihat" isi filenya sama sekali.
function runDeployTool(params, wrap) {
  wrap.innerHTML = '';
  const suggestedProject = (params.project || '').trim();
  const card = buildDeployCard(suggestedProject);
  wrap.appendChild(card);
}

function buildDeployCard(suggestedProject, isFullscreen) {
  const card = document.createElement('div');
  card.className = 'tool-deploy';

  let selectedFile = null;

  const head = document.createElement('div');
  head.className = 'tool-deploy-head';
  const title = document.createElement('div');
  title.className = 'tool-deploy-title';
  title.innerHTML = `<span>🚀</span><span>Deploy Website</span>`;
  head.appendChild(title);
  if (!isFullscreen) {
    const expandBtn = document.createElement('button');
    expandBtn.className = 'tool-deploy-expand';
    expandBtn.type = 'button';
    expandBtn.textContent = '⤢ Layar penuh';
    expandBtn.addEventListener('click', () => openDeployFullscreen(suggestedProject));
    head.appendChild(expandBtn);
  }
  card.appendChild(head);

  const projectField = document.createElement('div');
  projectField.className = 'tool-deploy-field';
  projectField.innerHTML = `<label>Nama project</label>`;
  const projectInput = document.createElement('input');
  projectInput.type = 'text';
  projectInput.placeholder = 'nama-project-singkat';
  projectInput.value = suggestedProject;
  projectField.appendChild(projectInput);
  card.appendChild(projectField);

  const drop = document.createElement('div');
  drop.className = 'tool-deploy-drop';
  drop.textContent = '📄 Ketuk untuk pilih file HTML, atau seret file ke sini';
  const fileInput = document.createElement('input');
  fileInput.type = 'file';
  fileInput.accept = '.html,.htm,text/html';
  fileInput.style.display = 'none';
  card.appendChild(drop);
  card.appendChild(fileInput);

  function setSelectedFile(file) {
    selectedFile = file;
    if (file) {
      drop.textContent = `✓ ${file.name} (${formatFileSize(file.size)})`;
      drop.classList.add('has-file');
    } else {
      drop.textContent = '📄 Ketuk untuk pilih file HTML, atau seret file ke sini';
      drop.classList.remove('has-file');
    }
  }

  drop.addEventListener('click', () => fileInput.click());
  fileInput.addEventListener('change', () => {
    if (fileInput.files && fileInput.files[0]) setSelectedFile(fileInput.files[0]);
  });
  drop.addEventListener('dragover', (e) => { e.preventDefault(); drop.classList.add('dragover'); });
  drop.addEventListener('dragleave', () => drop.classList.remove('dragover'));
  drop.addEventListener('drop', (e) => {
    e.preventDefault();
    drop.classList.remove('dragover');
    if (e.dataTransfer.files && e.dataTransfer.files[0]) setSelectedFile(e.dataTransfer.files[0]);
  });

  const deployBtn = document.createElement('button');
  deployBtn.className = 'tool-deploy-btn';
  deployBtn.type = 'button';
  deployBtn.textContent = 'Deploy';
  card.appendChild(deployBtn);

  const resultSlot = document.createElement('div');
  card.appendChild(resultSlot);

  deployBtn.addEventListener('click', async () => {
    resultSlot.innerHTML = '';
    const project = projectInput.value.trim();
    if (!project) {
      resultSlot.innerHTML = `<div class="tool-deploy-error">⚠ Isi nama project dulu.</div>`;
      return;
    }
    if (!selectedFile) {
      resultSlot.innerHTML = `<div class="tool-deploy-error">⚠ Pilih file HTML dulu.</div>`;
      return;
    }
    deployBtn.disabled = true;
    deployBtn.textContent = 'Men-deploy...';
    try {
      const fileContent = await selectedFile.text();
      const target = 'https://deploy.project.ekkstore.web.id/api/deploy';
      const res = await fetch(PROXY + encodeURIComponent(target), {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ project, fileName: selectedFile.name || 'index.html', fileContent })
      });
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      const data = await res.json();
      if (!data.success || !data.url) throw new Error(data.message || 'Deploy gagal');
      resultSlot.innerHTML = '';
      const resultBox = document.createElement('div');
      resultBox.className = 'tool-deploy-result';
      resultBox.innerHTML = `Berhasil di-deploy: <a href="${data.url}" target="_blank" rel="noopener noreferrer">${data.url}</a>`;
      resultSlot.appendChild(resultBox);
    } catch (err) {
      resultSlot.innerHTML = `<div class="tool-deploy-error">⚠ Gagal deploy: ${err.message}</div>`;
    } finally {
      deployBtn.disabled = false;
      deployBtn.textContent = 'Deploy';
    }
  });

  return card;
}

function openDeployFullscreen(suggestedProject) {
  const overlay = document.createElement('div');
  overlay.className = 'preview-overlay';

  function closeOverlay(){
    overlay.classList.add('closing');
    setTimeout(() => overlay.remove(), 200);
  }

  const panel = document.createElement('div');
  panel.className = 'preview-panel';

  const bar = document.createElement('div');
  bar.className = 'preview-bar';
  const title = document.createElement('span');
  title.className = 'preview-title';
  title.textContent = 'Deploy Website';
  const closeBtn = document.createElement('button');
  closeBtn.className = 'preview-close';
  closeBtn.textContent = '✕ Tutup';
  closeBtn.addEventListener('click', () => closeOverlay());
  bar.appendChild(title);
  bar.appendChild(closeBtn);

  const body = document.createElement('div');
  body.style.cssText = 'padding:20px; overflow-y:auto; display:flex; justify-content:center;';
  const card = buildDeployCard(suggestedProject, true);
  card.style.maxWidth = '480px';
  card.style.width = '100%';
  body.appendChild(card);

  panel.appendChild(bar);
  panel.appendChild(body);
  overlay.appendChild(panel);

  overlay.addEventListener('click', (e) => {
    if (e.target === overlay) closeOverlay();
  });

  document.body.appendChild(overlay);
}



