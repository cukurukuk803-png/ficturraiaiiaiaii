/* ===================== Model picker ===================== */
function renderModelMenu() {
  modelMenu.innerHTML = '';
  GEMINI_MODELS.forEach(m => {
    const opt = document.createElement('div');
    opt.className = 'model-opt' + (m.id === selectedModelId ? ' active' : '');
    opt.innerHTML = `<span class="name"></span><span class="desc"></span>`;
    opt.querySelector('.name').textContent = m.name;
    opt.querySelector('.desc').textContent = m.desc;
    opt.addEventListener('click', () => {
      selectedModelId = m.id;
      modelBtnLabel.textContent = m.name;
      modelMenu.classList.remove('open');
      modelBtn.classList.remove('open');
      renderModelMenu();
    });
    modelMenu.appendChild(opt);
  });
}
renderModelMenu();
modelBtn.addEventListener('click', () => {
  modelMenu.classList.toggle('open');
  modelBtn.classList.toggle('open');
});
document.addEventListener('click', (e) => {
  if (!e.target.closest('#modelPicker')) {
    modelMenu.classList.remove('open');
    modelBtn.classList.remove('open');
  }
});

inputEl.addEventListener('input', () => {
  inputEl.style.height = 'auto';
  inputEl.style.height = Math.min(inputEl.scrollHeight, 120) + 'px';
});

inputEl.addEventListener('keydown', (e) => {
  if (e.key === 'Enter' && !e.shiftKey) {
    e.preventDefault();
    handleSend();
  }
});
sendBtn.addEventListener('click', handleSend);

