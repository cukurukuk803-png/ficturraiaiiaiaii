/* ===================== Skill kode: deteksi + render code block ===================== */
const EXT_BY_LANG = {
  javascript:'js', js:'js', typescript:'ts', ts:'ts', python:'py', py:'py',
  html:'html', css:'css', json:'json', bash:'sh', sh:'sh', shell:'sh',
  java:'java', c:'c', cpp:'cpp', 'c++':'cpp', csharp:'cs', 'c#':'cs',
  php:'php', ruby:'rb', go:'go', rust:'rs', sql:'sql', yaml:'yml', yml:'yml',
  xml:'xml', markdown:'md', kotlin:'kt', swift:'swift', dart:'dart'
};

function escapeHtml(s) {
  return s.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');
}

// Render markdown inline (bold, italic, link) + heading + blockquote + list
// dalam satu blok teks biasa. Dipakai untuk tiap segmen 'text' di renderFinalContent.
function renderInlineMarkdown(container, raw) {
  const lines = raw.split('\n');
  let i = 0;

  function inlineToHtml(text) {
    let escaped = escapeHtml(text);
    escaped = escaped.replace(/\[([^\]]+)\]\((https?:\/\/[^\s)]+)\)/g, (_, label, url) => {
      return `<a href="${url}" target="_blank" rel="noopener noreferrer">${label}</a>`;
    });
    escaped = escaped.replace(/\*\*([^*]+)\*\*/g, '<strong>$1</strong>');
    escaped = escaped.replace(/(?<!\*)\*([^*\n]+)\*(?!\*)/g, '<em>$1</em>');
    return escaped;
  }

  function flushParagraph(buf) {
    if (!buf.length) return;
    const p = document.createElement('p');
    p.className = 'md-p';
    p.innerHTML = buf.join('\n').split('\n').map(inlineToHtml).join('<br>');
    container.appendChild(p);
  }

  let paraBuf = [];

  while (i < lines.length) {
    const line = lines[i];
    const headingMatch = line.match(/^(#{1,3})\s+(.*)$/);
    const quoteMatch = line.match(/^>\s?(.*)$/);
    const listMatch = line.match(/^\s*[-*]\s+(.*)$/);
    const numListMatch = line.match(/^\s*\d+\.\s+(.*)$/);

    if (headingMatch) {
      flushParagraph(paraBuf); paraBuf = [];
      const level = headingMatch[1].length;
      const h = document.createElement(level === 1 ? 'h3' : level === 2 ? 'h4' : 'h5');
      h.className = 'md-heading';
      h.innerHTML = inlineToHtml(headingMatch[2]);
      container.appendChild(h);
      i++;
    } else if (quoteMatch) {
      flushParagraph(paraBuf); paraBuf = [];
      const quoteLines = [];
      while (i < lines.length && /^>\s?/.test(lines[i])) {
        quoteLines.push(lines[i].replace(/^>\s?/, ''));
        i++;
      }
      const bq = document.createElement('blockquote');
      bq.className = 'md-quote';
      bq.innerHTML = quoteLines.map(inlineToHtml).join('<br>');
      container.appendChild(bq);
    } else if (listMatch || numListMatch) {
      flushParagraph(paraBuf); paraBuf = [];
      const ordered = !!numListMatch;
      const items = [];
      while (i < lines.length) {
        const m = ordered ? lines[i].match(/^\s*\d+\.\s+(.*)$/) : lines[i].match(/^\s*[-*]\s+(.*)$/);
        if (!m) break;
        items.push(m[1]);
        i++;
      }
      const list = document.createElement(ordered ? 'ol' : 'ul');
      list.className = 'md-list';
      items.forEach(itemText => {
        const li = document.createElement('li');
        li.innerHTML = inlineToHtml(itemText);
        list.appendChild(li);
      });
      container.appendChild(list);
    } else if (line.trim() === '') {
      flushParagraph(paraBuf); paraBuf = [];
      i++;
    } else {
      paraBuf.push(line);
      i++;
    }
  }
  flushParagraph(paraBuf);
}

// Pisah teks jadi segmen {type:'text'|'code'|'table', ...} berdasar fenced block, lalu tabel markdown
function splitTextAndCode(raw) {
  const codeSegments = [];
  const re = /```([a-zA-Z0-9+#]*)(?::([^\n]+))?\n?([\s\S]*?)```/g;
  let lastIndex = 0;
  let m;
  while ((m = re.exec(raw)) !== null) {
    if (m.index > lastIndex) {
      codeSegments.push({ type:'text', content: raw.slice(lastIndex, m.index) });
    }
    const lang = (m[1] || 'text').toLowerCase();
    const filename = (m[2] || '').trim() || null;
    codeSegments.push({ type:'code', lang, filename, content: m[3].replace(/\n$/, '') });
    lastIndex = re.lastIndex;
  }
  if (lastIndex < raw.length) {
    codeSegments.push({ type:'text', content: raw.slice(lastIndex) });
  }

  // pass kedua: pecah tiap segmen text jadi text/table berdasar baris markdown table
  // pass ketiga: dari situ, pecah lagi text jadi text/quiz berdasar blok :::quiz ... :::
  const segments = [];
  codeSegments.forEach(seg => {
    if (seg.type !== 'text') { segments.push(seg); return; }
    splitTextAndTables(seg.content).forEach(subSeg => {
      if (subSeg.type !== 'text') { segments.push(subSeg); return; }
      segments.push(...splitTextAndQuiz(subSeg.content));
    });
  });
  return segments;
}

// Deteksi blok pertanyaan pilihan ganda: :::quiz ... :::
function splitTextAndQuiz(text) {
  const re = /:::(quiz|tool)\s*\n([\s\S]*?):::/g;
  const out = [];
  let lastIndex = 0;
  let m;
  while ((m = re.exec(text)) !== null) {
    if (m.index > lastIndex) out.push({ type:'text', content: text.slice(lastIndex, m.index) });
    if (m[1] === 'quiz') {
      const parsed = parseQuizBlock(m[2]);
      if (parsed) out.push({ type:'quiz', ...parsed });
    } else {
      const parsed = parseToolBlock(m[2]);
      if (parsed) out.push({ type:'tool', ...parsed });
    }
    lastIndex = re.lastIndex;
  }
  if (lastIndex < text.length) out.push({ type:'text', content: text.slice(lastIndex) });
  return out;
}

function parseQuizBlock(inner) {
  const lines = inner.split('\n').map(l => l.trim()).filter(l => l !== '');
  if (!lines.length) return null;
  const question = lines[0];
  const options = lines.slice(1)
    .filter(l => /^[-*]\s+/.test(l))
    .map(l => l.replace(/^[-*]\s+/, ''));
  if (!options.length) return null;
  return { question, options };
}

// Parse blok :::tool ... ::: jadi { toolType, params: {key: value} }
function parseToolBlock(inner) {
  const lines = inner.split('\n').map(l => l.trim()).filter(l => l !== '');
  const params = {};
  lines.forEach(line => {
    const m = line.match(/^([a-zA-Z_]+)\s*:\s*(.+)$/);
    if (m) params[m[1].toLowerCase()] = m[2].trim();
  });
  const toolType = params.type;
  if (!toolType) return null;
  delete params.type;
  return { toolType, params };
}

// Deteksi blok tabel markdown: baris "| a | b |" diikuti baris pemisah "|---|---|"
function splitTextAndTables(text) {
  const lines = text.split('\n');
  const out = [];
  let buffer = [];
  let i = 0;

  const isRowLine = (line) => /^\s*\|.*\|\s*$/.test(line);
  const isSepLine = (line) => /^\s*\|?(\s*:?-{2,}:?\s*\|)+\s*:?-{2,}:?\s*\|?\s*$/.test(line);

  function flushBuffer() {
    if (buffer.length) out.push({ type:'text', content: buffer.join('\n') });
    buffer = [];
  }

  while (i < lines.length) {
    if (isRowLine(lines[i]) && i + 1 < lines.length && isSepLine(lines[i+1])) {
      flushBuffer();
      const headerLine = lines[i];
      i += 2;
      const bodyLines = [];
      while (i < lines.length && isRowLine(lines[i])) {
        bodyLines.push(lines[i]);
        i++;
      }
      const parsed = parseMarkdownTable(headerLine, bodyLines);
      if (parsed) out.push({ type:'table', ...parsed });
      else buffer.push(headerLine);
    } else {
      buffer.push(lines[i]);
      i++;
    }
  }
  flushBuffer();
  return out;
}

function splitTableRow(line) {
  const trimmed = line.trim().replace(/^\|/, '').replace(/\|$/, '');
  return trimmed.split('|').map(c => c.trim());
}

function parseMarkdownTable(headerLine, bodyLines) {
  const headers = splitTableRow(headerLine);
  if (!headers.length) return null;
  const rows = bodyLines.map(splitTableRow);
  return { headers, rows };
}

// Gambar satu tabel ke canvas lalu unduh sebagai JPG
function tableToImageAndDownload(headers, rows, btn) {
  const padX = 14, padY = 9, rowH = 34, fontSize = 13;
  const font = `${fontSize}px 'JetBrains Mono', monospace`;
  const boldFont = `500 ${fontSize}px 'JetBrains Mono', monospace`;

  const measureCanvas = document.createElement('canvas');
  const mctx = measureCanvas.getContext('2d');

  const colWidths = headers.map((h, idx) => {
    mctx.font = boldFont;
    let max = mctx.measureText(h).width;
    mctx.font = font;
    rows.forEach(row => {
      const w = mctx.measureText(String(row[idx] || '')).width;
      if (w > max) max = w;
    });
    return Math.max(max + padX * 2, 70);
  });

  const width = colWidths.reduce((a, b) => a + b, 0);
  const height = rowH * (rows.length + 1);

  const scale = 2; // biar hasil unduhan tetap tajam
  const canvas = document.createElement('canvas');
  canvas.width = width * scale;
  canvas.height = height * scale;
  const ctx = canvas.getContext('2d');
  ctx.scale(scale, scale);

  // latar
  ctx.fillStyle = '#27272f';
  ctx.fillRect(0, 0, width, height);

  // header
  ctx.fillStyle = 'rgba(124,106,232,0.16)';
  ctx.fillRect(0, 0, width, rowH);

  let x = 0;
  headers.forEach((h, idx) => {
    ctx.fillStyle = '#7c6ae8';
    ctx.font = boldFont;
    ctx.textBaseline = 'middle';
    ctx.fillText(h, x + padX, rowH / 2, colWidths[idx] - padX * 2);
    x += colWidths[idx];
  });

  // baris data
  rows.forEach((row, rIdx) => {
    const y = rowH * (rIdx + 1);
    ctx.fillStyle = rIdx % 2 === 0 ? 'rgba(120,120,130,0.06)' : 'transparent';
    if (ctx.fillStyle !== 'transparent') ctx.fillRect(0, y, width, rowH);

    let cx = 0;
    headers.forEach((_, cIdx) => {
      ctx.fillStyle = '#f5f5f7';
      ctx.font = font;
      ctx.textBaseline = 'middle';
      ctx.fillText(String(row[cIdx] || ''), cx + padX, y + rowH / 2, colWidths[cIdx] - padX * 2);
      cx += colWidths[cIdx];
    });

    ctx.strokeStyle = 'rgba(120,120,130,0.18)';
    ctx.beginPath();
    ctx.moveTo(0, y);
    ctx.lineTo(width, y);
    ctx.stroke();
  });

  canvas.toBlob(blob => {
    if (!blob) {
      btn.textContent = 'Gagal';
      setTimeout(() => { btn.textContent = '⬇ Unduh tabel'; }, 1500);
      return;
    }
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `tabel-${Date.now()}.jpg`;
    a.click();
    URL.revokeObjectURL(url);
    btn.textContent = 'Terunduh ✓';
    btn.classList.add('copied');
    setTimeout(() => { btn.textContent = '⬇ Unduh tabel'; btn.classList.remove('copied'); }, 1500);
  }, 'image/jpeg', 0.95);
}

function buildTable(headers, rows) {
  const wrap = document.createElement('div');
  wrap.className = 'table-wrap';

  const toolbar = document.createElement('div');
  toolbar.className = 'table-toolbar';
  const dlBtn = document.createElement('button');
  dlBtn.className = 'table-dl';
  dlBtn.textContent = '⬇ Unduh tabel';
  dlBtn.addEventListener('click', () => {
    try {
      tableToImageAndDownload(headers, rows, dlBtn);
    } catch (_) {
      dlBtn.textContent = 'Gagal';
      setTimeout(() => { dlBtn.textContent = '⬇ Unduh tabel'; }, 1500);
    }
  });
  toolbar.appendChild(dlBtn);
  wrap.appendChild(toolbar);

  const scroll = document.createElement('div');
  scroll.className = 'table-scroll';

  const table = document.createElement('table');
  table.className = 'md-table';

  const thead = document.createElement('thead');
  const headTr = document.createElement('tr');
  headers.forEach(h => {
    const th = document.createElement('th');
    th.textContent = h;
    headTr.appendChild(th);
  });
  thead.appendChild(headTr);
  table.appendChild(thead);

  const tbody = document.createElement('tbody');
  rows.forEach(row => {
    const tr = document.createElement('tr');
    headers.forEach((_, idx) => {
      const td = document.createElement('td');
      td.textContent = row[idx] || '';
      tr.appendChild(td);
    });
    tbody.appendChild(tr);
  });
  table.appendChild(tbody);

  scroll.appendChild(table);
  wrap.appendChild(scroll);
  return wrap;
}

